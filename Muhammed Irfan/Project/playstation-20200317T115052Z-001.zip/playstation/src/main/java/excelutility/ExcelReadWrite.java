package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelReadWrite
{
	public String excel_month(int a) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String mo=cell.getStringCellValue();
		return mo;
			
		
		
	}
	public String excel_date(int b) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(1);
			String da=cell.getStringCellValue();
		return da;
			
		
		
	}
	public String excel_year(int c) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(c);
			XSSFCell cell=row.getCell(2);
			String ye=cell.getStringCellValue();
		return ye;
			
		
		
	}
	public String excel_searchpass(int a) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet2");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String se=cell.getStringCellValue();
		return se;
			
		
		
	}
	public String excel_quantity(int b) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet2");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(1);
			String qu=cell.getStringCellValue();
		return qu;
			
		
		
	}
	public String excel_searchpassitem(int a) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet3");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String se=cell.getStringCellValue();
		return se;
			
		
		
	}
	public String excel_quantityno(int b) throws IOException
	{
		FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\hardwareshop.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet3");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(1);
			String qu=cell.getStringCellValue();
		return qu;
			
		
		
	}
	
}

