package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import baseclass.wrapperclass;



public class register extends  wrapperclass
{
	public register(WebDriver driver)
	{
		this.driver=driver;
		
	}
public void signin()
{
	driver.findElement(By.xpath("//*[@id=\"ember338\"]")).click();
}
public void createaccnt()
{
	driver.findElement(By.xpath("//*[@id=\"ember27\"]/button")).click();	
}
public void start()
{
	driver.findElement(By.xpath("//*[@id=\"ember15\"]/button")).click();
}
public void emailid(String a)
{
	driver.findElement(By.xpath("//*[@id=\"ember43\"]")).sendKeys(a);
}
public void password(String b)
{
	driver.findElement(By.xpath("//*[@id=\"ember47\"]")).sendKeys(b);
}
public void cpassword(String c)
{
	driver.findElement(By.xpath("//*[@id=\"ember49\"]")).sendKeys(c);
}
public void next()
{
	driver.findElement(By.xpath("//*[@id=\"ember52\"]/button")).click();
}
public void country() throws InterruptedException
{
	driver.findElement(By.id("ember66")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"ember66\"]/div/select/option[34]")).click();
}
public void dob() throws InterruptedException
{
	driver.findElement(By.id("ember87")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.xpath("//*[@id=\"ember87\"]/div/select/option[12]")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember73")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.xpath("//*[@id=\"ember73\"]/div/select/option[6]")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember120")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.xpath("//*[@id=\"ember120\"]/div/select/option[25]")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember247")).click();
}
public void city(String d)
{
	driver.findElement(By.id("ember468")).sendKeys(d);
}
public void state(String e)
{
	driver.findElement(By.id("ember471")).sendKeys(e);
}
public void postcode(String f) throws InterruptedException
{
	Actions act=new Actions(driver);
	
	act.moveToElement(driver.findElement(By.xpath("//*[@id=\"ember474\"]"))).sendKeys(f).build().perform();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember477")).click();
}
public void onlineid()
{
	driver.findElement(By.id("ember514")).sendKeys("jackym43");
}
public void fname(String g)
{
	driver.findElement(By.id("ember519")).sendKeys(g);
}
public void lname(String h) throws InterruptedException
{
	
	
	driver.findElement(By.id("ember521")).sendKeys(h);
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember525")).click();
}
public void click_continue()
{
	driver.findElement(By.xpath("//*[@id=\"ember534\"]/button")).click();
}
public void click_agree() throws InterruptedException
{
	driver.findElement(By.id("ember555")).click();
	TimeUnit.SECONDS.sleep(2);
	driver.findElement(By.id("ember571")).click();
}





}
