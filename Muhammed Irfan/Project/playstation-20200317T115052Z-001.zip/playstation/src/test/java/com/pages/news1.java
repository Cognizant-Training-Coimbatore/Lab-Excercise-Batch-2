package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;



public class news1 extends wrapperclass
{
	public news1(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void news()
	{
	driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-news\"]")).click();
	}
	public void PSBlog()
	{
	driver.findElement(By.id("link-secondary--msg-ps-blog")).click();	
	}
	
	public void place()
	{
	driver.findElement(By.xpath("//*[@id=\"site-navigation\"]/div[1]/div[2]/div[2]/button/span[3]")).click();
	driver.findElement(By.xpath("//*[@id=\"site-navigation\"]/div[1]/div[2]/div[2]/div/ul/li[2]")).click();
	}
	public void news2() throws InterruptedException
	{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,350)");
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[3]/div[1]/div[2]/a[1]/div[1]/div[2]/div")).click();
	}
	public void categories()
	{
	driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/nav[1]/div/span")).click();
	}
	public void nostalgia()
	{
	driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/nav[1]/div/div/div/div/div[3]/a[3]")).click();
	}
	public void datefrom() throws InterruptedException
	{
	driver.findElement(By.id("date-from")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[3]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[2]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"siee-cookie-bar-close\"]/span")).click();
	TimeUnit.SECONDS.sleep(3);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.id("apply-dates")).click();

	}
	public void dateto() throws InterruptedException
	{
	driver.findElement(By.id("date-to")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[3]/div[2]/div/div/div[2]/div[1]/div[2]/div[11]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[3]/div[2]/div/div/div[2]/div[2]/div[11]/div[2]/div[12]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.id("apply-dates")).click();
	}
	public void ZA() throws InterruptedException
	{
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div/div/div[2]/div[4]/div/div[2]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div/div/div[2]/div[4]/div/div[2]/nav/a[2]")).click();
	TimeUnit.SECONDS.sleep(3);
	}
	public void fpost()
	{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)");

	driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div/div[2]/div[1]/a/div[1]/div[3]/div")).click();
	}





}



