package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class ps_now1 extends wrapperclass
{

	public ps_now1(WebDriver driver) 
	{
		this.driver=driver;
	}
	public void click_on_ps_now()
	{
		driver.findElement(By.xpath("//*[@class=\"shared-nav__secondary-anchor shared-nav-anchor dtm-no-track shared-nav-link-icon shared-nav-link-icon--psnow\"]")).click();
	}
	public void click_on_watch()
	{
		driver.findElement(By.xpath("//*[@class=\"btn-secondary--dark btn-video link-btnnew ps-play\"]")).click();
	}
}
