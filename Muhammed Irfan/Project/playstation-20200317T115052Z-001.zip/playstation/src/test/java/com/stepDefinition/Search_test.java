package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.Search;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelRead;

public class Search_test extends wrapperclass
{
	Search obj=new Search(driver);
	@Given("^I Am on the Homepage$")
	public void i_Am_on_the_Homepage() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	    TimeUnit.SECONDS.sleep(5);
	}

	@When("^I Click on Hardware$")
	public void i_Click_on_Hardware() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj.hardware();
	}

	@When("^I Click on accessories$")
	public void i_Click_on_accessories() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj.access();
	}

	@When("^I Search media remotes$")
	public void i_Search_media_remotes() throws Exception {
		ExcelRead data=new ExcelRead();
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj.search(data.excel_search_data(1));
	}
	

	@When("^I Click on first link$")
	public void i_Click_on_first_link() throws Exception 
	{
		
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj.link();
	}

	@Then("^I Click on learn more$")
	public void i_Click_on_learn_more() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(5);
	    obj.more();
	    driver.quit();
	
	}


}
