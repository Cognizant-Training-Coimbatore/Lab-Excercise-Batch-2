package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.pages.Discount_rate;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Discount_rate_Test extends wrapperclass
{
Discount_rate rate=new Discount_rate(driver);

@Given("^Login in the Application$")
public void login_in_the_Application() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	launchApplication("chrome","https://www.playstation.com/en-us/");
	
	TimeUnit.SECONDS.sleep(5);
   
}

@When("^I click on Shop menu$")
public void i_click_on_Shop_menu() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 rate.click_shop();
}

@When("^I click on Digital Games and Services$")
public void i_click_on_Digital_Games_and_Services() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 rate.click_digital();
}

@When("^I click on Deals and Offers$")
public void i_click_on_Deals_and_Offers() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 
	 rate.click_offers();
}

@When("^I click on an Offer$")
public void i_click_on_an_Offer() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 rate.click_anyoffer();
	 
}

@When("^I select an Item$")
public void i_select_an_Item() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 rate.click_item();
}


@Then("^I should see the Timeperiod when the discount is available$")
public void i_should_see_the_Timeperiod_when_the_discount_is_available() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	 TimeUnit.SECONDS.sleep(5);
	 
	 JavascriptExecutor js = (JavascriptExecutor) driver;
     js.executeScript("window.scrollBy(0,700)");
     TimeUnit.SECONDS.sleep(4);
     extentreport(1);
     
	 screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\Discount_rate.jpg");
	 driver.quit();
	 
}



}
