package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.accessories;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Accessories_test extends wrapperclass
{
	accessories obj2=new accessories(driver);
	@Given("^I am on the home page$")
	public void i_am_on_the_home_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	    TimeUnit.SECONDS.sleep(5);
	}
	@When("^I click on Hardware button$")
	public void i_click_on_Hardware_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj2.hardware();
	}

	@When("^I click on Accessories button$")
	public void i_click_on_Accessories_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj2.access();
	}

	@When("^I click on Gaming controllers$")
	public void i_click_on_Gaming_controllers() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj2.game();
	}

	@When("^I click on Learn more$")
	public void i_click_on_Learn_more() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj2.learn();
	}

	@When("^I click on Explore more$")
	public void i_click_on_Explore_more() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj2.explore();
	    screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\playstation3.jpg");
	}

	@Then("^I validate the outcomes$")
	public void i_validate_the_outcomes() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		driver.quit();
	}

}
