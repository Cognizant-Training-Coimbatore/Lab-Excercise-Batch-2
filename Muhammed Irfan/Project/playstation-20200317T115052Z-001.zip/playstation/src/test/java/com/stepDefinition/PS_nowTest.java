package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.PSnow;


import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PS_nowTest extends wrapperclass
{
	PSnow obj=new  PSnow(driver);
	@Given("^open playstation$")
	public void open_playstation() throws Exception 
	{
		launchApplication("chrome", "https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(5);	
	}

	@When("^I click on Games$")
	public void i_click_on_Games() throws Exception
	{
		 obj.games();
		  TimeUnit.SECONDS.sleep(5);	
	}

	@When("^I click on Ps_now$")
	public void i_click_on_Ps_now() throws Exception 
	{
		obj.PS_now();
		   TimeUnit.SECONDS.sleep(5);	
	}

	@When("^I click on Ps_games$")
	public void i_click_on_Ps_games() throws Exception 
	{
		obj.PS_games();
		TimeUnit.SECONDS.sleep(5);	
	  
	}

	@When("^I click on First game$")
	public void i_click_on_First_game() throws Exception 
	{
		obj.fgame();
		TimeUnit.SECONDS.sleep(5);	
	   
	}

	@When("^I click on Buy$")
	public void i_click_on_Buy() throws Exception 
	{
		obj.buy();
		TimeUnit.SECONDS.sleep(5);	
	}

	@Then("^I click on Download$")
	public void i_click_on_Download() throws Exception 
	{
		obj.download();
		extentreport(1);
		TimeUnit.SECONDS.sleep(5);	
		quit();
	}


}
