package com.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;



public class accessories extends wrapperclass
{
	public accessories(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void hardware()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-hardware\"]")).click();
	}
	public void access()
	{
		driver.findElement(By.xpath("//*[@id=\"link-secondary--msg-accessories\"]")).click();
		
	}
	public void game()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div[2]/div[2]/div/div[1]/div[3]/div[2]/h3/a")).click();
		Set<String> allWindowHandles = driver.getWindowHandles();
		for(String handle : allWindowHandles)
		{
		driver.switchTo().window(handle);
		}


	}
	public void learn()
	{
	
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div/div[2]/div/div[2]/div[3]/div[2]/div[1]/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");

	}
	public void explore()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[1]/section/div[2]/div[2]/div/div/div[3]/div[2]/div[1]/a")).click();
	}

}
