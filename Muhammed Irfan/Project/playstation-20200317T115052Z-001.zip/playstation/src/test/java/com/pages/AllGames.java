package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;



public class AllGames extends wrapperclass
{
	public AllGames(WebDriver driver)
	{
		this.driver=driver;
	}
	public void click_games()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-games\"]")).click();
	}
	public void click_allgames()
	{
		driver.findElement(By.xpath("//*[@id=\"link-secondary--msg-all-games\"]")).click();
	}
	public void click_newrel()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div/ul/li[1]/a")).click();
	}
	public void click_call()
	{
		driver.findElement(By.xpath("//*[@id=\"newreleases\"]/div[2]/div[2]/div[2]/a/figure/picture/img")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement Element = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div[2]/div[2]/div/div[1]/div[2]/div/figure/a/picture/img"));		
        js.executeScript("arguments[0].scrollIntoView();", Element);
	}
	public void click_comsoon()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div/ul/li[2]/a")).click();
	}
	public void click_doom()
	{
		driver.findElement(By.xpath("//*[@id=\"comingsoon\"]/div[2]/div[2]/div[2]/a/figure/picture/img")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement Element = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/div[4]/div/div/div[2]/div/h1"));		
        js.executeScript("arguments[0].scrollIntoView();", Element);
	}
	public void click_allrel()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div/ul/li[3]/a")).click();
	}
	public void click_houseflipper()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[5]/section/div[2]/div[2]/div[2]/a/figure/picture/img")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement Element = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[3]/section/div/div[2]/div/div[2]/div[2]/div[2]/h3[2]/b/span"));		
        js.executeScript("arguments[0].scrollIntoView();", Element);
	}
}
