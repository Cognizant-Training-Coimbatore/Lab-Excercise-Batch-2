
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/com/features/cservice1.feature","src/test/resources/com/features/cservice2.feature",
		"src/test/resources/com/features/fHelp1.feature","src/test/resources/com/features/aAllgames.feature",
		"src/test/resources/com/features/aComp_centre.feature",
		"src/test/resources/com/features/aPSVR.feature","src/test/resources/com/features/bAccessories.feature",
		"src/test/resources/com/features/bGallery.feature","src/test/resources/com/features/bPS4.feature"
		,"src/test/resources/com/features/bSearch_product.feature","src/test/resources/com/features/dnews1.feature",
		"src/test/resources/com/features/bSearch_product.feature","src/test/resources/com/features/dnews2.feature",
		"src/test/resources/com/features/bSearch_product.feature","src/test/resources/com/features/aPS_now.feature",
		"src/test/resources/com/features/eDiscount_rate.feature","src/test/resources/com/features/eOrder_More.feature",
		"src/test/resources/com/features/aAAregister.feature"},glue= {"com.stepDefinition"})
public class testRunner {

}
