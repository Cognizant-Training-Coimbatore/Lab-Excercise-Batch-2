package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;


public class help_2 extends wrapperclass
{
	
	
	public help_2(WebDriver driver)
	{
	this.driver=driver;
	}
	public void click_on_help()
	{
	driver.findElement(By.id("menu-button-primary--msg-help")).click();
	}
	
	public void click_on_HelpAndSupport()
	{
	driver.findElement(By.id("link-secondary--msg-help-support")).click();
	}
	
	public void click_on_ACCOUNT_MANAGEMENT()
	{
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/header/div[3]/div[1]/span[2]/a")).click();
	}
	
	public void click_on_PS4_2_Step_Verification() throws InterruptedException, IOException
	{
	driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[5]/div/div/div/div/ul/li[3]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	
	
	 JavascriptExecutor js = (JavascriptExecutor) driver;
	 WebElement Element = driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[1]/div/div[1]"));
     js.executeScript("arguments[0].scrollIntoView();", Element);
	 TimeUnit.SECONDS.sleep(3);
	 //s2
	 screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\ss2.jpg");
 	 TimeUnit.SECONDS.sleep(3);
     
 	 WebElement Elemen = driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/div/div[3]/div/div/div[1]"));
     js.executeScript("arguments[0].scrollIntoView();", Elemen);
     TimeUnit.SECONDS.sleep(3);
     //s3
     screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\ss3.jpg");
 	 TimeUnit.SECONDS.sleep(3);
     
 	 WebElement Eleme = driver.findElement(By.xpath("//span[contains(text(),\"After 2-Step Verification Is Activated\") and @style=\"font-size: 28px;\"]"));
     js.executeScript("arguments[0].scrollIntoView();", Eleme);
     TimeUnit.SECONDS.sleep(3);
     //s4
     screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\ss4.jpg");
 	 TimeUnit.SECONDS.sleep(3);
 	 
 	
     }
	
	public void outcome() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(3);
	quit();
	}
	
}
