package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.Gallery;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Gallery_Test extends wrapperclass 
{
	Gallery obj3=new Gallery(driver);
	@Given("^I am on the Home Page$")
	public void i_am_on_the_Home_Page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	    TimeUnit.SECONDS.sleep(5);
	}

	@Given("^I click on Harware button$")
	public void i_click_on_Harware_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj3.hardware();
	}

	@Given("^I click on PS VR$")
	public void i_click_on_PS_VR() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj3.psvr();
	}

	@Given("^I click on gallery$")
	public void i_click_on_gallery() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj3.gallery();
	}

	@Given("^I click on view screenshots$")
	public void i_click_on_view_screenshots() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj3.scrnsht();
	}

	@Given("^I click on close gallery$")
	public void i_click_on_close_gallery() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj3.close();
	    screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\playstation4.jpg");
	}

	@Then("^I validate the Outcomes$")
	public void i_validate_the_Outcomes() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
	    driver.quit();
	}

}
