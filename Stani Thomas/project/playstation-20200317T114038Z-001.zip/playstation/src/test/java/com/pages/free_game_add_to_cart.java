package com.pages;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class free_game_add_to_cart extends wrapperclass
{
	public free_game_add_to_cart(WebDriver driver) 
	{
		this.driver=driver;
	}
	public void click_on_free_game()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div[1]/ul/li[2]/a")).click();
	}
	public void click_on_game() throws InterruptedException
	{
		Set<String> allWindowHandles = driver.getWindowHandles();
		for(String handle : allWindowHandles)
		{
			driver.switchTo().window(handle);
			TimeUnit.SECONDS.sleep(3);
		}
		driver.findElement(By.xpath("//*[@id=\"ember1027\"]")).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void click_on_add_to_cart()
	{
		driver.findElement(By.xpath("//*[@class=\"button expanded desktop-cta desktop-cta--add-to-cart desktop-cta--vertical-stack\"]")).click();
	}
}
