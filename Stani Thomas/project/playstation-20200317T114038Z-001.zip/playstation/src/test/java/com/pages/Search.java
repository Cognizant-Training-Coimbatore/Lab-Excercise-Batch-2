package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;


public class Search  extends wrapperclass
{
	public Search(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void hardware()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-hardware\"]")).click();
	}
	public void access()
	{
		driver.findElement(By.xpath("//*[@id=\"link-secondary--msg-accessories\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"shared-nav\"]/span/span/button")).click();
	}
	public void search(String a) throws InterruptedException
	{
	
		driver.findElement(By.xpath("/html/body/div[12]/div/div/div/div[2]/input")).sendKeys(a);
	}
	public void  link()
	{
		driver.findElement(By.xpath("/html/body/div[12]/div/div/div/button[2]")).click();
		driver.findElement(By.xpath("//a[@data-position=\"1\"]")).click();
	}
	public void more()
	{
		driver.findElement(By.xpath("//*[@id=\"twocolumnf2fc72ff_7a48_4a12_a825_19aac6ed2034\"]/div/div[2]/div/div/div[2]/div")).click();
	}
	public void close()
	{
		driver.quit();
	}
	
}
