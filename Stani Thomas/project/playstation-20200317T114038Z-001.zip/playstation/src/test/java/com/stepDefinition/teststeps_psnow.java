package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pages.add_to_cart_page;
import com.pages.ps_now1;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class teststeps_psnow extends wrapperclass
{
	add_to_cart_page add1= new add_to_cart_page(driver);
	ps_now1 pn= new ps_now1(driver);
	@Given("^I want to navigate to service menu$")
	public void i_want_to_navigate_to_service_menu() throws Exception 
	{
		launchApplication("chrome", "https://www.playstation.com/en-us");
	}

	@When("^I click on service bar$")
	public void i_click_on_service_bar() throws Exception 
	{
		add1.click_on_service();
	}

	@When("^I click on PS Now button$")
	public void i_click_on_PS_Now_button() throws Exception
	{
		pn.click_on_ps_now();
	}

	@When("^I click on watch trailer$")
	public void i_click_on_watch_trailer() throws Exception 
	{
		pn.click_on_watch();
		WebElement ifr=driver.findElement(By.xpath("//*[@class=\"lg-video-object lg-youtube lg-object\"]"));
		driver.switchTo().frame(ifr);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@class=\"ytp-large-play-button ytp-button\"]")).click();
		TimeUnit.MINUTES.sleep(1);
	}

	@Then("^The trailer is watched and print \"([^\"]*)\"$")
	public void the_trailer_is_watched_and_print(String arg1) throws Exception
	{
		extentreport(1);
		System.out.println(arg1);
		quit();
	}
}
