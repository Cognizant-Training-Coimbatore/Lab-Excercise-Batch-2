package com.excelUtility;



import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelutility 
{
	public String enter_firstname(int a) throws IOException {
		FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\project.xlsx"));
		
		XSSFWorkbook wbk=new XSSFWorkbook(fil);
		XSSFSheet sheet=wbk.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String fname=cell.getStringCellValue();
		System.out.println(fname);
		return fname;
		}
		public String enter_lastname(int b) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\project.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(1);
			String lname=cell.getStringCellValue();
			System.out.println(lname);
		    return lname;
		}
		public String enter_email(int c) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\project.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(c);
			XSSFCell cell=row.getCell(2);
			String mail=cell.getStringCellValue();
			System.out.println(mail);
		    return mail;
		}
		public String enter_pass(int d) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\project.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(d);
			XSSFCell cell=row.getCell(3);
			String password=cell.getStringCellValue();
			System.out.println(password);
		    return password;
		}
		public String enter_confirmpass(int e) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\project.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(e);
			XSSFCell cell=row.getCell(4);
			String cpassword=cell.getStringCellValue();
			System.out.println(cpassword);
		    return cpassword;
		}

}
