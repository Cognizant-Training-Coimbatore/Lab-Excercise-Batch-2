package com.excelUtility;



import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_email 
{
	public String enter_friendmail(int a) throws IOException {
		FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\email.xlsx"));
		
		XSSFWorkbook wbk=new XSSFWorkbook(fil);
		XSSFSheet sheet=wbk.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String fmail=cell.getStringCellValue();
		System.out.println(fmail);
		return fmail;
		}
		public String enter_yourmail(int b) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\email.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(1);
			String ymail=cell.getStringCellValue();
			System.out.println(ymail);
		    return ymail;
		}
		public String enter_message(int c) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\email.xlsx"));
			XSSFWorkbook wbk=	new XSSFWorkbook(fil);
			XSSFSheet sheet= wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(c);
			XSSFCell cell=row.getCell(2);
			String messg=cell.getStringCellValue();
			System.out.println(messg);
		    return messg;
		}

}
