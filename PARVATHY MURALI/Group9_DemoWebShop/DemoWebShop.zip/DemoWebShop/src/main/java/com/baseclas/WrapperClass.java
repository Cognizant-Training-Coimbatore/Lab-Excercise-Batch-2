package com.baseclas;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WrapperClass 
{
	protected WebDriver driver;
	static protected Logger log=Logger.getLogger(WrapperClass.class.getName());
	public void launch_Browser(String browser, String url) throws InterruptedException
	{
		try
		{// to browse in chrome
			if(browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\driver\\chromedriver.exe");
				driver=new ChromeDriver();
			}
			//to browse in firefox
			else if(browser.equalsIgnoreCase("firefox"))
			{
				System.setProperty("webdriver.gecko.driver","C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\driver\\chromedriver.exe");
				driver=new FirefoxDriver();
			}
			driver.manage().window().maximize();
			TimeUnit.SECONDS.sleep(3);
			driver.get(url);
		}
		catch(WebDriverException e )
		{
			System.out.println("browser could not be opened");
		}
	}
	//to take ScreenShot
	public void screenshot(String path ) throws IOException
	{
		TakesScreenshot ts=((TakesScreenshot)driver);
		File Source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Source, new File(path));
	}
	public void quit()
	{
		driver.quit();
	}
}
