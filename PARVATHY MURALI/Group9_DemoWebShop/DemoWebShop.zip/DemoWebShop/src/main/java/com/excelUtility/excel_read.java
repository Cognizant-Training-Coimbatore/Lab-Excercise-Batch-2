package com.excelUtility;





	
	import java.io.File;
	import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class excel_read
	{
		public String enter_firstname(int a) throws IOException {
			FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
			
			XSSFWorkbook wbk=new XSSFWorkbook(fil);
			XSSFSheet sheet=wbk.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
				XSSFRow row=sheet.getRow(a);
				XSSFCell cell=row.getCell(0);
				String fname=cell.getStringCellValue();
			System.out.println(fname);
			return fname;
			}
			public String enter_lastname(int b) throws IOException {
				FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
				XSSFWorkbook wbk=	new XSSFWorkbook(fil);
				XSSFSheet sheet= wbk.getSheet("Sheet1");
				int count=sheet.getLastRowNum();
				System.out.println(count);
				XSSFRow row=sheet.getRow(b);
				XSSFCell cell=row.getCell(1);
				String lname=cell.getStringCellValue();
				System.out.println(lname);
			    return lname;
			}
			public String enter_email(int c) throws IOException {
				FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
				XSSFWorkbook wbk=	new XSSFWorkbook(fil);
				XSSFSheet sheet= wbk.getSheet("Sheet1");
				int count=sheet.getLastRowNum();
				System.out.println(count);
				XSSFRow row=sheet.getRow(c);
				XSSFCell cell=row.getCell(2);
				String mail=cell.getStringCellValue();
				System.out.println(mail);
			    return mail;
			}
			public String enter_pass(int d) throws IOException {
				FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
				XSSFWorkbook wbk=	new XSSFWorkbook(fil);
				XSSFSheet sheet= wbk.getSheet("Sheet1");
				int count=sheet.getLastRowNum();
				System.out.println(count);
				XSSFRow row=sheet.getRow(d);
				XSSFCell cell=row.getCell(3);
				String password=cell.getStringCellValue();
				System.out.println(password);
			    return password;
			}
			public String enter_confirmpass(int e) throws IOException {
				FileInputStream fil=new FileInputStream(new File ("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
				XSSFWorkbook wbk=	new XSSFWorkbook(fil);
				XSSFSheet sheet= wbk.getSheet("Sheet1");
				int count=sheet.getLastRowNum();
				System.out.println(count);
				XSSFRow row=sheet.getRow(e);
				XSSFCell cell=row.getCell(4);
				String cpassword=cell.getStringCellValue();
				System.out.println(cpassword);
			    return cpassword;
			}
			    public String excel_username(int a) throws IOException
				{
					FileInputStream fil=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
					XSSFWorkbook workbook=new XSSFWorkbook(fil);
					XSSFSheet sheet=workbook.getSheet("login");
					int count=sheet.getLastRowNum();
					System.out.println(count);
					
					XSSFRow row=sheet.getRow(a);  
					XSSFCell cell= row.getCell(0);
					String un=cell.getStringCellValue();
					return un;
					
				}
				//to read and return password
				public String excel_pwd(int b) throws IOException
				{
					FileInputStream fil=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
					XSSFWorkbook workbook=new XSSFWorkbook(fil);
					XSSFSheet sheet=workbook.getSheet("login");
					int count=sheet.getLastRowNum();
					System.out.println(count);
					
					XSSFRow row=sheet.getRow(b);
					XSSFCell cell= row.getCell(1);
					String un=cell.getStringCellValue();
					return un;
					
				}
				public String excel_username1(int a) throws IOException
				{
					FileInputStream fil=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
					XSSFWorkbook workbook=new XSSFWorkbook(fil);
					XSSFSheet sheet=workbook.getSheet("Sheet1");
					int count=sheet.getLastRowNum();
					System.out.println(count);
					
					XSSFRow row=sheet.getRow(a);  
					XSSFCell cell= row.getCell(0);
					String un=cell.getStringCellValue();
					return un;
					
				}
				//to read and return password
				public String excel_pwd1(int b) throws IOException
				{
					FileInputStream fil=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
					XSSFWorkbook workbook=new XSSFWorkbook(fil);
					XSSFSheet sheet=workbook.getSheet("Sheet1");
					int count=sheet.getLastRowNum();
					System.out.println(count);
					
					XSSFRow row=sheet.getRow(b);
					XSSFCell cell= row.getCell(1);
					String un=cell.getStringCellValue();
					return un;
				}
					public String excel_pwd2(int b) throws IOException
					{
						FileInputStream fil=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx"));
						XSSFWorkbook workbook=new XSSFWorkbook(fil);
						XSSFSheet sheet=workbook.getSheet("Sheet1");
						int count=sheet.getLastRowNum();
						System.out.println(count);
						
						XSSFRow row=sheet.getRow(b);
						XSSFCell cell= row.getCell(2);
						String un=cell.getStringCellValue();
						return un;		

	}
					public  void ex1(String value)throws IOException{
						String path = "C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx";
						FileInputStream fis = new FileInputStream(path);
					    XSSFWorkbook workbook = new XSSFWorkbook(fis);
						XSSFSheet sheet = workbook.getSheetAt(0);
						XSSFRow row = sheet.createRow(1);
						XSSFCell cell = row.createCell(3);
						cell.setCellValue(value);
						FileOutputStream fos = new FileOutputStream(path);
						workbook.write(fos);
						fos.close();
	}
					public  void ex2(String value)throws IOException{
						String path = "C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\testdata\\jewelry.xlsx";
						FileInputStream fis = new FileInputStream(path);
					    XSSFWorkbook workbook = new XSSFWorkbook(fis);
						XSSFSheet sheet = workbook.getSheetAt(0);
						XSSFRow row = sheet.createRow(1);
						XSSFCell cell = row.createCell(4);
						cell.setCellValue(value);
						FileOutputStream fos = new FileOutputStream(path);
						workbook.write(fos);
						fos.close();		
}
	}