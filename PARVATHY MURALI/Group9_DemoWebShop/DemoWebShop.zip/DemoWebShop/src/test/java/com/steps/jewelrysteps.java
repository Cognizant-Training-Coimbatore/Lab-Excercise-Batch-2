package com.steps;



import com.baseclas.WrapperClass;
import com.excelUtility.excel_read;
import com.main.Demojewelry;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jewelrysteps extends WrapperClass {

@Given("^The site should be open$")
public void the_site_should_be_open() throws Throwable {
	launch_Browser("chrome", "http://demowebshop.tricentis.com/");
}

@Given("^Log in button clicked$")
public void log_in_button_clicked() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
    ob.login();
}

@Given("^Username and password is entered$")
public void username_and_password_is_entered() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
    excel_read dat=new excel_read();
    ob.email(dat.excel_username1(0));
	ob.password(dat.excel_pwd1(0));
}

@When("^Click log in button$")
public void click_log_in_button() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.log();
}

@Then("^Navigated to home page$")
public void navigated_to_home_page() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\1.png");
}

@When("^Select jewelry from sub sections$")
public void select_jewelry_from_sub_sections() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.jewe(); 
    
}

@Then("^Products are displayed$")
public void products_are_displayed() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\11.png");
}

@When("^Select sort by drop down box$")
public void select_sort_by_drop_down_box() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.sortby();
}

@Then("^Select high to low$")
public void select_high_to_low() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\22.png");
}

@Then("^Select  Name:A to Z$")
public void select_Name_A_to_Z() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.sort();
}

@When("^select display drop down box$")
public void select_display_drop_down_box() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	   ob.sort1();
}

@Then("^select (\\d+)$")
public void select(int arg1) throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\2.png");
	   
}

@When("^select view as drop down box$")
public void select_view_as_drop_down_box() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	   ob.sort2();
}

@Then("^select grid$")
public void select_grid() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\3.png");

}

@Then("^select list$")
public void select_list() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	   ob.sort3();
		
}

@When("^Selecting a product$")
public void selecting_a_product() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.click();

}

@When("^Clicking add to cart$")
public void clicking_add_to_cart() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.add1();
}

@Then("^Product has been added to cart$")
public void product_has_been_added_to_cart() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\4.png");
}

@When("^Clicking add to wishlist$")
public void clicking_add_to_wishlist() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.wish1(); 
    
}

@Then("^product has been added to wishlist$")
public void product_has_been_added_to_wishlist() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\wishlist.png");

}

@When("^Selecting email a friend$")
public void selecting_email_a_friend() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.mail();
}

@When("^Enter frinds email$")
public void enter_frinds_email() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	excel_read dat=new excel_read();
	ob.frmail(dat.excel_pwd2(0));
}

@When("^Clickn on send email button$")
public void clickn_on_send_email_button() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.fbutton();
   
}

@Then("^Email has been sent$")
public void email_has_been_sent() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\5.png");
	   

}

@Given("^select shopping cart$")
public void select_shopping_cart() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.cart1();
}

@When("^select check out$")
public void select_check_out() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.box1();
	ob.check();
}

@When("^select continue for billing address$")
public void select_continue_for_billing_address() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.co1();
}

@When("^select continue for shipping address$")
public void select_continue_for_shipping_address() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.co2();
	ob.co3();
}

@When("^select continue for payment method$")
public void select_continue_for_payment_method() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.co4();
}

@When("^select continue for payment information$")
public void select_continue_for_payment_information() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.co5();
}

@When("^select confirm$")
public void select_confirm() throws Throwable {
	Demojewelry ob=new Demojewelry(driver);
	ob.conf();
}

@Then("^Order has been confirmed$")
public void order_has_been_confirmed() throws Throwable {
	screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\6.png");
	driver.quit();
}



}
