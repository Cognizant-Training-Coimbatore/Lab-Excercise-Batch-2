package com.steps;

import com.baseclas.WrapperClass;
import com.excelUtility.excelLogin;
import com.main.DemoLogin;
import com.main.Demodesktop;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class module1ComputerDesktopsteps extends WrapperClass
{

	
	@Given("^the DemoWebShop is Launched$")
	public void the_DemoWebShop_is_Launched() throws Exception 
	{
		
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();
	}
	
	@When("^the user select the Desktop  category from computer$")
	public void the_user_select_the_Desktop_category_from_computer() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.computerclick(); 
	}
	
	@When("^Select Sort By,Filter, Dispaly, View properties$")
	public void select_Sort_By_Filter_Dispaly_View_properties() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.sortNameAtoZ();
		dd.filterover1200();
		dd.viewlist();
		dd.display4(); 
	}
	
	@When("^click on the product to purchase$")
	public void click_on_the_product_to_purchase() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.selectProduct();
	}
	
	@When("^give all the product specification$")
	public void give_all_the_product_specification() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.setProductProperties();
	}
	
	@Then("^click on add to cart button$")
	public void click_on_add_to_cart_button() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.AddtoCart();
		log.info("added to cart");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\desktop\\desktopsucessfulladdtocart.jpg");
		quit();
	}
	@Given("^the DemoWebShop site is Launched$")
	public void the_DemoWebShop_site_is_Launched() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();
		
	}

	@When("^the user select the Desktop category from computer$")
	public void the_user_select_the_Desktop_category_from_computer3() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.computerclick(); 
	}
	@When("^Select Sort By,Filter,Dispaly, View properties from the webpage$")
	public void select_Sort_By_Filter_Dispaly_View_properties_from_the_webpage() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver); 
		dd.sortNameAtoZ();
		dd.filterover1200();
		dd.viewlist();
		dd.display4(); 
	}

	@When("^click on the product to buy$")
	public void click_on_the_product_to_buy() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.selectProduct();
	}

	@When("^give all the specification of the product$")
	public void give_all_the_specification_of_the_product() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.setProductProperties();
	}

	@Then("^click on email a friend button$")
	public void click_on_email_a_friend_button() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.emailToFriend();
		log.info("emailed to friend");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\desktop\\emailtofriend.jpg");
		quit();
	}

	@Given("^Launch the DemoWebshop Site$")
	public void launch_the_DemoWebshop_Site() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();
		 
	}

	@When("^Select SortBy, Filter, Dispaly, View properties from the navigated page$")
	public void select_SortBy_Filter_Dispaly_View_properties_from_the_navigated_page() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.computerclick(); 
		dd.sortNameAtoZ();
		dd.filterover1200();
		dd.viewlist();
		dd.display4(); 
	}

	@When("^click on the product to buy it$")
	public void click_on_the_product_to_buy_it() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.selectProduct();
	}

	@When("^give all the specifications$")
	public void give_all_the_specifications() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.setProductProperties();
	}

	@Then("^click on Add to compare list button$")
	public void click_on_Add_to_compare_list_button() throws Exception
	{
		Demodesktop dd=new Demodesktop(driver);
		dd.AddToCompareList();
		log.info("added to compare list");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\desktop\\addtocompare.jpg");
		quit();
	}


}
