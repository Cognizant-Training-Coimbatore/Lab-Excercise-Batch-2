package com.main;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Apparels_and_Shoes {
	WebDriver driver;
		public Apparels_and_Shoes(WebDriver driver) {
			this.driver = driver;
		}
	
	public void click_on_apparels_and_shoes() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		driver.findElement(By.id("Email")).sendKeys("shilpa.niravilpuzha@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("india12345");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[4]/a")).click();
		}
	public void add_to_cart_an_item() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-5\"]")).click();
		}
	public void size_and_colour_change_item() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[2]/h2/a")).click();
		Select size = new Select(driver.findElement(By.id("product_attribute_28_7_10")));
		size.selectByVisibleText("10");
		driver.findElement(By.xpath("//*[@id=\"color-squares-11\"]/li[2]/label/span/span")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-28\"]")).click();
	}
	public void sort_by_Name() {
		Select sortby = new Select(driver.findElement(By.id("products-orderby")));
		sortby.selectByVisibleText("Name: A to Z");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[3]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-36\"]")).click();
	}
	public void display_per_page_change() {
		Select display = new Select(driver.findElement(By.id("products-pagesize")));
		display.selectByVisibleText("12");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[4]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-40\"]")).click();
	}
	public void view_as_change() {
		Select viewas = new Select(driver.findElement(By.id("products-viewmode")));
		viewas.selectByVisibleText("List");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-5\"]")).click();
	}
	public void add_to_wish_list() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"add-to-wishlist-button-28\"]")).click();
	}
	public void add_to_compare_list() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[9]/input")).click();
	}
	public void email_a_friend() {
		driver.findElement(By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[8]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"FriendEmail\"]")).sendKeys("shilpamohan5@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"PersonalMessage\"]")).sendKeys("Hello Good Morning");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/form/div[3]/input")).click();
	}
	public void quantity_change() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a")).click();
		driver.findElement(By.id("addtocart_5_EnteredQuantity")).sendKeys(Keys.BACK_SPACE);
		driver.findElement(By.id("addtocart_5_EnteredQuantity")).sendKeys("2");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-5\"]")).click();
	}
	public void buy_an_item()
	{
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a")).click();
		driver.findElement(By.id("add-to-cart-button-5")).click();
		driver.findElement(By.linkText("Shopping cart")).click();
		Select country = new Select(driver.findElement(By.id("CountryId")));
		country.selectByVisibleText("India");
		driver.findElement(By.id("ZipPostalCode")).sendKeys("641035");
		driver.findElement(By.id("termsofservice")).click();
		driver.findElement(By.id("checkout")).click();
	}
	
}
