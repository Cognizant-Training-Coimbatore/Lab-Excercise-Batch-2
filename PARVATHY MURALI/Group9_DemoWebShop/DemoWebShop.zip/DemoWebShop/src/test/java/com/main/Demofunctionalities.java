package com.main;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Demofunctionalities {
	WebDriver driver;
	public Demofunctionalities(WebDriver driver)
	{
		this.driver=driver;
	}
	By lo=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By email=By.id("Email");
	By pass=By.id("Password");
	By login=By.xpath("//*[@value=\"Log in\"]");
	By tri=By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[2]/div[2]/ul/li/a");
	By viewall=By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[3]/div[2]/div[2]/a");
	By news=By.id("newsletter-email");
	By button=By.id("newsletter-subscribe-button");
	
	public void login()
	{
		driver.findElement(lo).click();
	}
	public void email(String value) throws InterruptedException
	{
		driver.findElement(email).sendKeys(value);
	}
	public void password(String val) throws InterruptedException
	{
		driver.findElement(pass).sendKeys(val);
	}
	public void log() throws InterruptedException
	{
		driver.findElement(login).click();
	}
	public void manufacture() throws InterruptedException
	{
		driver.findElement(tri).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void populattag() throws InterruptedException
	{
		driver.findElement(viewall).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void newsletter(String value) throws InterruptedException
	{
		driver.findElement(news).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
	}
	public void subscribe() throws InterruptedException
	{
		driver.findElement(button).click();
		TimeUnit.SECONDS.sleep(3);
	
	}
}
