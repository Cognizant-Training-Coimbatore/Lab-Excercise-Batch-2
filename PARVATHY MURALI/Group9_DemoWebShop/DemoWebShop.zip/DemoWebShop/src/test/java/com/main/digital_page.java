package com.main;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class digital_page {

	WebDriver driver;
	public digital_page(WebDriver driver) {
	this.driver = driver;
	}
	
	
	public void login_to_the_website() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
		public void click_login1() {
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		}
		public void type_email() {
		driver.findElement(By.id("Email")).sendKeys("sanilsunder97@gmail.com");	
	}
		public void type_password() {
		driver.findElement(By.id("Password")).sendKeys("sanilsasna");
		}
		
		public void click_login2() {
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();	
		}
	

	public void click_on_digital() {
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[5]/a")).click();
	}
	public void add_to_cart() {
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a")).click();
	driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-53\"]")).click();
	}
	
	public void qty_change() {
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[2]/h2/a")).click();
	driver.findElement(By.id("addtocart_51_EnteredQuantity")).sendKeys(Keys.BACK_SPACE);;
	driver.findElement(By.id("addtocart_51_EnteredQuantity")).sendKeys("2");
	driver.findElement(By.id("add-to-cart-button-51")).click();
		
	}
	
	public void add_to_wishlist() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[3]/div/div[2]/h2/a")).click();
		driver.findElement(By.id("add-to-wishlist-button-52")).click();		
	}
	
	public void email_a_friend() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[3]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[7]/input")).click();
		driver.findElement(By.id("FriendEmail")).sendKeys("sanilsunder97@gmail.com");
		driver.findElement(By.id("PersonalMessage")).sendKeys("buy book");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/form/div[3]/input")).click();
	}


	public void compare_list() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[2]/h2/a")).click();
		driver.findElement(By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[8]/input")).click();
	}
		
	public void properties1() {
		Select prop1 = new Select(driver.findElement(By.id("products-orderby")));
		prop1.selectByVisibleText("Name: A to Z");
		
		Select prop2 = new Select(driver.findElement(By.xpath("//*[@id=\"products-pagesize\"]")));
		prop2.selectByVisibleText("4");
		
		Select prop3 = new Select(driver.findElement(By.xpath("//*[@id=\"products-viewmode\"]")));
		prop3.selectByVisibleText("List");
	}
	
	public void buy_now() {
		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"termsofservice\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"payment-method-buttons-container\"]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"payment-info-buttons-container\"]/input")).click();
		driver.findElement(By.xpath("//*[@id=\"confirm-order-buttons-container\"]/input")).click();
	}
		
	}
	

	
