package com.main;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Reg_page 
{
	WebDriver driver;
	public Reg_page(WebDriver driver)
	{
		this.driver=driver;
	}
	By register=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	By gender=By.xpath("//*[@id=\"gender-male\"]");
	By female=By.xpath("//*[@id=\"gender-female\"]");
	By fname=By.xpath("//*[@id=\"FirstName\"]");
	By lname=By.xpath("//*[@id=\"LastName\"]");
	By mail=By.xpath("//*[@id=\"Email\"]");
	By password=By.xpath("//*[@id=\"Password\"]");
	By cpassword=By.xpath("//*[@id=\"ConfirmPassword\"]");
	By lastreg=By.xpath("//*[@id=\"register-button\"]");
	
	//By click=By.xpath("//*[@id=\"register-button\"]");
	/*By first=By.xpath("//*[@id=\"FirstName\"]");
	By last=By.xpath("//*[@id=\"LastName\"]");*/
	public void reg() throws InterruptedException
	{
		driver.findElement(register).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void button() throws InterruptedException
	{
		driver.findElement(gender).click();
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void first(String value) throws InterruptedException
	{
		driver.findElement(fname).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void last(String value) throws InterruptedException
	{
		driver.findElement(lname).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void email(String value) throws InterruptedException
	{
		driver.findElement(mail).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void pass(String value) throws InterruptedException
	{
		driver.findElement(password).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void confirm(String value) throws InterruptedException
	{
		driver.findElement(cpassword).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
		
	}
	
	public void reglast() throws InterruptedException 
	{
		driver.findElement(lastreg).click();
		TimeUnit.SECONDS.sleep(5);
		
	}
	public void femselect() throws InterruptedException
	{
		driver.findElement(female).click();
		TimeUnit.SECONDS.sleep(5);
	}

}
