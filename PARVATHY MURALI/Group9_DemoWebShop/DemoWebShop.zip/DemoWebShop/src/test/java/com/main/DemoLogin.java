package com.main;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class DemoLogin 
{
	WebDriver driver;
	public DemoLogin(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By login=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By username=By.xpath("//*[@id=\"Email\"]");
	By password=By.xpath("//*[@id=\"Password\"]");
	By loginbtn=By.xpath("//*[@value=\"Log in\"]");
	
	 
	
	
		public void click() throws InterruptedException
		{
		driver.findElement(login).click();
		TimeUnit.SECONDS.sleep(2);
		}
		public void usernam(String user) throws InterruptedException
		{
		driver.findElement(username).sendKeys(user);
		TimeUnit.SECONDS.sleep(2);
		}
		public void pass(String pwd) throws InterruptedException
		{
		driver.findElement(password).click();
		driver.findElement(password).sendKeys(pwd);
		TimeUnit.SECONDS.sleep(2);
		}
	
	public void loginbtn() throws InterruptedException 
	{
		driver.findElement(loginbtn).click();
		TimeUnit.SECONDS.sleep(2);
	}

	
}	

