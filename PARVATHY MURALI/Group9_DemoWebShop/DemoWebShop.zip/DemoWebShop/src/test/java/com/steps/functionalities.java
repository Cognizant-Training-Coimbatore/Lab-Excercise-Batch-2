package com.steps;

import com.baseclas.WrapperClass;
import com.excelUtility.excel_read;
import com.main.Demofunctionalities;

import java.util.concurrent.TimeUnit;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class functionalities extends WrapperClass {
	ExtentReports report =new ExtentReports("ReportJewelry.html");
	ExtentTest test=report.startTest("Extended_reports");
	@Given("^The site is open and log in clicked$")
	public void the_site_is_open_and_log_in_clicked() throws Throwable 
	{
	    launch_Browser("chrome", "http://demowebshop.tricentis.com/");
	    Demofunctionalities ob=new Demofunctionalities(driver);
	    ob.login();
	}

	@When("^Enter username and password$")
	public void enter_username_and_password() throws Throwable {
		excel_read dat=new excel_read();
		Demofunctionalities ob=new Demofunctionalities(driver);
	    ob.email(dat.excel_username1(0));
		ob.password(dat.excel_pwd1(0));
	}

	@Then("^Click log in$")
	public void click_log_in() throws Throwable {
		Demofunctionalities ob=new Demofunctionalities(driver);
		ob.log();
		log.info("Account is logged in");
	}

	@When("^click on tricentis under manufactures$")
	public void click_on_tricentis_under_manufactures() throws Throwable {
		Demofunctionalities ob=new Demofunctionalities(driver);
		ob.manufacture();
		driver.navigate().back();
		log.info("Manufactures is selected");
		
	}

	@Then("^Details are displayed$")
	public void details_are_displayed() throws Throwable {
	    screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\manufactures.png");
	}

	@When("^click on view all$")
	public void click_on_view_all() throws Throwable {
		Demofunctionalities ob=new Demofunctionalities(driver);
		ob.populattag();
	}

	@Then("^popular tags are displayed$")
	public void popular_tags_are_displayed() throws Throwable {
		screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\populartags.png");
	log.info("Popular tags are displayed");}

	@When("^Enter mailid for subscription$")
	public void enter_mailid_for_subscription() throws Throwable {
		Demofunctionalities ob=new Demofunctionalities(driver);
		excel_read dat=new excel_read();
		ob.newsletter(dat.excel_pwd2(0));

	}

	@Then("^Mail id has been added for subscription$")
	public void mail_id_has_been_added_for_subscription() throws Throwable {
		Demofunctionalities ob=new Demofunctionalities(driver);
		ob.subscribe();
		TimeUnit.SECONDS.sleep(3);
		log.info("Subscription successful");

	}
	
	@Then("^The vote is registered$")
	public void the_vote_is_registered() throws Throwable {
		 screenshot("C:\\Users\\admin\\Desktop\\Selenium\\DemoProject\\src\\test\\resources\\com\\screenshots\\communitypoll.png");
		 driver.quit();
		 log.info("Vote registered");
		 excel_read dat=new excel_read();
		 dat.ex2("Pass");
			}



}
