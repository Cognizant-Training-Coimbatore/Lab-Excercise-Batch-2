package com.main;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Demojewelry {
	protected WebDriver driver;
	public Demojewelry(WebDriver driver)
	{
		this.driver=driver;
	}
	By lo=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By email=By.id("Email");
	By pass=By.id("Password");
	By login=By.xpath("//*[@value=\"Log in\"]");
	By jew=By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[6]/a");
	By page=By.id("products-pagesize");
	By view=By.id("products-viewmode");
	By product=By.linkText("Black & White Diamond Heart");
	By add=By.id("add-to-cart-button-14");
	By wish=By.xpath("//*[@id=\"add-to-wishlist-button-14\"]");
	By mailfr=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[8]/input");
	By fm=By.id("FriendEmail");
	By fb=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/form/div[3]/input");
	By cart=By.xpath("//*[@id=\"topcartlink\"]/a/span[1]");
	By box=By.id("termsofservice");
	By checkout=By.id("checkout");
	By con1=By.xpath("//*[@id=\"billing-buttons-container\"]/input");
	By con2=By.xpath("//*[@id=\"shipping-buttons-container\"]/input");
	By con3=By.xpath("//*[@id=\"shipping-method-buttons-container\"]/input");
	By con4=By.xpath("//*[@id=\"payment-method-buttons-container\"]/input");
	By con5=By.xpath("//*[@id=\"payment-info-buttons-container\"]/input");
	By confirm=By.xpath("//*[@id=\"confirm-order-buttons-container\"]/input");
	
	public void login()
	{
		driver.findElement(lo).click();
	}
	public void email(String value) throws InterruptedException
	{
		driver.findElement(email).sendKeys(value);
	}
	public void password(String val) throws InterruptedException
	{
		driver.findElement(pass).sendKeys(val);
	}
	public void log() throws InterruptedException
	{
		driver.findElement(login).click();
	}
	public void jewe()throws InterruptedException
	{
		driver.findElement(jew).click();
		
	}
	public void sortby() throws InterruptedException
	{
		Select combo2=new Select(driver.findElement(By.id("products-orderby")));
		combo2.selectByVisibleText("Price: High to Low");
	}
	
	public void sort() throws InterruptedException
	{
		Select combo2=new Select(driver.findElement(By.id("products-orderby")));
		combo2.selectByVisibleText("Name: A to Z");
	}
	public void sort1() throws InterruptedException
	{
		Select combo2=new Select(driver.findElement(page));
		combo2.selectByVisibleText("12");
	}
	public void sort2() throws InterruptedException
	{
		Select combo2=new Select(driver.findElement(view));
		combo2.selectByVisibleText("Grid");
	}
	public void sort3() throws InterruptedException
	{
		Select combo2=new Select(driver.findElement(view));
		combo2.selectByVisibleText("List");
	}
	public void click() throws InterruptedException
	{
		driver.findElement(product).click();
	}
	public void add1() throws InterruptedException
	{
		driver.findElement(add).click();
	}
	public void wish1() throws InterruptedException
	{
		driver.findElement(wish).click();
	}
	public void mail () throws InterruptedException
	{
		driver.findElement(mailfr).click();
		
		
	}
	public void frmail(String value) throws InterruptedException
	{
		driver.findElement(fm).sendKeys(value);
	}
	public void fbutton() throws InterruptedException
	{
		driver.findElement(fb).click();
	}
	public void cart1() throws InterruptedException
	{
		driver.findElement(cart).click();
	}
	public void box1() throws InterruptedException
	{
		driver.findElement(box).click();
	}
	public void check() throws InterruptedException
	{
		driver.findElement(checkout).click();
	}
	public void co1() throws InterruptedException
	{
		driver.findElement(con1).click();
	}
	public void co2() throws InterruptedException
	{
		driver.findElement(con2).click();
	}
	public void co3() throws InterruptedException
	{
		driver.findElement(con3).click();
	}
	public void co4() throws InterruptedException
	{
		driver.findElement(con4).click();
	}
	public void co5() throws InterruptedException
	{
		driver.findElement(con5).click();
	}
	public void conf() throws InterruptedException
	{
		driver.findElement(confirm).click();
	}
	
}
