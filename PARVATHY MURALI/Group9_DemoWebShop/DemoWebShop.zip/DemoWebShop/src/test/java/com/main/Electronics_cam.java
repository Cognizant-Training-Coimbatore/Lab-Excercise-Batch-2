package com.main;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Electronics_cam 
{
	WebDriver driver;
	public Electronics_cam(WebDriver driver)
	{
		this.driver=driver;
	}
	 By cam=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/ul/li[1]/a");
	 By phone=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/ul/li[2]/a");
	 By select=By.xpath("//*[@id=\"products-orderby\"]");
	 By page=By.xpath("//*[@id=\"products-pagesize\"]");
	 By grid=By.xpath("//*[@id=\"products-viewmode\"]");
	 By phone_image=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[2]/div/div[1]/a/img");
	///html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[1]/a/img
	 By phone_htol=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[1]/a/img");
	 By phone_ltoh=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[3]/div/div[1]/a/img");
	 By under=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[1]/a");
	 By over=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[2]/a");
	 By undercam=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div/div/div[1]/a/img");
	 By overcam=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[1]/a/img");
	 By compare=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[8]/input");
	 By cart=By.xpath("//*[@id=\"add-to-cart-button-43\"]");
	 By wishlist=By.xpath("//*[@id=\"add-to-wishlist-button-43\"]");
	 
	 
	 By fmail=By.xpath("//*[@id=\"FriendEmail\"]");
	 By ymail=By.xpath("//*[@id=\"YourEmailAddress\"]");
	 By messg=By.xpath("//*[@id=\"PersonalMessage\"]");
	 By send=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/form/div[3]/input");
	 By mail=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[7]/input");
	 By lookcart=By.xpath("//*[@id=\"topcartlink\"]/a/span[1]");
	 By wishclick=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[4]/a/span[1]");
	 By addtick=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div[1]/form/table/tbody/tr/td[2]/input");
	 By updatewish=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div[1]/form/div/div/input[1]");
	 By cartclick=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div[1]/form/div/div/input[2]");
	 By country=By.xpath("//*[@id=\"CountryId\"]");
	 By state=By.xpath("//*[@id=\"StateProvinceId\"]");
	 By zip=By.xpath("//*[@id=\"ZipPostalCode\"]");
	 By estimate=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[2]/div[1]/div[2]/div/div[3]/div[4]/input");
	 By agree=By.xpath("//*[@id=\"termsofservice\"]");
	 By checkout=By.xpath("//*[@id=\"checkout\"]");
	 By remove=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div[1]/form/table/tbody/tr/td[1]/input");
	 By cartupdate=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[1]/div/input[1]");
	 By contin=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[1]/div/input[2]");
	 public void computers() throws InterruptedException
	{
		Actions action=new Actions(driver);
		WebElement electron=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/a"));
		action.moveToElement(electron).build().perform();
		driver.findElement(cam).click();
		TimeUnit.SECONDS.sleep(3);
	}
	 public void computer_phone() throws InterruptedException
	 {
		 Actions action=new Actions(driver);
		 WebElement electron=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/a"));
	     action.moveToElement(electron).build().perform();
		 driver.findElement(phone).click();
		 TimeUnit.SECONDS.sleep(3);
	 }
	 public void created() throws InterruptedException
	 {
		 Select create=new Select(driver.findElement(select));
		 create.selectByVisibleText("Created on");
		 TimeUnit.SECONDS.sleep(3); 
	 }
	public void AtoZ() throws InterruptedException
	{
		Select atoz=new Select(driver.findElement(select));
		atoz.selectByVisibleText("Name: A to Z");
		TimeUnit.SECONDS.sleep(3);
	}
	public void display() throws InterruptedException
	{
		Select display=new Select(driver.findElement(page));
		display.selectByVisibleText("4");
		TimeUnit.SECONDS.sleep(3);
	}
	public void view() throws InterruptedException
	{
		Select display=new Select(driver.findElement(grid));
		display.selectByVisibleText("Grid");
		TimeUnit.SECONDS.sleep(3);
	}
	public void filter() throws InterruptedException
	{
		driver.findElement(under).click();
		TimeUnit.SECONDS.sleep(3);
		
		
	}
	public void navigate() throws InterruptedException 
	{
		driver.findElement(undercam).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void ZtoA() throws InterruptedException
	{
		Select atoz=new Select(driver.findElement(select));
		atoz.selectByVisibleText("Name: Z to A");
		TimeUnit.SECONDS.sleep(3);
	}
	public void lowtohigh() throws InterruptedException
	{
		Select low=new Select(driver.findElement(select));
		low.selectByVisibleText("Price: Low to High");
		TimeUnit.SECONDS.sleep(3);
		
	}
	public void hightolow() throws InterruptedException
	{
		Select high=new Select(driver.findElement(select));
		high.selectByVisibleText("Price: High to Low");
		TimeUnit.SECONDS.sleep(3);
	}
	public void diplay1() throws InterruptedException
	{
		Select display=new Select(driver.findElement(page));
		display.selectByVisibleText("8");
		TimeUnit.SECONDS.sleep(3);
	}
	public void diplay2() throws InterruptedException
	{
		Select display=new Select(driver.findElement(page));
		display.selectByVisibleText("12");
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void view1() throws InterruptedException
	{
		Select display=new Select(driver.findElement(grid));
		display.selectByVisibleText("List");
		TimeUnit.SECONDS.sleep(3);
	}
	public void filter1() throws InterruptedException
	{
		driver.findElement(over).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void navigate1() throws InterruptedException
	{
		driver.findElement(overcam).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void addcompare() throws InterruptedException
	{
		driver.findElement(compare).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void phone_navigate() throws InterruptedException
	{
		driver.findElement(phone_image).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void phone_htol_navigate() throws InterruptedException
	{
		driver.findElement(phone_htol).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void phone_ltoh_navigate() throws InterruptedException
	{
		driver.findElement(phone_ltoh).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void addcart() throws InterruptedException
	{
		driver.findElement(cart).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void addwishlist() throws InterruptedException
	{
		driver.findElement(wishlist).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void lookshopcart() throws InterruptedException
	{
		driver.findElement(lookcart).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void email() throws InterruptedException
	{
		driver.findElement(mail).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void friendemail(String value) throws InterruptedException
	{
		driver.findElement(fmail).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
	}
	public void youremail(String value) throws InterruptedException
	{
		driver.findElement(ymail).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
	}
	public void message(String value) throws InterruptedException
	{
		driver.findElement(messg).sendKeys(value);
		TimeUnit.SECONDS.sleep(3);
	}
	public void emailsend() throws InterruptedException
	{
		driver.findElement(send).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void wish() throws InterruptedException
	{
		driver.findElement(wishclick).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void addtick() throws InterruptedException
	{
		driver.findElement(addtick).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void updatewish() throws InterruptedException
	{
		driver.findElement(updatewish).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void cartclick() throws InterruptedException
	{
		driver.findElement(cartclick).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void country() throws InterruptedException
	{
		Select cntry=new Select(driver.findElement(country));
		cntry.selectByVisibleText("United States");
		TimeUnit.SECONDS.sleep(3);
	}
	public void state() throws InterruptedException
	{
		Select st=new Select(driver.findElement(state));
		st.selectByVisibleText("Ohio");
		TimeUnit.SECONDS.sleep(3);
	}
	public void zip() throws InterruptedException
	{
		driver.findElement(zip).sendKeys("683561");
		TimeUnit.SECONDS.sleep(3);
	}
	public void estimate() throws InterruptedException
	{
		driver.findElement(estimate).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void agree() throws InterruptedException
	{
		driver.findElement(agree).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void checkout() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.findElement(checkout).click();
		Thread.sleep(5000);
	}
	public void remove() throws InterruptedException
	{
		driver.findElement(remove).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void cartupdate() throws InterruptedException
	{
		driver.findElement(cartupdate).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void continshop() throws InterruptedException
	{
		driver.findElement(contin).click();
		TimeUnit.SECONDS.sleep(3);
	}
	public void mail() throws InterruptedException
	{
		driver.findElement(send).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	
}

