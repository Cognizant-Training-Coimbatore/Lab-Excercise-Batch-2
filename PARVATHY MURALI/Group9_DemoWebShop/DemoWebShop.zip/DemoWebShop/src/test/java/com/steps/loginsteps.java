package com.steps;

import org.openqa.selenium.By;

import com.baseclas.WrapperClass;
import com.excelUtility.excelLogin;
import com.main.DemoLogin;
import com.main.Demodesktop;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class loginsteps extends WrapperClass
{
	@Given("^The DemoWebShop website will launch$")
	public void the_DemoWebShop_website_will_launch() throws Exception 
	{
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	}

	@When("^The user will give the positive username and positive password$")
	public void the_user_will_give_the_positive_username_and_positive_password() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		log.info("positive username and positive password");
		
		
	}

	@When("^would click login button$")
	public void would_click_login_button() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		ob.loginbtn();
		Demodesktop dd=new Demodesktop(driver);
		log.info("successfull login");
	}

	@Then("^user would navigate to home page$")
	public void user_would_navigate_to_home_page() throws Exception 
	{
		quit();
	}

	@Given("^Launch the DemoWebShop website$")
	public void launch_the_DemoWebShop_website() throws Exception
	{
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	}
	@When("^The user give the negative username and positive password$")
	public void the_user_give_the_negative_username_and_positive_password() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(2));
		ob.pass(xl.excel_pwd(2));
		ob.loginbtn();
		log.info("negative username and positive password");
	}


	@When("^login button is clicked$")
	public void login_button_is_clicked() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		ob.loginbtn();
		log.info("login faliure");
	}

	@Then("^navigate to the homepage$")
	public void navigate_to_the_homepage() throws Exception
	{
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\login\\negativeusernameposititvepassword.jpg");
		quit();
	}

	@Given("^The DemoWebShop website should be launched$")
	public void the_DemoWebShop_website_should_be_launched() throws Exception
	{
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	}
	@When("^The user give the positive username and negative password$")
	public void the_user_give_the_positive_username_and_negative_password() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(3));
		ob.pass(xl.excel_pwd(3));
		log.info("positive username and negative password");
		ob.loginbtn();
	}


	@When("^should click on login button$")
	public void should_click_on_login_button() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		ob.loginbtn();
		log.info("login faliure");

	}

	@Then("^user should  navigate to the homepage$")
	public void user_should_navigate_to_the_homepage() throws Exception
	{
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\login\\positiveusernamenegativepassword.jpg");
		quit();
	}

	@Given("^The DemoWebShop website should launch$")
	public void the_DemoWebShop_website_should_launch() throws Exception
	{
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	}
	@When("^The user give the null username and negative password$")
	public void the_user_give_the_null_username_and_negative_password() throws Exception
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(4));
		ob.pass(xl.excel_pwd(4));
		log.info("the null username and negative password");
		ob.loginbtn();
	}

	@When("^click login button$")
	public void click_login_button() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		ob.loginbtn();
		log.info("login faliure");

	}

	@Then("^user navigates to homepage$")
	public void user_navigates_to_homepage() throws Exception 
	{
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\login\\nullusernegativepassword.jpg");
		quit();
	}
	@When("^The user give the positive username and null password$")
	public void the_user_give_the_positive_username_and_null_password() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(5));
		ob.pass(xl.excel_pwd(5));
		log.info("positive username and null password");
		ob.loginbtn();
		log.info("login faliure");

	}

	@Then("^should be navigated to the homepage$")
	public void should_be_navigated_to_the_homepage() throws Exception
	{
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\login\\posittiveusernamenullpassword.jpg");
		quit();
	}

	@Given("^Launch DemoWebShop$")
	public void launch_DemoWebShop() throws Exception 
	{
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	}
	@When("^The user give the  username and password as null$")
	public void the_user_give_the_username_and_password_as_null() throws Exception
	{
		DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam("");
		ob.pass("");
		log.info("empty username and password");
		
		
		
	}



	@When("^clicks login button$")
	public void clicks_login_button() throws Exception 
	{
		DemoLogin ob=new DemoLogin(driver);
		ob.loginbtn();
		log.info("login faliure");

	}

	@Then("^navigated to the homepage$")
	public void navigated_to_the_homepage() throws Exception 
	{
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\login\\nullpositivenegative.jpg");
		quit();
	}


}
