package com.steps;





import com.baseclas.WrapperClass;
import com.excelUtility.Excel_email;
import com.main.Electronics_cam;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Electronics_phone_steps extends WrapperClass
{
	
	@Given("^the application opened$")
	public void the_application_opened() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		log.info("The application is open");
		
	}

	@When("^the user selects the electronics option$")
	public void the_user_selects_the_electronics_option() throws Exception
	{
	    Electronics_cam obj=new Electronics_cam(driver);
	    obj.computer_phone();
	}

	@When("^the phone sub option should be selected$")
	public void the_phone_sub_option_should_be_selected() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.computer_phone();
	    log.info("Phone is selected from electronics");
	}

	@When("^shoud be sorted by created on$")
	public void shoud_be_sorted_by_created_on() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.created();
	    log.info("Sorted in the order of created on");
	}

	@When("^the display should be four in a page$")
	public void the_display_should_be_four_in_a_page() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.display();
	    log.info("Display is 4 per page");
	}

	@When("^the view should be in grid manner$")
	public void the_view_should_be_in_grid_manner() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.view();
	    log.info("Viewed in grid manner");
	   
	}

	@When("^filter should be under five hundred$")
	public void filter_should_be_under_five_hundred() throws Exception 
	{
		
	}

	@When("^the user should navigate to next page by selecting a particular phone$")
	public void the_user_should_navigate_to_next_page_by_selecting_a_particular_phone() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.phone_navigate();
	    log.info("Navigated to next page");
	    
	}

	@Then("^the product should be added to the shopping cart$")
	public void the_product_should_be_added_to_the_shopping_cart() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.addcart();
	    quit();
	    log.info("Application is closed");
	}

	@Given("^the application is opened$")
	public void the_application_is_opened() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		log.info("Application is open");
	}

	@When("^the user selects the electronic option$")
	public void the_user_selects_the_electronic_option() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.computer_phone();
	}

	@When("^the phone sub option is selected$")
	public void the_phone_sub_option_is_selected() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.computer_phone();
	    log.info("Phone is selected from electronics");
	}

	@When("^shoud be sorted by A to Z$")
	public void shoud_be_sorted_by_A_to_Z() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.AtoZ();
	    log.info("Sorted as A to Z");
	}

	@When("^the display should be eight in a page$")
	public void the_display_should_be_eight_in_a_page() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.diplay1();
	    log.info("Displayed as 8 per page");
	}

	@When("^the view should be in list manner$")
	public void the_view_should_be_in_list_manner() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.view1();
	    log.info("Viewed as list");
	}

	@When("^filter should be over five hundred$")
	public void filter_should_be_over_five_hundred() throws Exception 
	{
		
		
	}

	@When("^the user should navigate to next page when selected a particular phone$")
	public void the_user_should_navigate_to_next_page_when_selected_a_particular_phone() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
	    obj1.phone_navigate();
	    log.info("Navigated to next page");
	}

	@Then("^the product should be added to the shopping cart\\.$")
	public void the_product_should_be_added_to_the_shopping_cart1() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.addcart();
	    quit();
	    log.info("The application is closed");
	}

	@When("^the user would select the electronic option$")
	public void the_user_would_select_the_electronic_option() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.computer_phone();
	}

	@When("^the phone sub option wil be selected$")
	public void the_phone_sub_option_wil_be_selected() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.computer_phone();
	    log.info("Phone is selected electronics");
	}

	@When("^shoud be sorted by Z to A$")
	public void shoud_be_sorted_by_Z_to_A() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.ZtoA();
	    log.info("Sorted as Z to A");
	}

	@When("^the display should be twelve in a page$")
	public void the_display_should_be_twelve_in_a_page() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2. diplay2();
	    log.info("Displayed 12 per page");
	}

	@When("^the view should be in the list manner$")
	public void the_view_should_be_in_the_list_manner() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.view1();
	    log.info("Viewed in list manner");
	}

	@When("^filter should be in range under five hundred$")
	public void filter_should_be_in_range_under_five_hundred() throws Exception {
	    
	}

	@When("^the user should navigate to next page when selects a particular phone$")
	public void the_user_should_navigate_to_next_page_when_selects_a_particular_phone() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.phone_navigate();
	}

	@Then("^the product should be added to wishlist and shopping cart$")
	public void the_product_should_be_added_to_wishlist_and_shopping_cart() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
	    obj2.addwishlist();
		obj2.addcart();
	    quit();
	    log.info("Application is closed");
	}

	@When("^the sub option phone wil be selected$")
	public void the_sub_option_phone_wil_be_selected() throws Exception 
	{
		Electronics_cam obj3=new Electronics_cam(driver);
	    obj3.computer_phone();
	    log.info("Phone is selected from electronics");
	}

	@When("^shoud be sorted by High to low$")
	public void shoud_be_sorted_by_High_to_low() throws Exception 
	{
		Electronics_cam obj3=new Electronics_cam(driver);
	    obj3.hightolow();
	    log.info("Sorted as high to low");
	}

	@When("^filter should be in range of over five hundred$")
	public void filter_should_be_in_range_of_over_five_hundred() throws Exception 
	{
	   
	}

	@When("^the user should be navigated to next page when selects a particular phone$")
	public void the_user_should_be_navigated_to_next_page_when_selects_a_particular_phone() throws Exception 
	{
		Electronics_cam obj3=new Electronics_cam(driver);
	    obj3.phone_htol_navigate();
	}

	@Then("^the product be added to wishlist and shopping cart$")
	public void the_product_be_added_to_wishlist_and_shopping_cart() throws Exception 
	{
		Electronics_cam obj3=new Electronics_cam(driver);
		obj3.addwishlist();
		obj3.addcart();
	    quit();
	    log.info("Application is closed");
	}

	@Given("^the application opens$")
	public void the_application_opens() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		log.info("Application is open");
	}

	@When("^the user would select the Electronic option$")
	public void the_user_would_select_the_Electronic_option() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
	    obj4.computer_phone();
	}

	@When("^the phone sub option will be selected$")
	public void the_phone_sub_option_will_be_selected() throws Exception
	{
		Electronics_cam obj4=new Electronics_cam(driver);
	    obj4.computer_phone();
	    log.info("Phone is selected from electronics");
	}

	@When("^shoud be sorted by Low to High$")
	public void shoud_be_sorted_by_Low_to_High() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
	    obj4.lowtohigh();
	    log.info("Sorted as low to high");
	}

	@When("^the view should be in the grid form$")
	public void the_view_should_be_in_the_grid_form() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
	    obj4.view();
	    log.info("Viewed as grid");
	}

	@When("^filter should be in the range under five hundred$")
	public void filter_should_be_in_the_range_under_five_hundred() throws Exception {
	    
	}

	@When("^the user navigates to next page when selects a particular phone$")
	public void the_user_navigates_to_next_page_when_selects_a_particular_phone() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
		obj4.phone_ltoh_navigate();
		log.info("Navigated to next page");
	}

	@When("^the product should be added to wishlist and then shopping cart$")
	public void the_product_should_be_added_to_wishlist_and_then_shopping_cart() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
		obj4.addwishlist();
		obj4.addcart();
		log.info("Added to wishlist and shopcart");
		
	}

	@Then("^the user can send an email to friend$")
	public void the_user_can_send_an_email_to_friend() throws Exception 
	{
		Electronics_cam obj4=new Electronics_cam(driver);
		Excel_email dat=new Excel_email();
		obj4.email();
		obj4.friendemail(dat.enter_friendmail(1));
		obj4.youremail(dat.enter_yourmail(1));
		obj4.message(dat.enter_message(1));
		log.info("Email details filled");
		obj4.mail();
		screenshot("C:\\Users\\admin\\Desktop\\Java programs CBE\\Final Project\\DEMOproject\\src\\test\\resources\\com\\screenshot\\negemailsend.jpg");
		quit();
		log.info("Application is closed");
	}


}
