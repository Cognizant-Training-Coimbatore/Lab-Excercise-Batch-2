package com.steps;



import com.baseclas.WrapperClass;
import com.excelUtility.Excelutility;
import com.main.Reg_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Register1 extends WrapperClass
{
	@Given("^The application will be open$")
	public void the_application_will_be_open() throws Exception 
	{
	   launch_Browser("chrome","http://demowebshop.tricentis.com/");
	   Reg_page obj=new Reg_page(driver);
	   log.info("The Application is open");
	   obj.reg();
	}

	@When("^the male will be selected as gender$")
	public void the_male_will_be_selected_as_gender() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.button();
		log.info("Gender is selected as male");
	    
	}

	@When("^the user wil enter firtsname$")
	public void the_user_wil_enter_firtsname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.first(dat.enter_firstname(1));
		log.info("Firstname is entered");
	}

	@When("^the user will enter lastname$")
	public void the_user_will_enter_lastname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.last(dat.enter_lastname(1));
		log.info("Lastname is entered");
	}

	@When("^the user wil enter the mail and password$")
	public void the_user_wil_enter_the_mail_and_password() throws Exception
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.email(dat.enter_email(1));
		obj.pass(dat.enter_pass(1));
		log.info("The Email and password is entered");
	}

	@When("^the user would enter the confirm password$")
	public void the_user_would_enter_the_confirm_password() throws Exception
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.confirm(dat.enter_confirmpass(1));
		log.info("Confirm password is entered");
	}

	@Then("^the user should register$")
	public void the_user_should_register() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.reglast();
		
		quit();
		log.info("The application is closed");
	}

	@Given("^The application would be open$")
	public void the_application_would_be_open() throws Exception
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Reg_page obj=new Reg_page(driver);
		obj.reg();
		log.info("The Application is open");
	}

	@When("^the female will be selected as gender$")
	public void the_female_will_be_selected_as_gender() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.femselect();
		log.info("Gender is selected as female");
	    
	}

	@When("^the user would enter the negative firstname$")
	public void the_user_would_enter_the_negative_firstname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.first(dat.enter_firstname(2));
		log.info("Negative firstname is entered");
	}

	@When("^the user would enter the negative lastname$")
	public void the_user_would_enter_the_negative_lastname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.last(dat.enter_lastname(2));
		log.info("Negative astname is entered");
	   
	}

	@When("^the user would enter mail and password$")
	public void the_user_would_enter_mail_and_password() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.email(dat.enter_email(2));
		obj.pass(dat.enter_pass(2));
		log.info("Email and password is entered");
	}

	@When("^the user will enter confirm password$")
	public void the_user_will_enter_confirm_password() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.confirm(dat.enter_confirmpass(2));
		log.info("Confirm password is entered");
	}

	@Then("^the user should not be able to register$")
	public void the_user_should_not_be_able_to_register() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.reglast();
		
		quit();
		log.info("The Application is closed");
		
		screenshot("C:\\Users\\admin\\Desktop\\Java programs CBE\\Final Project\\DEMOproject\\src\\test\\resources\\com\\screenshot\\negativereg.jpg");
	}

	@Given("^The application should open$")
	public void the_application_should_open() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Reg_page obj=new Reg_page(driver);
		obj.reg();
		log.info("The application is open");
	    
	}

	@When("^the gender is selected as male$")
	public void the_gender_is_selected_as_male() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.button();
		log.info("Gender is selected as male");
		
	}

	@When("^the user will enter correct firstname$")
	public void the_user_will_enter_correct_firstname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.first(dat.enter_firstname(3));
		log.info("Firstname is entered");
	}

	@When("^the user will enter correct lastname$")
	public void the_user_will_enter_correct_lastname() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.last(dat.enter_lastname(3));
		log.info("Lastname is entered");
	}

	@When("^the user will enter wrong mail and correct password$")
	public void the_user_will_enter_wrong_mail_and_correct_password() throws Exception
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.email(dat.enter_email(3));
		obj.pass(dat.enter_pass(3));
		log.info("Wrong mail and corerct password is entered");
	}

	@When("^the user will enter the confirmpassword$")
	public void the_user_will_enter_the_confirmpassword() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		Excelutility dat=new Excelutility();
		obj.confirm(dat.enter_confirmpass(3));
		log.info("Confirm password is entered");
	}

	@Then("^the user not registered$")
	public void the_user_not_registered() throws Exception 
	{
		Reg_page obj=new Reg_page(driver);
		obj.reglast();
		quit();
		log.info("The application is closed");
	}



}
