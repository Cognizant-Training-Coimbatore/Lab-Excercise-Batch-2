package com.steps;


import com.baseclas.WrapperClass;
import com.main.digital_page;

import java.util.concurrent.TimeUnit;



import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class digital_steps extends WrapperClass {
	@Given("^The DemoWebShop website will be launched$")
	public void the_DemoWebShop_website_will_be_launched() throws Exception {
	    
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");

	}

	@When("^The user will give the username and password$")
	public void the_user_will_give_the_username_and_password() throws Exception {
		digital_page ob = new digital_page(driver);
		  ob.click_login1();
		  ob.type_email();
		  ob.type_password();
		  ob.click_login2();
		  TimeUnit.SECONDS.sleep(5);
	}

	@Given("^The user will navigate to the digital page$")
	public void the_user_will_navigate_to_the_digital_page1() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}

	@When("^Add to cart button is clicked$")
	public void add_to_cart_button_is_clicked() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.add_to_cart();
		TimeUnit.SECONDS.sleep(5);
	}

	@Given("^user should navigate to the digital page$")
	public void user_should_navigate_to_the_digital_page() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}

	@When("^quantity change is carried out$")
	public void quantity_change_is_carried_out() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.qty_change();
		TimeUnit.SECONDS.sleep(5);
	}

	@Given("^navigate to the digital page$")
	public void navigate_to_the_digital_page() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}

	@When("^add to wish list button is clicked$")
	public void add_to_wish_list_button_is_clicked() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.add_to_wishlist();
		TimeUnit.SECONDS.sleep(5);
	}

	@Given("^The user will navigate to the digital  page$")
	public void the_user_will_navigate_to_the_digital_page11() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}

	@When("^Email a friend button is clicked$")
	public void email_a_friend_button_is_clicked() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.email_a_friend();
		TimeUnit.SECONDS.sleep(5);
		
	}

	@Given("^the user should navigate to the digital page$")
	public void the_user_should_navigate_to_the_digital_page() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
		
	}

	@When("^compare list button is clicked$")
	public void compare_list_button_is_clicked() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.compare_list();
		TimeUnit.SECONDS.sleep(5);
	}

	@Given("^the user  navigate to the digital page$")
	public void the_user_navigate_to_the_digital_page() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}
	
	@When("^user change the page appearance$")
	public void user_change_the_page_appearance() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.properties1();
		TimeUnit.SECONDS.sleep(5);
	}

	@Given("^the user will navigate to the digital page$")
	public void the_user_will_navigate_to_the_digital_page() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.click_on_digital();
	}

	@When("^the user click the buy now button$")
	public void the_user_click_the_buy_now_button() throws Exception {
		digital_page ob = new digital_page(driver);
		ob.buy_now();
		TimeUnit.SECONDS.sleep(5);
	}

	@Then("^navigate to the home page$")
	public void navigate_to_the_home_page() throws Exception {
		quit();
	}
			}


	



