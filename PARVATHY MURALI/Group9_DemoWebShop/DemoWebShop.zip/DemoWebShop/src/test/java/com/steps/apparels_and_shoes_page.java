package com.steps;





import com.baseclas.WrapperClass;
import com.main.Apparels_and_Shoes;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class apparels_and_shoes_page extends WrapperClass{
	@Given("^The DemoWebshop site will launch$")
	public void the_DemoWebshop_site_will_launch() throws Throwable {
	    launch_Browser("chrome", "http://demowebshop.tricentis.com/");
	}

	@Then("^Taking screenshot$")
	public void taking_screenshot() throws Throwable {
	    screenshot("C:\\Users\\admin\\Desktop\\Java programs New\\project2\\src\\test\\resources\\screenshots\\scs.png");
	}

	@Given("^Navigating to Apparel&Shoes$")
	public void navigating_to_Apparel_Shoes() throws Throwable {
	  Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	  obj.click_on_apparels_and_shoes();
	}

	@When("^Click on a product and add it to cart$")
	public void click_on_a_product_and_add_it_to_cart() throws Throwable {
	    Apparels_and_Shoes  obj = new Apparels_and_Shoes(driver);
	    obj.add_to_cart_an_item();
	    driver.navigate().back();
	}

	@Given("^Change colour and size$")
	public void change_colour_and_size() throws Throwable {
	    Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	    obj.size_and_colour_change_item();
	    driver.navigate().back();
	}

	@When("^Click on  sortby and choose$")
	public void click_on_sortby_and_choose() throws Throwable {
		Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
		obj.sort_by_Name();
		driver.navigate().back();
	    
	}

	@When("^Click on display per page and change$")
	public void click_on_display_per_page_and_change() throws Throwable {
	   Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	   obj.display_per_page_change();
	   driver.navigate().back();
	}

	@Given("^Click on view as and choose$")
	public void click_on_view_as_and_choose() throws Throwable {
	    Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	    obj.view_as_change();
	    driver.navigate().back();
	}

	@When("^Click on add to wishlist$")
	public void click_on_add_to_wishlist() throws Throwable {
	    Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	    obj.add_to_wish_list();
	    driver.navigate().back();
	}

	@When("^Click on add to compare list$")
	public void click_on_add_to_compare_list() throws Throwable {
		Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
		obj.add_to_compare_list();
		driver.navigate().back();
	}

	@Given("^click on Email a friend$")
	public void click_on_Email_a_friend() throws Throwable {
	    Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	    obj.email_a_friend();
	    driver.navigate().back();
	    driver.navigate().back();
	    driver.navigate().back();
	}

	@When("^Click on quantity and choose$")
	public void click_on_quantity_and_choose() throws Throwable {
	  Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
	  obj.quantity_change();
	  driver.navigate().back();
	}

	@Given("^user buying a product$")
	public void user_buying_a_product() throws Throwable {
		Apparels_and_Shoes obj = new Apparels_and_Shoes(driver);
		obj.buy_an_item();
		driver.navigate().back();
	}

}
