package com.steps;

import org.openqa.selenium.By;

import com.baseclas.WrapperClass;
import com.excelUtility.excelLogin;
import com.main.DemoLogin;
import com.main.Demoaccessories;
import com.main.Demodesktop;
import com.main.Demonotebook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class module3Accessories extends WrapperClass
{
	@Given("^the DemoWebShop website is Launched$")
	public void the_DemoWebShop_website_is_Launched() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();
	}

	@When("^the user select the Accessoies  category from computer$")
	public void the_user_select_the_Accessoies_category_from_computer() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.computerclick();

	}

	@When("^Select Sort By,Filter, Dispaly,View$")
	public void select_Sort_By_Filter_Dispaly_View() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.sortNameAtoZ();
		da.filter();
		da.viewlist();
		da.display12();

	}

	@When("^click on the accessories to purchase$")
	public void click_on_the_accessories_to_purchase() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.selectProduct();

	}

	@When("^provide the quantity of the product$")
	public void provide_the_quantity_of_the_product() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.setProductProperties();

	}

	@Then("^click add to cart button$")
	public void click_add_to_cart_button() throws Exception 
	{
		Demoaccessories dn=new Demoaccessories(driver);
		dn.AddToCompareList();
		log.info("added to cart");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\accessories\\accessoriessucessfullAddToCart.jpg");
		quit();

	}

	@Given("^the DemoWebShop website is Launch$")
	public void the_DemoWebShop_website_is_Launch() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();

	}

	@When("^the user select the Accessories category from computer$")
	public void the_user_select_the_Accessories_category_from_computer() throws Exception
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.computerclick();

	}

	@When("^Select Sort By,Filter,Dispaly,View property from the page$")
	public void select_Sort_By_Filter_Dispaly_View_property_from_the_page() throws Exception 
	{

		Demoaccessories da=new Demoaccessories(driver);
		da.sortNameAtoZ();
		da.filter();
		da.viewlist();
		da.display12();
	}

	@When("^click on the accessories to buy$")
	public void click_on_the_accessories_to_buy() throws Exception
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.selectProduct();

	}

	@When("^give the quantity of the product$")
	public void give_the_quantity_of_the_product() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.setProductProperties();
	}

	@Then("^click email a friend button$")
	public void click_email_a_friend_button() throws Exception
	{
		Demoaccessories dn=new Demoaccessories(driver);
		dn.emailToFriend();
		log.info("successfully mailed to friend");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\accessories\\accessoriesemailafriend.jpg");
		quit();
	}

/*	@Given("^Launch the Demo Webshop website$")
	public void launch_the_Demo_Webshop_website() throws Exception 
	{

		/*Demoaccessories da=new Demoaccessories(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();
	}

	@When("^click on the acessories to buy it$")
	public void click_on_the_acessories_to_buy_it() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[3]/div/h2/a")).click();
		da.selectProduct();

	}

	@When("^give the quantity of product$")
	public void give_the_quantity_of_product() throws Exception
	{
	/*	Demoaccessories da=new Demoaccessories(driver);
		
		da.setProductProperties();
	}

	@Then("^click Add to compare list button$")
	public void click_Add_to_compare_list_button() throws Exception
	{
		
		/*screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\accessories\\accessoriessucessfullAddToCompareList.jpg");
		quit();

	}*/

	@Given("^Launch the Demo Webshop website in browser$")
	public void launch_the_Demo_Webshop_website_in_browser() throws Exception 
	{
		Demodesktop dd=new Demodesktop(driver);
		launch_Browser("chrome", "http://demowebshop.tricentis.com/");
		log.info("browser launched");
	    DemoLogin ob=new DemoLogin(driver);
		excelLogin xl=new excelLogin();
		ob.click();
		ob.usernam(xl.excel_username(1));
		ob.pass(xl.excel_pwd(1));
		ob.loginbtn();

	}

	@When("^the user selects the Accessories category from computer$")
	public void the_user_selects_the_Accessories_category_from_computer() throws Exception
	{

		Demoaccessories da=new Demoaccessories(driver);
		da.computerclick();
	}

	@When("^Select SortBy,Filter, Dispaly, View properties from the navigated webpage$")
	public void select_SortBy_Filter_Dispaly_View_properties_from_the_navigated_webpage() throws Exception
	{

		Demoaccessories da=new Demoaccessories(driver);
		da.sortNameAtoZ();
		da.filter();
		da.viewlist();
		da.display12();
	}

	@When("^click on the acessories to buy the product$")
	public void click_on_the_acessories_to_buy_the_product() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.selectProduct();

	}

	@When("^give the quantity of product to buy$")
	public void give_the_quantity_of_product_to_buy() throws Exception 
	{
		Demoaccessories da=new Demoaccessories(driver);
		da.setProductProperties();

	}

	@Then("^click wish list button$")
	public void click_wish_list_button() throws Exception 
	{

		Demoaccessories dn=new Demoaccessories(driver);
		dn.wishlist();
		log.info("add to wishlist");
		screenshot("C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\screenshot\\accessories\\accessoriessucessfullAddTowishlist.jpg");
		quit();
	}


}
