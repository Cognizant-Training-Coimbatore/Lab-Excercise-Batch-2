package com.main;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.excelUtility.excelLogin;

public class Demodesktop 
{
	static protected WebDriver driver;
	public Demodesktop(WebDriver driver)
	{
		this.driver=driver;
	}
	//xpath of computer to desktop page
	By computer=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a");
	By desktopmouseover=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a");
	By desk=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[1]/div/div");
	By desktop=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[1]/div/h2/a");
	
	
	public void coumputermouseover() throws InterruptedException
	{
		Actions action=new Actions(driver);
		WebElement mouse=driver.findElement(computer);	
		action.moveToElement(mouse).build().perform();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(desktopmouseover).click();
		TimeUnit.SECONDS.sleep(1);
	}
	public void computerclick() throws InterruptedException
	{
		driver.findElement(computer).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(desktop).click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	//xpath of select properties
		By sort=By.xpath("//*[@id=\"products-orderby\"]");
		By display=By.xpath("//*[@id=\"products-pagesize\"]");
		By viewpage=By.xpath("//*[@id=\"products-viewmode\"]");
		By filterunder1000=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[1]/a/span");
		By filter1000_1200=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[2]/a");
		By filterover1200=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[3]/a");
		
		
	public void sortNameAtoZ() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Name: A to Z");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortNameZtoA() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Name: Z to A");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPricLowtoHigh() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Price: Low to High");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPriceHightoLow() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Price: High to Low");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortCreatedon() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Created on");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPosition() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Position");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void display4() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("4");
		TimeUnit.SECONDS.sleep(1);
	}
	public void display8() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("8");
		TimeUnit.SECONDS.sleep(1);
	}
	public void display12() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("12");
		TimeUnit.SECONDS.sleep(1);
	}
	public void viewlist() throws InterruptedException
	{
		Select viewlist=new Select(driver.findElement(viewpage));
		viewlist.selectByVisibleText("List");
		TimeUnit.SECONDS.sleep(1);
	}
	public void viewGrid() throws InterruptedException
	{
		Select viewlist=new Select(driver.findElement(viewpage));
		viewlist.selectByVisibleText("Grid");
		TimeUnit.SECONDS.sleep(1);
	}
	public void filterunder1000() throws InterruptedException
	{
		
		driver.findElement(filterunder1000).click();
		TimeUnit.SECONDS.sleep(1);	
		
	}
	public void filter1000_1200() throws InterruptedException
	{
		
		driver.findElement(filter1000_1200).click();
		TimeUnit.SECONDS.sleep(1);	
		
	}
	public void filterover1200() throws InterruptedException
	{
		
		driver.findElement(filterover1200).click();
		TimeUnit.SECONDS.sleep(1);	
		
	}
	//xpath for selecting product
	By productname1=By.linkText("Build your own expensive computer");
	
	public void selectProduct() throws InterruptedException 
	{
		driver.findElement(productname1).click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	//xpath for setting product properties
	By processor=By.xpath("//*[@id=\"product_attribute_74_5_26_82\"]");
	By RAM=By.xpath("//*[@id=\"product_attribute_74_6_27_85\"]");
	By HDD=By.xpath("//*[@id=\"product_attribute_74_3_28_87\"]");
	By software1=By.xpath("//*[@id=\"product_attribute_74_8_29_89\"]");
	By qty=By.xpath("//*[@id=\"addtocart_74_EnteredQuantity\"]");
	public void setProductProperties() throws InterruptedException
	{
		driver.findElement(processor).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(RAM).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HDD).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(software1).click();
		driver.findElement(qty).sendKeys("5");	
	}
	//xpath to add to cart
	By addtocartButton=By.xpath("//*[@id=\"add-to-cart-button-74\"]");
	
	public void AddtoCart()
	{
		driver.findElement(addtocartButton).click();
		
	}
	
	//xpath to email a friend
	By emailfriendbtn=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[9]/input");
	By emailidto=By.xpath("//*[@id=\"FriendEmail\"]");
	By msg=By.xpath("//*[@id=\"PersonalMessage\"]");
	public void emailToFriend() throws IOException
	{
		driver.findElement(emailfriendbtn).click();
		driver.findElement(emailidto).click();
		excelLogin xl=new excelLogin();
		driver.findElement(emailidto).sendKeys(xl.excel_username(2));
		driver.findElement(msg).sendKeys("I like this product");
	}
	
	//xpath to compare list
	By compare=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[10]/input");
	public void AddToCompareList()
	{
		driver.findElement(compare).click();
	}
	
}
