package com.steps;



import com.baseclas.WrapperClass;
import com.main.Electronics_cam;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Cart_wishist_steps extends WrapperClass
{
	@Given("^the application is opened and the product is added to wishist$")
	public void the_application_is_opened_and_the_product_is_added_to_wishist() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.AtoZ();
		obj.display();
		obj.view();
		obj.phone_navigate();
		obj.addwishlist();
	}

	@When("^the user clicks on wishlist$")
	public void the_user_clicks_on_wishlist() throws Exception
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.wish();
	}

	@When("^the add to cart is ticked$")
	public void the_add_to_cart_is_ticked() throws Exception
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.addtick();
	}

	@Then("^wishlist should be updated$")
	public void wishlist_should_be_updated() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.updatewish();
		quit();
		
	}

	@Given("^the application opens and the product added to wishlist$")
	public void the_application_opens_and_the_product_added_to_wishlist() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.ZtoA();
		obj.diplay1();
		obj.view1();
		obj.phone_navigate();
		obj.addwishlist();
	}

	@When("^the user selects wishlist$")
	public void the_user_selects_wishlist() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.wish();
	}

	@When("^the user ticks add to cart$")
	public void the_user_ticks_add_to_cart() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.addtick();
	}

	@When("^clicks on Add to Cart$")
	public void clicks_on_Add_to_Cart() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.cartclick();
	}

	@When("^navigates to shopping cart page$")
	public void navigates_to_shopping_cart_page() throws Exception 
	{
	    System.out.println("Navigated to the shopping cart page");
	}

	@When("^the country is selected as India$")
	public void the_country_is_selected_as_India() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.country();
	}

	@When("^the state province is selected$")
	public void the_state_province_is_selected1() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.state();
	    
	}

	@When("^the zip code should be entered$")
	public void the_zip_code_should_be_entered() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.zip();
	}

	@When("^Estimate shipping is given$")
	public void estimate_shipping_is_given() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.estimate();
	    
	}

	@When("^I agree term should be ticked$")
	public void i_agree_term_should_be_ticked() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.agree();
	}

	@Then("^the user should checkout$")
	public void the_user_should_checkout() throws Exception 
	{
		quit();
		
	}

	@Given("^Application is open and product in wishlist$")
	public void application_is_open_and_product_in_wishlist() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.lowtohigh();
		obj.diplay1();
		obj.view1();
		obj.phone_ltoh_navigate();
		obj.addwishlist();
	}

	@When("^the user clicks the wishlist$")
	public void the_user_clicks_the_wishlist() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.wish();
	}

	@When("^the remove option is clicked$")
	public void the_remove_option_is_clicked() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.remove();
	}

	@Then("^the wishlist is updated$")
	public void the_wishlist_is_updated() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.updatewish();
		quit();
		
	}

	@Given("^the application is open and the product is added to cart$")
	public void the_application_is_open_and_the_product_is_added_to_cart() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.hightolow();
		obj.diplay1();
		obj.view1();
		obj.phone_htol_navigate();
		obj.addcart();
	}

	@When("^the user selects Shopping cart$")
	public void the_user_selects_Shopping_cart() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.lookshopcart();
	}

	@When("^the country is selected$")
	public void the_country_is_selected() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.country();
	}

	@When("^the state province  is selected$")
	public void the_state_province_is_selected() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.state();
	}

	@When("^the zip postal is entered$")
	public void the_zip_postal_is_entered() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.zip();
	}

	@When("^estimate shopping given$")
	public void estimate_shopping_given() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.estimate();
	}

	@When("^I agree condition is ticked$")
	public void i_agree_condition_is_ticked() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.agree();
		quit();
		
	 
	}

	@Given("^the application is open and the product added to shopping cart$")
	public void the_application_is_open_and_the_product_added_to_shopping_cart() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.hightolow();
		obj.diplay1();
		obj.view1();
		obj.phone_htol_navigate();
		obj.addcart();
	}

	@When("^the Shopping cart is selected$")
	public void the_Shopping_cart_is_selected() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.lookshopcart();
	}

	@When("^the remove option clicked$")
	public void the_remove_option_clicked() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.remove();
	}

	@Then("^the Shopping cart is updated$")
	public void the_Shopping_cart_is_updated() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.cartupdate();
		quit();
		
	}

	@When("^the application is open and a product added to shopping cart$")
	public void the_application_is_open_and_a_product_added_to_shopping_cart() throws Exception 
	{
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		Electronics_cam obj=new Electronics_cam (driver);
		obj.computer_phone();
		obj.hightolow();
		obj.diplay1();
		obj.view1();
		obj.phone_htol_navigate();
		obj.addcart();
	   
	}

	@When("^the shopping cart is clicked$")
	public void the_shopping_cart_is_clicked() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.lookshopcart();
	}

	@Then("^the continue shopping is clicked for more shopping$")
	public void the_continue_shopping_is_clicked_for_more_shopping() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam (driver);
		obj.continshop();
		quit();
	}


}
