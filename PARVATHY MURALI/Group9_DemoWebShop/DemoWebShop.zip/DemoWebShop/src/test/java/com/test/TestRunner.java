package com.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith (Cucumber.class)
@CucumberOptions (features= {"C:\\Users\\Admin\\Desktop\\844390_Selenium_project\\demo2\\src\\test\\resources\\com\\features"},glue="com.steps")
public class TestRunner {

}
