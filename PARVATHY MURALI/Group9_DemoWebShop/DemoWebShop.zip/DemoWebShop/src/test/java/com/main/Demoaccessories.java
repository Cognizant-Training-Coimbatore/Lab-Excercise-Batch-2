package com.main;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.excelUtility.excelLogin;

public class Demoaccessories 
{
	static protected WebDriver driver;
	public Demoaccessories(WebDriver driver)
	{
		this.driver=driver;
	}
	By computer=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a");
	By access=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/ul/li[3]/a");
	By accessories=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[1]/div[3]/div/h2/a");
	
	
	public void coumputermouseover() throws InterruptedException
	{
		Actions action=new Actions(driver);
		WebElement mouse=driver.findElement(computer);	
		action.moveToElement(mouse).build().perform();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(access).click();
		TimeUnit.SECONDS.sleep(1);
	}
	public void computerclick() throws InterruptedException
	{
		driver.findElement(computer).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(accessories).click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	
	
	//xpath of select properties
		By sort=By.xpath("//*[@id=\"products-orderby\"]");
		By display=By.xpath("//*[@id=\"products-pagesize\"]");
		By viewpage=By.xpath("//*[@id=\"products-viewmode\"]");
		By filter=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[2]/div/div[2]/ul/li[2]/a");
		
		
		
	public void sortNameAtoZ() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Name: A to Z");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortNameZtoA() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Name: Z to A");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPricLowtoHigh() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Price: Low to High");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPriceHightoLow() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Price: High to Low");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortCreatedon() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Created on");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void sortPosition() throws InterruptedException
	{
		Select sortlist=new Select(driver.findElement(sort));
		sortlist.selectByVisibleText("Position");
		TimeUnit.SECONDS.sleep(1);
		
	}
	public void display4() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("4");
		TimeUnit.SECONDS.sleep(1);
	}
	public void display8() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("8");
		TimeUnit.SECONDS.sleep(1);
	}
	public void display12() throws InterruptedException
	{
		Select displaylist=new Select(driver.findElement(display));
		displaylist.selectByVisibleText("12");
		TimeUnit.SECONDS.sleep(1);
	}
	public void viewlist() throws InterruptedException
	{
		Select viewlist=new Select(driver.findElement(viewpage));
		viewlist.selectByVisibleText("List");
		TimeUnit.SECONDS.sleep(1);
	}
	public void viewGrid() throws InterruptedException
	{
		Select viewlist=new Select(driver.findElement(viewpage));
		viewlist.selectByVisibleText("Grid");
		TimeUnit.SECONDS.sleep(1);
	}
	public void filter() throws InterruptedException
	{
		
		driver.findElement(filter).click();
		TimeUnit.SECONDS.sleep(1);	
		
	}
	
	//xpath for selecting product
	By productname1=By.linkText("TCP Instructor Led Training");
	
	public void selectProduct() throws InterruptedException 
	{
		driver.findElement(productname1).click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	//xpath for setting product properties
	
	By qty=By.xpath("//*[@id=\"addtocart_66_EnteredQuantity\"]");
	public void setProductProperties() throws InterruptedException
	{
		driver.findElement(qty).sendKeys("15");	
	}
	//xpath to add to cart
	By addtocartButton=By.xpath("//*[@id=\"add-to-cart-button-66\"]");
	
	public void AddtoCart()
	{
		driver.findElement(addtocartButton).click();
		
	}
	
	//xpath to email a friend
	By emailfriendbtn=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[6]/input");
	By emailidto=By.xpath("//*[@id=\"FriendEmail\"]");
	By msg=By.xpath("//*[@id=\"PersonalMessage\"]");
	public void emailToFriend() throws IOException
	{
		driver.findElement(emailfriendbtn).click();
		driver.findElement(emailidto).click();
		excelLogin xl=new excelLogin();
		driver.findElement(emailidto).sendKeys(xl.excel_username(2));
		driver.findElement(msg).sendKeys("I like this product");
		
	}
	
	//xpath to compare list
	By compare=By.xpath("//*[@id=\"product-details-form\"]/div/div[1]/div[2]/div[7]/input");
	public void AddToCompareList()
	{
		driver.findElement(compare).click();
	}
	
	//xpath to wishlist
	By wish=By.xpath("//*[@id=\"add-to-wishlist-button-66\"]");
	By wishlist=By.xpath("//*[@id=\"bar-notification\"]/p/a");
	public void wishlist()
	{
		driver.findElement(wish).click();
		
	}


}
