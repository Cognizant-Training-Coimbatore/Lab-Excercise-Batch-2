package com.steps;



import com.baseclas.WrapperClass;
import com.main.Electronics_cam;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Eectronics_steps extends WrapperClass
{
	@Given("^the application should be open$")
	public void the_application_should_be_open() throws Exception 
	{
	   launch_Browser("chrome","http://demowebshop.tricentis.com/");
	   log.info("The application is open");
	}

	@When("^the user will select electronics$")
	public void the_user_will_select_electronics() throws Exception 
	{
	    Electronics_cam obj=new Electronics_cam(driver);
	    obj.computers();
	}

	@When("^the camera,photo should be selected$")
	public void the_camera_photo_should_be_selected() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.computers();
	    log.info("Camera is selected from electronics");
	}

	@When("^should be sorted by Name A-Z$")
	public void should_be_sorted_by_Name_A_Z() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.AtoZ();
	    log.info("Sorted in the order of A to Z");
	}

	@When("^the display should be four per page$")
	public void the_display_should_be_four_per_page() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.display();
	    log.info("Displayed 4 per page");
	}

	@When("^it should be viewed as a grid$")
	public void it_should_be_viewed_as_a_grid() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.view();
	    log.info("Viewed as grid");
	}

	@When("^should be filtered by price under five hundred$")
	public void should_be_filtered_by_price_under_five_hundred() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.filter();
	    log.info("Filtered under 500 Rs");
	}

	@Then("^the user should be able to select a particular camera and navigate to next page$")
	public void the_user_should_be_able_to_select_a_particular_camera_and_navigate_to_next_page() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
	    obj.navigate();
	    log.info("Navigated to next page");
	    obj.addcompare();
	    quit();
	    log.info("Application is closed");
	}

	@Given("^the application would be open$")
	public void the_application_would_be_open() throws Exception 
	{

		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		   log.info("the Appication is open");
	}

	@When("^the user selects electronics$")
	public void the_user_selects_electronics() throws Exception 
	{
		 Electronics_cam obj1=new Electronics_cam(driver);
		 obj1.computers();
	}

	@When("^the camera,photo is selected$")
	public void the_camera_photo_is_selected() throws Exception 
	{
		 Electronics_cam obj1=new Electronics_cam(driver);
		 obj1.computers();
		 log.info("Camera is selected from electronics");
	}

	@When("^should be sorted by Name Z-A$")
	public void should_be_sorted_by_Name_Z_A() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
		 obj1.ZtoA();
		 log.info("Sorted in the order of Z to A");
	    
	}

	@When("^dispay is eight per page$")
	public void dispay_is_eight_per_page() throws Exception 
	{
		Electronics_cam obj=new Electronics_cam(driver);
		obj.diplay1();
		log.info("Displayed 8 per page");
	}

	@When("^it shoud be viewed as list$")
	public void it_shoud_be_viewed_as_list() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
		obj1.view1();
		log.info("Viewed as list");
	}

	@When("^should be filtered by price over five hundred$")
	public void should_be_filtered_by_price_over_five_hundred() throws Exception 
	{
		
		Electronics_cam obj1=new Electronics_cam(driver);
		obj1.filter1();
		log.info("Filtered over 500 Rs ");
	}

	@Then("^the user should be able to select a camera image and navigate to next page$")
	public void the_user_should_be_able_to_select_a_camera_image_and_navigate_to_next_page() throws Exception 
	{
		Electronics_cam obj1=new Electronics_cam(driver);
		obj1.navigate1();
		obj1.addcompare();
		quit();
		log.info("Application is closed");
	}

	@Given("^the application is open$")
	public void the_application_is_open() throws Exception 
	{
		
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		log.info("Application is open");
	    
	}

	@When("^the user will select electronic$")
	public void the_user_will_select_electronic() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.computers();
		log.info("Camera is selected from electronics");
		
	}

	@When("^should be sorted as price Low to high$")
	public void should_be_sorted_as_price_Low_to_high() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.lowtohigh();
		log.info("Sorted in the order of Low to High");
	}

	@When("^dispay is twelve per page$")
	public void dispay_is_twelve_per_page() throws Exception
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.diplay2();
		log.info("Displayed 12 per page");
	}

	@When("^it shoud be viewed as grid$")
	public void it_shoud_be_viewed_as_grid() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.view();
		log.info("Viewed as grid");
		log.info("Application is closed");
	}

	@Given("^the application should be opened$")
	public void the_application_should_be_opened() throws Exception 
	{
		
		launch_Browser("chrome","http://demowebshop.tricentis.com/");
		log.info("Application is open");
	}

	@When("^should be sorted as price High to Low$")
	public void should_be_sorted_as_price_High_to_Low() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.hightolow();
		log.info("Sorted in the order of high to low");
	}

	@When("^dispay is four per page$")
	public void dispay_is_four_per_page() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.display();
	}

	@When("^it shoud be viewed as List$")
	public void it_shoud_be_viewed_as_List() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.view1();
	}

	@When("^should be filtered by price that is under five hundred$")
	public void should_be_filtered_by_price_that_is_under_five_hundred() throws Exception 
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.filter();
	}

	@Then("^the user should be able to select a camera image and navigates to next page$")
	public void the_user_should_be_able_to_select_a_camera_image_and_navigates_to_next_page() throws Exception
	{
		Electronics_cam obj2=new Electronics_cam(driver);
		obj2.navigate();
		obj2.addcompare();
		quit();
		log.info("Application is closed");
	}


}
