package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pages.module_acinfo;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.excelread_for_ac_info;

public class acc_info_teststep extends wrapperclass
{
	@Given("^The user is logged in now$")
	public void the_user_is_logged_in_now() throws Exception {
		System.out.println("launched");
	}

	@When("^The user clicks my account$")
	public void the_user_clicks_my_account() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_myinfo(); 
	}

	@When("^The user selects My Details$")
	public void the_user_selects_My_Details() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_mydetails();
	}

	@When("^The user selects account information$")
	public void the_user_selects_account_information() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_acinfo();
	}

	@When("^The user selects title$")
	public void the_user_selects_title() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_title();
	}

	@When("^The user selects gender$")
	public void the_user_selects_gender() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_gender();
	}

	@When("^The user selects change password$")
	public void the_user_selects_change_password() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.click_ch_pass();
	}

	@When("^The user enters current password$")
	public void the_user_enters_current_password() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass(data.excel_read_pwd(1,0));
		TimeUnit.SECONDS.sleep(5);
	}

	@When("^The user enters new password$")
	public void the_user_enters_new_password() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass2(data.excel_read_pwd2(1,1));
		TimeUnit.SECONDS.sleep(5);
	}

	@When("^The user enters new password for confirmation$")
	public void the_user_enters_new_password_for_confirmation() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass3(data.excel_read_pwd3(1,2));
		TimeUnit.SECONDS.sleep(5);
	}

	@When("^The user clicks save button$")
	public void the_user_clicks_save_button() throws Exception {
		module_acinfo obj = new module_acinfo(driver);
		obj.save();
		TimeUnit.SECONDS.sleep(5);
		
		
		
	}

	@Then("^The user gets a error message$")
	public void the_user_gets_a_error_message() throws Exception {
	    System.out.println("Displaying error message");
	    TimeUnit.SECONDS.sleep(5);
	    screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn1.jpg");
	    TimeUnit.SECONDS.sleep(2);
	    
	}

	//2nd testcase
	@Given("^The user is logged inb$")
	public void the_user_is_logged_inb() throws Exception {
	    TimeUnit.SECONDS.sleep(1);
		System.out.println("logged in");
	}

	@When("^The user selects change passwordb$")
	public void the_user_selects_change_passwordb() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		obj.click_ch_pass();
	}

	@When("^The user enters current passwordb$")
	public void the_user_enters_current_passwordb() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass(data.excel_read_pwd(2,0));
	}

	@When("^The user enters new passwordb$")
	public void the_user_enters_new_passwordb() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass2(data.excel_read_pwd2(2,1));
	}
	
	@When("^The user enters new password for confirmationb$")
	public void the_user_enters_new_password_for_confirmationb() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		obj.enter_pass3(data.excel_read_pwd2(2,2));
	}

	@When("^The user clicks save buttonb$")
	public void the_user_clicks_save_buttonb() throws Exception {
		 TimeUnit.SECONDS.sleep(3);
		module_acinfo obj = new module_acinfo(driver);
		obj.save();
	}

	@Then("^The user gets a error messageb$")
	public void the_user_gets_a_error_messageb() throws Exception {
		 TimeUnit.SECONDS.sleep(5);
		  screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn2.jpg");
		 TimeUnit.SECONDS.sleep(2);
	    System.out.println("Displaying error message");
	}

	//3rd testcase
	@Given("^The user is logged inc$")
	public void the_user_is_logged_inc() throws Exception {
		 TimeUnit.SECONDS.sleep(3);
	    System.out.println("logged in");
	}

	@When("^The user selects change passwordc$")
	public void the_user_selects_change_passwordc() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"change-password\"]"))).click();
		obj.click_ch_pass();
	}

	@When("^The user enters current passwordc$")
	public void the_user_enters_current_passwordc() throws Exception {
//		 TimeUnit.SECONDS.sleep(4);
//		module_acinfo obj = new module_acinfo(driver);
//		excelread_for_ac_info data = new excelread_for_ac_info();
//		obj.enter_pass(data.excel_read_pwd(3,0));
		System.out.println(":)");
	}

	@When("^The user enters new passwordc$")
	public void the_user_enters_new_passwordc() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		driver.findElement(By.xpath("//*[@id=\"password\"]")).clear();
		obj.enter_pass2(data.excel_read_pwd2(3,1));
	}
	
	@When("^The user enters new password for confirmationc$")
	public void the_user_enters_new_password_for_confirmationc() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
		module_acinfo obj = new module_acinfo(driver);
		excelread_for_ac_info data = new excelread_for_ac_info();
		driver.findElement(By.id("password-confirmation")).clear();
		obj.enter_pass3(data.excel_read_pwd2(3,2));
	}

	@When("^The user clicks save buttonc$")
	public void the_user_clicks_save_buttonc() throws Exception {
		 TimeUnit.SECONDS.sleep(3);
		module_acinfo obj = new module_acinfo(driver);
		obj.save();
	}

	@Then("^The password gets changed and reaches homepagec$")
	public void the_password_gets_changed_and_reaches_homepagec() throws Exception {
		 TimeUnit.SECONDS.sleep(4);
	    System.out.println("Password changed and reaches homepage");
	}
	
	@Then("^The user clicks the homepage icon$")
	public void the_user_clicks_the_homepage_icon() throws Exception {
	    TimeUnit.SECONDS.sleep(3);
	    module_acinfo obj = new module_acinfo(driver);
		obj.clickhomepage();
	}
}
