package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import com.pages.loginpage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login_teststep extends wrapperclass {
	
	
	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("the application has been opened");
		 
		launchApplication("chrome","https://www.mothercare.in/");
		  TimeUnit.SECONDS.sleep(3);
	   
	}

	@When("^user navigates login page$")
	public void user_navigates_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		loginpage obj=new loginpage(driver);
		obj.login();
		System.out.println("user is on loginpage");
	}

	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and(String arg1, String arg2) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		loginpage obj=new loginpage(driver);
		obj.user_login(arg1, arg2);
		System.out.println("user enters username and password");
	   
	}

	@Then("^success message is displayed$")
	public void success_message_is_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  System.out.println("user is able to login");
	    
	}


	
	
	

}
