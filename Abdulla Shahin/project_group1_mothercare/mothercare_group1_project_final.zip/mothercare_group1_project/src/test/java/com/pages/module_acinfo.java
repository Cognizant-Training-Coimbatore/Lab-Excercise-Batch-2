package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class module_acinfo 
{
	WebDriver driver;
	By click_myac = By.xpath("/html/body/div[2]/header/div[1]/div/ul/li[1]/a[2]");
	By click_mydetails = By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[2]/div/div/div[2]/div/div/a[1]/div/div");
	By click_acinfo = By.xpath("//*[@id=\"block-collapsible-nav\"]/ul/li[6]/a");
	By click_title = By.xpath("//*[@id=\"prefix\"]");
	By click_gender = By.xpath("//*[@id=\"gender\"]");
	By click_ch_pass = By.xpath("//*[@id=\"change-password\"]");
	By enter_pass = By.id("current-password");
	By enter_pass2 = By.xpath("//*[@id=\"password\"]");
	By enter_pass3 = By.id("password-confirmation");
	By save = By.xpath("//*[@id=\"form-validate\"]/div/div[1]/button");
	By clickhomepage = By.id("ui-id-3");
	
	
	public module_acinfo(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void click_myinfo()
	{
		driver.findElement(click_myac).click();
	}
	
	public void click_mydetails()
	{
		driver.findElement(click_mydetails).click();
	}
	
	public void click_acinfo()
	{
		driver.findElement(click_acinfo).click();
	}
	
	public void click_title()
	{
		driver.findElement(click_title).click();
		Select title = new Select(driver.findElement(click_title));
		title.selectByVisibleText("Mr");		
	}
	
	public void click_gender()
	{
		driver.findElement(click_gender).click();
		Select title = new Select(driver.findElement(click_gender));
		title.selectByVisibleText("Male");		
	}
	
	public void click_ch_pass()
	{
		driver.findElement(click_ch_pass).click();;
	}
	
	public void enter_pass(String p)
	{
		driver.findElement(enter_pass).sendKeys(p,Keys.TAB);
	}
	
	public void enter_pass2(String q)
	{
		driver.findElement(enter_pass2).sendKeys(q,Keys.TAB);
	}
	
	public void enter_pass3(String r)
	{
		driver.findElement(enter_pass3).sendKeys(r);
	}
	
	public void save()
	{
		driver.findElement(save).click();
	}
	
	public void clickhomepage()
	{
		driver.findElement(clickhomepage).click();
	}
}
