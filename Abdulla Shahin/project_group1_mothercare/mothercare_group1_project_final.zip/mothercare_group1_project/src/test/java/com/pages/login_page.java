package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class login_page extends wrapperclass
{
	By login = By.linkText("join my mothercare");
	By username = By.id("email");
	By password = By.id("pass");
	By signin = By.id("send2");
	By babyfashion = By.id("ui-id-4");
	
	public login_page(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void clicklogin()
	{
		driver.findElement(login).click();
	}
	
	public void login(String user, String pass)
	{
		driver.findElement(username).sendKeys(user);
		driver.findElement(password).sendKeys(pass);
	}
	
	public void signin()
	{
		driver.findElement(signin).click();
	}
	
	

}
