package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class search extends wrapperclass{
	
	public search(WebDriver driver)
	{
		this.driver=driver;
	}

	public void search_single(String product) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("search")).clear();
		driver.findElement(By.id("search")).sendKeys(product);
		driver.findElement(By.id("search")).sendKeys(Keys.ENTER);
		
		
	}
	public void back_home()
	{
		  driver.findElement(By.id("ui-id-4")).click();
	}

}
