package com.stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.Excel_data;
import com.pages.shopping_basket;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class shopping_teststep extends wrapperclass 
{
	
	@Given("^I am on a product detail page$")
	public void i_am_on_a_product_detail_page() throws Exception
	{
		shopping_basket  obj=new shopping_basket(driver);
		obj.baby_click();
		
		
	
		}
	    
	    
	
	@When("^I select the category$")
	public void i_select_the_category() throws Exception {
		shopping_basket obj=new shopping_basket(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel4(3,1);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]"));
		statement1:
		for(WebElement e1 : main)
		{
		System.out.println(e1.getText());
		if(e1.getText().contains(cat))
		{
			System.out.println(cat);
		obj.prod_click();
		break statement1;
		}
		}
		
	    
	}

	@When("^I select the age filter$")
	public void i_select_the_age_filter() throws Exception {
		shopping_basket obj=new shopping_basket(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel4(3,2);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol"));
		statement1:
		for(WebElement e2 : main)
		{
		System.out.println(e2.getText());
		if(e2.getText().contains(cat))
		{
			System.out.println(cat);
			obj.ag();
		TimeUnit.SECONDS.sleep(5);
		break statement1;
		
		}
		}
	}

	@When("^I select a product$")
	public void i_select_a_product() throws Exception
	{
		TimeUnit.SECONDS.sleep(10);
		shopping_basket obj=new shopping_basket(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel4(3,3);
		System.out.println(cat);
		//List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]"));
		List<WebElement> main =driver.findElements(By.xpath("/html/body/div[3]/main/div[2]/div[1]/div[6]/ol"));
		statement1:
		for(WebElement e3 : main)
		{
		System.out.println(e3.getText());
		if(e3.getText().contains(cat))
		{
			System.out.println(cat);
			TimeUnit.SECONDS.sleep(5);
		obj.prod_sel();
		TimeUnit.SECONDS.sleep(3);
		break statement1;
		}
		}
	   
	}



	@When("^I click the add to basket button$")
	public void i_click_the_add_to_basket_button() throws Exception
	{
		
		shopping_basket obj=new shopping_basket(driver);
		obj.add_to();
		TimeUnit.SECONDS.sleep(3);
		screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn5.jpg");
		TimeUnit.SECONDS.sleep(3);
	   
	}

	@Then("^the product is added to my shopping basket$")
	public void the_product_is_added_to_my_shopping_basket() throws Exception
	{
		System.out.println("product added to basket");
	    
	}

	@Given("^I have added an item to my shopping bag$")
	public void i_have_added_an_item_to_my_shopping_bag() throws Exception 
	{
		System.out.println("product added");
	   
	}

	@When("^I click the shopping bag icon$")
	public void i_click_the_shopping_bag_icon() throws Exception 
	{
		shopping_basket obj=new shopping_basket(driver);
		obj.view_basket();
	   
	}

	@Then("^I land on the shopping bag page$")
	public void i_land_on_the_shopping_bag_page() throws Exception
	{
		System.out.println("i am on the shopping bag page");
	   
	}

	@Then("^I can see the product in my shopping basket$")
	public void i_can_see_the_product_in_my_shopping_basket() throws Exception
	{
		System.out.println("I can see the product there");
		TimeUnit.SECONDS.sleep(5);
		screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn6.jpg");
	   
	}

	@Then("^The user clicks homepage and reaches homepage$")
	public void the_user_clicks_homepage_and_reaches_homepage() throws Exception {
		shopping_basket obj=new shopping_basket(driver);
		obj.clickhomepage();
	}

}
