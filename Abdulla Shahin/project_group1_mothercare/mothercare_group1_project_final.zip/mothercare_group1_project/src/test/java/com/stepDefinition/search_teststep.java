package com.stepDefinition;

import java.lang.annotation.Annotation;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import excelutility.excel_utility;
import baseclass.wrapperclass;
import com.pages.search;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class search_teststep extends  wrapperclass{
 
	
	@Given("^I am on the homepage to do a single keyword search$")
	public void i_am_on_the_homepage_to_do_a_single_keyword_search() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("user is in the homepage");
	}

	@When("^I do a single keyword search for \\(\\.\\.\\.\\)$")
	public void i_do_a_single_keyword_search_for() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		search s=new search(driver);
		excel_utility e=new excel_utility();
		String product=e.read_excel_search(1, 0);
		s.search_single(product);
		
	  
	}

	@Then("^I see a single keyword search result page with more than zero results$")
	public void i_see_a_single_keyword_search_result_page_with_more_than_zero_results() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("found");
	}

	@Given("^I am on the homepage to do a search with multiple keywords$")
	public void i_am_on_the_homepage_to_do_a_search_with_multiple_keywords() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  System.out.println("scenario2");
	  TimeUnit.SECONDS.sleep(3);
	}

	@When("^I do a multiple keyword search for \\(\\.\\.\\. \\.\\.\\.\\)$")
	public void i_do_a_multiple_keyword_search_for() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		search s=new search(driver);
		excel_utility e=new excel_utility();
		String product=e.read_excel_search(2, 0);
		TimeUnit.SECONDS.sleep(3);
		s.search_single(product);
		screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn3.jpg");
		TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I see a multiple keyword search result page with more than zero results$")
	public void i_see_a_multiple_keyword_search_result_page_with_more_than_zero_results() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
	  System.out.println("done");
	  TimeUnit.SECONDS.sleep(3);
	}

	@Given("^I am on the homepage to do search$")
	public void i_am_on_the_homepage_to_do_search() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	System.out.println("Scenario3");
	TimeUnit.SECONDS.sleep(3);
	}

	@When("^I do a search for an invalid data$")
	public void i_do_a_search_for_an_invalid_data() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		search s=new search(driver);
		excel_utility e=new excel_utility();
		String product=e.read_excel_search(3, 0);
		TimeUnit.SECONDS.sleep(3);
		s.search_single(product);
		screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn4.jpg");
		TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I see no results on the screen with a message,no results found\\.$")
	public void i_see_no_results_on_the_screen_with_a_message_no_results_found() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 System.out.println("done"); 
	 TimeUnit.SECONDS.sleep(3);
	}
	
	
	

}
