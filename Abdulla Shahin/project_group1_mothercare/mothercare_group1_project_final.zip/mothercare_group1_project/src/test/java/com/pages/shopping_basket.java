package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class shopping_basket 
{
	WebDriver driver;
	
	By baby=By.id("ui-id-6");
	By prod1=By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]/div/div/a[1]");
	By age=By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[1]/a/label");
	By prod=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]/ol/li[2]/div/div/div[4]/div/div[1]");
	By basket=By.xpath("//*[@id=\"product-addtocart-button\"]");
	By view=By.xpath("/html/body/div[2]/header/div[2]/div[4]/a/span");
	By clickhomepage = By.id("ui-id-3");
	
	public shopping_basket(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void baby_click()
	{
		
		driver.findElement(baby).click();
	}
	public void prod_click()
	{
		driver.findElement(prod1).click();
	}
	public void ag()
	{
		driver.findElement(age).click();
	}
	
	public void prod_sel()
	{
		driver.findElement(prod).click();
	}
	
	public void add_to()
	{
		driver.findElement(basket).click();
	}
	
	public void view_basket()
	{
		driver.findElement(view).click();
	}
	
	public void clickhomepage()
	{
		driver.findElement(clickhomepage).click();
	}

}
