package com.stepDefinition;

import baseclass.wrapperclass;
import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class invalidadd_teststep extends wrapperclass {
	
	@Given("^user is at address page$")
	public void user_is_at_address_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user is at address page");
	    
	}

	@Given("^user click on add address$")
	public void user_click_on_add_address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addaddres();
	   
	}

	@Then("^user click on save$")
	public void user_click_on_save() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_save();
	}



}
