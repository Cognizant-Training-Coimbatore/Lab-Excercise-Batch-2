package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import excelutility.excel_utility;
import baseclass.wrapperclass;
import com.pages.storefinder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class storefinder_teststep extends wrapperclass{


@Given("^user has logged in to the homepage$")
public void user_has_logged_in_to_the_homepage() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	JavascriptExecutor js= (JavascriptExecutor)driver;
	js.executeScript("scroll(0,-400);");
	 System.out.println("logged in");
}

@When("^user clicks the store finder icon$")
public void user_clicks_the_store_finder_icon() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	storefinder s=new  storefinder(driver);
	s.click_store();
	
}

@When("^user enters the valid city name$")
public void user_enters_the_valid_city_name() throws Exception {
    // Write code here that turns the phrase above into concrete actions
      storefinder s=new storefinder(driver);
  	excel_utility e=new excel_utility();
  	String place=e.read_excel_store(1, 0);
  	s.search_type(place);
}

@When("^user clicks on search button$")
public void user_clicks_on_search_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   storefinder s=new storefinder(driver);
   s.click_search();
  
}

@Then("^the user selects a  city$")
public void the_user_selects_a_city() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	System.out.println("valid displayed");
   
}

@Given("^user has logged in to website$")
public void user_has_logged_in_to_website() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("given 2");
	
  
}

@When("^user clicks  store finder$")
public void user_clicks_store_finder() throws Exception {
    // Write code here that turns the phrase above into concrete actions
//	storefinder s=new  storefinder(driver);
//	s.click_store();
	System.out.println("hey");
	
	
   
}

@When("^user enters an  invalid city name$")
public void user_enters_an_invalid_city_name() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	  storefinder s=new storefinder(driver);
	  	excel_utility e=new excel_utility();
	  	String place=e.read_excel_store(2, 0);
	  	s.search_type(place);
}

@When("^user clicks on search$")
public void user_clicks_on_search() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	  storefinder s=new storefinder(driver);
	   s.click_search();
	  
}

@Then("^no place is displayed$")
public void no_place_is_displayed() throws Exception {
    // Write code here that turns the phrase above into concrete actions
    System.out.println("invalid");
}

@Given("^user has logged in the site$")
public void user_has_logged_in_the_site() throws Exception {
    // Write code here that turns the phrase above into concrete actions
System.out.println("given 3");
}

@When("^the user clicks on store finder$")
public void the_user_clicks_on_store_finder() throws Exception {
    // Write code here that turns the phrase above into concrete actions
//	storefinder s=new  storefinder(driver);
//	s.click_store();
	System.out.println("hey2");
	
}

@When("^user does not enter any value$")
public void user_does_not_enter_any_value() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.id("address")).clear();
	
 System.out.println("no value");
}

@When("^user clicks on search icon$")
public void user_clicks_on_search_icon() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	  storefinder s=new storefinder(driver);
	   s.click_search();
	 
}

@Then("^all the locations are displayed by default$")
public void all_the_locations_are_displayed_by_default() throws Exception {
    // Write code here that turns the phrase above into concrete actions
      System.out.println("hello");
      
      
}
@Then("^go back to home page$")
public void go_back_to_home_page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   storefinder s=new storefinder(driver);
   s.back_home();



}

}
