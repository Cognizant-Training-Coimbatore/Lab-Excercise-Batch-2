package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class wishlist 
{
	WebDriver driver;
	By baby=By.id("ui-id-6");
	By prod1=By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]/div/div/a[1]");
	By ag=By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[1]/a/label");
	By prod=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]/ol/li[1]/div/div/div[4]/div/div[1]");
	By add_wish=By.xpath("//*[@id=\"maincontent\"]/div/div/div[1]/div[7]/div/a/span");
	By clickwishlist = By.linkText("wish list");
	By clickhomepage = By.id("ui-id-3");
	
	public wishlist(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void baby_click()
	{
		driver.findElement(baby).click();
	}
	
	public void prod()
	{
		driver.findElement(prod1).click();
	}
	
	public void wish()
	{
		driver.findElement(ag).click();
	}
	public void sel_prod()
	{
		driver.findElement(prod).click();
	}
	
	public void wishlist_add()
	{
		driver.findElement(add_wish).click();
	}
	
	public void clickwishlist()
	{
		driver.findElement(clickwishlist).click();
	}
	
	public void clickhomepage()
	{
		driver.findElement(clickhomepage).click();
	}
	

}
