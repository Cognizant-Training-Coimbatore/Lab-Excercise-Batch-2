package com.stepDefinition;

import baseclass.wrapperclass;

import java.util.concurrent.TimeUnit;

import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class deleteaddress_teststep extends wrapperclass {
	
	@Given("^user is in address page$")
	public void user_is_in_address_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("user is in address page");
	}

	@When("^user clicks on address book$")
	public void user_clicks_on_address_book() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addressbook1();
		    
	}

	@When("^user clicks on delete$")
	public void user_clicks_on_delete() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		TimeUnit.SECONDS.sleep(5);
		obj.click_delete();
		TimeUnit.SECONDS.sleep(5);
		obj.click_ok();
		TimeUnit.SECONDS.sleep(5);
	   
	}
	
	@Then("^user clicks homepage icon$")
	public void user_clicks_homepage_icon() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		addressbook obj=new addressbook(driver);
		obj.click_home();
	   
	}




}
