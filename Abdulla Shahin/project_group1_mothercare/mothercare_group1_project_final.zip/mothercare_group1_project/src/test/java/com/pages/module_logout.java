package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class module_logout extends wrapperclass
{
	By clicklogout = By.xpath("/html/body/div[2]/header/div[1]/div/ul/li[1]/a[1]");
	
	public module_logout(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void clicklogout()
	{
		driver.findElement(clicklogout).click();
	}
}
