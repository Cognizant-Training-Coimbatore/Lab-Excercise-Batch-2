package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import baseclass.wrapperclass;

public class addressbook extends wrapperclass {
	
	
//	By myaccount=By.xpath("//*[@class='my-account']");
	
	//By addressbook=By.xpath("//*[@class='account_content_image my_address']");
	//By addimg=By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[2]/div/div/div[2]/div/div/a[2]/div/div/div[1]/img");
	
	WebDriver driver;
	By myaccount=By.xpath("/html/body/div[2]/header/div[1]/div/ul/li[1]/a[2]");
	
	By a=By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[2]/div/div/div[2]/div/div/a[2]/div/div");
	
	By b=By.xpath("//*[@id=\"block-collapsible-nav\"]/ul/li[5]/a");
	
	//By ok=By.xpath("/html/body/div[3]/aside[3]/div[2]/footer/button[2]");
	By ok=By.xpath("/html/body/div[3]/aside[3]/div[2]/footer/button[2]");
	///html/body/div[3]/aside[3]/div[2]/footer/button[2]
	
	
	By addaddress=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[4]/div[1]/button");
	
	By pnumber=By.id("telephone");
	By streetadd1=By.id("street_1");
	By streetadd2=By.id("street_2");
	By city=By.id("city");
	By state=By.id("region_id");
	By zip=By.id("zip");
	By country=By.id("country");
	By save=By.xpath("//*[@class='action save primary']");
	By delete=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[3]/div[2]/ol/li[1]/div/a[2]");
	By home=By.xpath("/html/body/div[2]/div[2]/ul/li[1]/a");
	
	
	public addressbook(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
public void click_myaccount()
{
	driver.findElement(myaccount).click();
}
	
public void click_addressbook()
{
//	driver.findElement(addimg).click();
//	driver.findElement(addressbook).click();
	
	//System.out.println("hello");

	driver.findElement(a).click();

}


public void click_addressbook1()
{
	driver.findElement(b).click();
}
	
public void click_addaddres()
{
	driver.findElement(addaddress).click();
}
	

public void enter_pnumber(String s)
{
	driver.findElement(pnumber).sendKeys(s);
}

public void enter_streetadd1(String s1)
{
	
	driver.findElement(streetadd1).sendKeys(s1);
}

public void enter_streetadd2(String s2)
{
	
	driver.findElement(streetadd2).sendKeys(s2);
}


public void enter_city(String s3)
{
	driver.findElement(city).sendKeys(s3);
}

public void select_state(String s4) {
	Select state1=new Select(driver.findElement(state));
	state1.selectByVisibleText(s4);
}

public void enter_zip(String s5)
{

	driver.findElement(zip).sendKeys(s5);
}

public void select_country(String s6) {
	Select ctr=new Select(driver.findElement(country));
	ctr.selectByVisibleText(s6);
}



public void click_save()
{
	driver.findElement(save).click();
}


public void click_delete()
{
	driver.findElement(delete).click();
}

public void click_ok()
{
	driver.findElement(ok).click();
}
	
public void click_home()
{
	driver.findElement(home).click();
}
}
