package com.stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.Excel_data;
import com.pages.module_1;
import com.pages.wishlist;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class wishlist_teststep extends wrapperclass
{
	
	@Given("^user is logged in again$")
	public void user_is_logged_in_again() throws Exception {
	    System.out.println("the user is logged in");
	}

	@When("^user clicks  category babycare$")
	public void user_clicks_category_babycare() throws Exception
	{
		wishlist obj=new wishlist(driver);
		obj.baby_click();
				
	  
	}

	@When("^user selects a subcategory from the list$")
	public void user_selects_a_subcategory_from_the_list() throws Exception 
	{
		wishlist obj=new wishlist(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel5(2,1);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]"));
		statement1:
		for(WebElement e1 : main)
		{
		System.out.println(e1.getText());
		if(e1.getText().contains(cat))
		{
			System.out.println(cat);
		obj.prod();
		break statement1;
		}
		}
		
	    
	   
	}

	@When("^user selects age filter$")
	public void user_selects_age_filter() throws Exception 
	{

		wishlist obj=new wishlist(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel5(2,2);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol"));
		statement1:
		for(WebElement e2 : main)
		{
		System.out.println(e2.getText());
		if(e2.getText().contains(cat))
		{
			System.out.println(cat);
			obj.wish();
		TimeUnit.SECONDS.sleep(5);
		break statement1;
		
		}
		}
	  
	}

	@When("^user selects the product$")
	public void user_selects_the_product() throws Exception
	{
		TimeUnit.SECONDS.sleep(7);
		wishlist obj=new wishlist(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel5(2,3);
		System.out.println(cat);
		//List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]"));
		List<WebElement> main =driver.findElements(By.xpath("/html/body/div[3]/main/div[2]/div[1]/div[6]/ol"));
		statement1:
		for(WebElement e3 : main)
		{
		System.out.println(e3.getText());
		if(e3.getText().contains(cat))
		{
			System.out.println(cat);
		obj.sel_prod();
		TimeUnit.SECONDS.sleep(3);
		break statement1;
		}
		}
	    
	}

	@Then("^user add the product to wishlist$")
	public void user_add_the_product_to_wishlist() throws Exception
	{
		wishlist obj=new wishlist(driver);
		obj.wishlist_add();
		TimeUnit.SECONDS.sleep(5);
		screenshot("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\screenshots\\scrn7.jpg");
	   
	}
	
	@Then("^user clicks wishlist$")
	public void user_clicks_wishlist() throws Exception {
		wishlist obj=new wishlist(driver);
		obj.clickwishlist();
	}

	@Then("^user clicks homepage$")
	public void user_clicks_homepage() throws Exception {
		wishlist obj=new wishlist(driver);
		obj.clickhomepage();
	}


}
