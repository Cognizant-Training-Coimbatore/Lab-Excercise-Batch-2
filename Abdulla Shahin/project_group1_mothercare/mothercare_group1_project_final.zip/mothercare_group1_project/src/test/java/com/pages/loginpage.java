package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage {
	
	
	WebDriver driver;
	By join=By.linkText("join my mothercare");
	By em=By.id("email");
	By passw=By.id("pass");
	By sub=By.id("send2");
	By baby=By.id("ui-id-6");
	
	public loginpage(WebDriver driver)
	{
		this.driver=driver;
	}
	public void login() throws InterruptedException
	{
		driver.findElement(join).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void user_login(String user,String pass)
	{
		driver.findElement(em).sendKeys(user);
		driver.findElement(passw).sendKeys(pass);
		driver.findElement(sub).click();
		
	}
	


}
