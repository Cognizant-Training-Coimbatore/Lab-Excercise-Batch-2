package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.pages.login_page;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login_teststep_dup extends wrapperclass
{
	@Given("^The application is launched$")
	public void the_application_is_launched() throws Exception 
	{
	    launchApplication("chrome", "https://www.mothercare.in/");
	}

	@When("^The user navigates to login page$")
	public void the_user_navigates_to_login_page() throws Exception 
	{
	   login_page obj = new login_page(driver);
	   obj.clicklogin();
	}

	@When("^The user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enters_and(String arg1, String arg2) throws Exception 
	{
		login_page obj = new login_page(driver);
		obj.login(arg1,arg2);
	}

	@Then("^The user is able to login$")
	public void the_user_is_able_to_login() throws Exception 
	{
		login_page obj = new login_page(driver);
		obj.signin();
		TimeUnit.SECONDS.sleep(2);
		
	}

}
