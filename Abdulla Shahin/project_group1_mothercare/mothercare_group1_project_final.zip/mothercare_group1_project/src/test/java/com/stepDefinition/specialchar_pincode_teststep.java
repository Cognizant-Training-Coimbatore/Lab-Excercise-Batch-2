package com.stepDefinition;

import baseclass.wrapperclass;
import excelutility.excel;
import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class specialchar_pincode_teststep extends wrapperclass {
	
	@Given("^The user is in address page$")
	public void the_user_is_in_address_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user is address page");
	}

	@When("^the user click on add address button$")
	public void the_user_click_on_add_address_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addressbook1();
	    obj.click_addaddres();
	}

	@When("^the user enters contact informations$")
	public void the_user_enters_contact_informations() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_pnumber(dat.excel_pnumber(7));
	    
	}

	@When("^The user enters address$")
	public void the_user_enters_address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_streetadd1(dat.excel_street1(7));
		obj.enter_streetadd2(dat.excel_street2(7));
		obj.enter_city(dat.excel_city(7));
		obj.select_state(dat.excel_state(7));
		obj.enter_zip(dat.excel_zip(7));
		obj.select_country(dat.excel_country(7));
	}

	@Then("^the user click on save button$")
	public void the_user_click_on_save_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		addressbook obj=new addressbook(driver);
		obj.click_save();
	    
	   
	   
	}



}
