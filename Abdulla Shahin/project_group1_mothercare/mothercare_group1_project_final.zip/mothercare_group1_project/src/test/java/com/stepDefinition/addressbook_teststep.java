package com.stepDefinition;

import baseclass.wrapperclass;
import excelutility.excel;

import java.util.concurrent.TimeUnit;

import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class addressbook_teststep extends wrapperclass {
	
	
	@Given("^user is logged in$")
	public void user_is_logged_in() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("user is logged into the site");
	}

	@When("^user clicks on my account$")
	public void user_clicks_on_my_account() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_myaccount();
	}

	@When("^user clicks on Address Book$")
	public void user_clicks_on_Address_Book() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addressbook();
		TimeUnit.SECONDS.sleep(5);
	   
	}

	@When("^user clicks on Add New Address$")
	public void user_clicks_on_Add_New_Address() throws Exception {
		TimeUnit.SECONDS.sleep(5);
		addressbook obj=new addressbook(driver);
		obj.click_addaddres();
		TimeUnit.SECONDS.sleep(5);
	}

	@When("^user enters contact information$")
	public void user_enters_contact_information() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	addressbook obj=new addressbook(driver);
	excel dat=new excel();
	obj.enter_pnumber(dat.excel_pnumber(1));
	    
	}

	@When("^user enters Address$")
	public void user_enters_Address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_streetadd1(dat.excel_street1(1));
		obj.enter_streetadd2(dat.excel_street2(1));
		obj.enter_city(dat.excel_city(1));
		obj.select_state(dat.excel_state(1));
		obj.enter_zip(dat.excel_zip(1));
		obj.select_country(dat.excel_country(1));
		TimeUnit.SECONDS.sleep(5);
	}

	@When("^user clicks on Save Address$")
	public void user_clicks_on_Save_Address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_save();
		TimeUnit.SECONDS.sleep(5);
	}



}

