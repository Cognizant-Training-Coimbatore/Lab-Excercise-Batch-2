package com.stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.Excel_data;
import com.pages.module_1;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class teststeps_babycare extends wrapperclass
{
	@Given("^the user is logged in$")
	public void the_user_is_logged_in() throws Exception {
	    System.out.println("user is logged in");
	}

	@When("^the user clicks  category babycare$")
	public void the_user_clicks_category_babycare() throws Exception {
	  
		module_1 obj=new module_1(driver);
		obj.baby_click();
	    
	}

	@When("^the user selects a subcategory from the list$")
	public void the_user_selects_a_subcategory_from_the_list() throws Exception
	{
		module_1 obj=new module_1(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel(1);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]"));
		statement1:
		for(WebElement e1 : main)
		{
		System.out.println(e1.getText());
		if(e1.getText().contains(cat))
		{
			System.out.println(cat);
		obj.prod();
		break statement1;
		}
		}
		}
	    
	

	@When("^the user selects age filter$")
	public void the_user_selects_age_filter() throws Exception 
	{
		module_1 obj=new module_1(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel1(1);
		System.out.println(cat);
		List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol"));
		statement1:
		for(WebElement e2 : main)
		{
		System.out.println(e2.getText());
		if(e2.getText().contains(cat))
		{
			System.out.println(cat);
		obj.age();
		TimeUnit.SECONDS.sleep(5);
		break statement1;
		
		}
		}
		}
	    
	

	@When("^the user selects the product$")
	public void the_user_selects_the_product() throws Exception 
	{
		TimeUnit.SECONDS.sleep(10);
		module_1 obj=new module_1(driver);
		Excel_data ob=new Excel_data();
		String cat=ob.read_excel2(1);
		System.out.println(cat);
		//List<WebElement> main = driver.findElements(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]"));
		List<WebElement> main =driver.findElements(By.xpath("/html/body/div[3]/main/div[2]/div[1]/div[6]/ol"));
		statement1:
		for(WebElement e3 : main)
		{
		System.out.println(e3.getText());
		if(e3.getText().contains(cat))
		{
			System.out.println(cat);
		obj.p1();
		TimeUnit.SECONDS.sleep(3);
		break statement1;
		}
		}
	}
	    
	

	@When("^the product added to the basket$")
	public void the_product_added_to_the_basket() throws Exception 
	{
		module_1 obj=new module_1(driver);
		obj.addto();
	    
	
	}
	@When("^the user clicks view basket$")
	public void the_user_clicks_view_basket() throws Exception 
	{
		module_1 obj=new module_1(driver);
		obj.viewbasket();
	    
	}

	@Then("^the user checkout$")
	public void the_user_checkout() throws Exception
	{
		module_1 obj=new module_1(driver);
		obj.checkout();
		obj.clickhomepage();
	    
	}



}
