package com.stepDefinition;

import baseclass.wrapperclass;
import excelutility.excel;
import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class specialchar_pno_teststep extends wrapperclass {
	
	@Given("^The user is at address page$")
	public void the_user_is_at_address_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user is address page");
	}

	@When("^The user clicks on add address button$")
	public void the_user_clicks_on_add_address_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addressbook1();
	    obj.click_addaddres();
	    
	}

	@When("^The user enter contact informations$")
	public void the_user_enter_contact_informations() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_pnumber(dat.excel_pnumber(5));
	    
	    
	}

	@When("^The user enters Address$")
	public void the_user_enters_Address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_streetadd1(dat.excel_street1(5));
		obj.enter_streetadd2(dat.excel_street2(5));
		obj.enter_city(dat.excel_city(5));
		obj.select_state(dat.excel_state(5));
		obj.enter_zip(dat.excel_zip(5));
		obj.select_country(dat.excel_country(5));
	    
	}

	@Then("^The user clicks on save button$")
	public void the_user_clicks_on_save_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		addressbook obj=new addressbook(driver);
		obj.click_save();
	    
	}



}
