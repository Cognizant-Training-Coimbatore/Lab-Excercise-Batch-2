package com.stepDefinition;

import baseclass.wrapperclass;
import excelutility.excel;
import com.pages.addressbook;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class spcialchar_city_teststep extends wrapperclass{
	
	@Given("^the user is in address page$")
	public void the_user_is_in_address_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user is address page");
	}

	@When("^The user click on add address button$")
	public void the_user_click_on_add_address_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		obj.click_addressbook1();
	    obj.click_addaddres();
	   
	}

	@When("^The user enters contact informations$")
	public void the_user_enters_contact_informations() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_pnumber(dat.excel_pnumber(6));
	    
	   
	}

	@When("^The user enter Address$")
	public void the_user_enter_Address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		addressbook obj=new addressbook(driver);
		excel dat=new excel();
		obj.enter_streetadd1(dat.excel_street1(6));
		obj.enter_streetadd2(dat.excel_street2(6));
		obj.enter_city(dat.excel_city(6));
		obj.select_state(dat.excel_state(6));
		obj.enter_zip(dat.excel_zip(6));
		obj.select_country(dat.excel_country(6));
	    
	   
	}

	@Then("^The user click on save button$")
	public void the_user_click_on_save_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions

		addressbook obj=new addressbook(driver);
		obj.click_save();
	    
	   
	}


	
	

}
