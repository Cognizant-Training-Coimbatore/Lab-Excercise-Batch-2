package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Module_sale
{
	WebDriver driver;
	By sale=By.id("ui-id-8");
	By new_born_clothes=By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul/li[1]/a");
	By subcategory=By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul/ul/li[1]/a");
	By age=By.xpath("/html/body/div[3]/main/div[3]/div[2]/div/div[2]/div[3]/div[3]/div[2]/ol/li[3]/a");
	By product=By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[6]/ol/li[1]/div/div/div[4]/div/div[1]/button/span");
	By add=By.id("product-addtocart-button");
	By basket=By.xpath("/html/body/div[2]/header/div[2]/div[4]");
	By checkout=By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[3]/div/div[2]/div[3]/button");
	By baby_clothes=By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul/li[2]/a");
	By subcategory2=By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul/ul/li[2]/a");
	By age2=By.xpath("/html/body/div[3]/main/div[3]/div[2]/div/div[2]/div[3]/div[3]/div[2]/ol/li[1]/a/label");
	By product2=By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[6]/ol/li[3]/div/div/div[4]/div/div[1]/button/span");
	
	public Module_sale(WebDriver driver)
	{
		this.driver=driver;
	}
	public void sales()
	{
		driver.findElement(sale).click();
	}
	public void category()
	{
		driver.findElement(new_born_clothes).click();
	}
	public void category2()
	{
		driver.findElement(baby_clothes).click();
	}
	public void subcategory()
	{
		driver.findElement(subcategory).click();
	}
	public void subcategory2()
	{
		driver.findElement(subcategory2).click();
	}
	public void agefilter()
	{
		driver.findElement(age).click();
	}
	public void agefilter2()
	{
		driver.findElement(age2).click();
	}
	public void product()
	{
		driver.findElement(product).click();
	}
	public void product2()
	{
		driver.findElement(product2).click();
	}
	public void cart()
	{
		driver.findElement(add).click();
	}
	public void basket()
	{
		driver.findElement(basket).click();
	}
	public void checkout()
	{
		driver.findElement(checkout).click();
	}
	public void close()
	{
		driver.close();
	}
}
