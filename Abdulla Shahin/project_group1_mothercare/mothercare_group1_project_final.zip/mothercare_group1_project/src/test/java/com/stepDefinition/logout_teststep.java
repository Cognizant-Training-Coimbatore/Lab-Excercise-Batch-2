package com.stepDefinition;

import com.pages.module_logout;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class logout_teststep extends wrapperclass
{
	@Given("^I am logged in on the site$")
	public void i_am_logged_in_on_the_site() throws Exception {
	    System.out.println("The user is logged in");
	}

	@When("^I click the Log out button$")
	public void i_click_the_Log_out_button() throws Exception {
	    module_logout obj = new module_logout(driver);
	    obj.clicklogout();
	}

	@Then("^I cannot visit my account page anymore and reaches the homepage$")
	public void i_cannot_visit_my_account_page_anymore_and_reaches_the_homepage() throws Exception {
	    System.out.println("The user cannot visit account page anymore and reaches the homepage");
	}

}
