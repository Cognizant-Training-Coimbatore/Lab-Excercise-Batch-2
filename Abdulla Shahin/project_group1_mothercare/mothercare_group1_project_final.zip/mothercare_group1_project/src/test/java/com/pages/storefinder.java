package com.pages;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class storefinder extends wrapperclass{
	
	public storefinder(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	public void click_store()
	{
		driver.findElement(By.xpath("/html/body/div[2]/header/div[2]/div[3]/a")).click();
	}
   public void search_type(String place)
   {
	   driver.findElement(By.id("address")).clear();
	   driver.findElement(By.id("address")).sendKeys(place);
   }
   public void click_search() throws InterruptedException
   {
	   driver.findElement(By.id("submit")).click();
	 
	  
   }
   public void back_home()
   {
	   driver.findElement(By.id("ui-id-4")).click();
   }
   
}
