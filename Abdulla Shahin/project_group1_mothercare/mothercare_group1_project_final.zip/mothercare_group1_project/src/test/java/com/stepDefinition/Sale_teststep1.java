package com.stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.pages.Module_sale;
import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.excelread;

public class Sale_teststep1 extends wrapperclass
{
	
	//Sales-new born clothes
	@Given("^The user is logged in$")
	public void the_user_is_logged_in() throws Exception {
	    System.out.println("User logged in");
	}

	@When("^The user clicks Sale$")
	public void the_user_clicks_Sale() throws Exception {
		TimeUnit.SECONDS.sleep(5);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, -350);");
		Module_sale obj1=new Module_sale(driver);
		obj1.sales();

	}

	@When("^The user selects a category$")
	public void the_user_selects_a_category() throws Exception  {
		TimeUnit.SECONDS.sleep(10);
		Module_sale obj1=new Module_sale(driver);
		excelread obj=new excelread();
		String cat=obj.Category(1,0);
		
		List<WebElement> maincategory = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul"));
	
		for(WebElement a1 : maincategory)
		{
			try {
		if(a1.getText().contains(cat))
		{
			obj1.category();
		break;
		}
		}
			catch(Exception e)
			{
				System.out.println("Fail");
			}
		}
	}
	@When("^The user selects a subcategory$")
	public void the_user_selects_a_subcategory() throws Exception {
			TimeUnit.SECONDS.sleep(10);
			Module_sale obj1=new Module_sale(driver);
		
			excelread obj=new excelread();
			String sub=obj.Subcategory(1,1);
			
			List<WebElement> subcategory = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[2]/div[2]/ul/ul/ul"));
			
			for(WebElement b1 : subcategory)
			{
				try {
			if(b1.getText().contains(sub))
			{
				obj1.subcategory();
				TimeUnit.SECONDS.sleep(10);
			break;
			}
			
			}
				catch(Exception e)
				{
					System.out.println("Fail");
				}
			}
	}

	@When("^The user selects age filter$")
	public void the_user_selects_age_filter() throws Exception {
		TimeUnit.SECONDS.sleep(10);
		Module_sale obj1=new Module_sale(driver);
		excelread obj3=new excelread();
		String agefilter=obj3.Subcategory(1,2);
		System.out.println(agefilter);
		List<WebElement> age = driver.findElements(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol"));
		
		for(WebElement c1 : age)
		{
			try {
		if(c1.getText().contains(agefilter))
		{
			System.out.println(agefilter);
			obj1.agefilter();
			TimeUnit.SECONDS.sleep(10);
			
		break;
		}
		}
	  catch(Exception e)
			{
		  		System.out.println("Fail");
			}
		}
	}

	@When("^The user selects product$")
	public void the_user_selects_product() throws Exception {
		TimeUnit.SECONDS.sleep(15);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 350);");
		excelread obj4=new excelread();
		Module_sale obj1=new Module_sale(driver);
		String Product=obj4.product(1,3);
		List<WebElement> products = driver.findElements(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[6]"));
		
		for(WebElement d1 : products)
		{
			try {
		if(d1.getText().contains(Product))
		{
			
			obj1.product();
			System.out.println(Product);
		break;
		}
		
		}
			catch(Exception e)
			{
				System.out.println("Fail");
			}
		}
	}

	@When("^The product added to the basket$")
	public void the_product_added_to_the_basket() throws Exception {
		TimeUnit.SECONDS.sleep(5);
		Module_sale obj1=new Module_sale(driver);
		obj1.cart();
	  
	}

	@When("^The user clicks view basket$")
	public void the_user_clicks_view_basket() throws Exception {
		TimeUnit.SECONDS.sleep(5);
		Module_sale obj1=new Module_sale(driver);
		obj1.basket();
	}

	@Then("^The user checkout$")
	public void the_user_checkout() throws Exception {
		TimeUnit.SECONDS.sleep(10);
		Module_sale obj1=new Module_sale(driver);
		obj1.checkout();
		TimeUnit.SECONDS.sleep(5);
		//quit();
	}

	
}




