package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class module_1 
{
	
	WebDriver driver;
	By baby=By.id("ui-id-6");
	By prod1=By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[1]/div/div/a[1]");
	By ag=By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[1]/a/label");
	//By ag=By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[2]/a/label");
	//By prod=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]/ol/li/div/div/div[4]/div/div[1]");
	By prod=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]/ol/li[3]/div/div/div[4]/div/div[1]");
	By basket=By.xpath("//*[@id=\"product-addtocart-button\"]");
	By view=By.xpath("/html/body/div[2]/header/div[2]/div[4]/a/span");
	By check=By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[3]/div/div[2]/div[3]/button");
	
	By prod2=By.xpath("//*[@id=\"clp-category-list\"]/div[1]/ul/li[2]/div/div/a[1]");
	By age=By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li/a/label");
	By pr=By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[6]/ol/li[1]/div/div/div[4]/div/div[1]");
	By basket1=By.xpath("//*[@id=\"product-addtocart-button\"]");
	By view1=By.xpath("/html/body/div[2]/header/div[2]/div[4]/a/span");
	By check1=By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[3]/div/div[2]/div[3]/button");
	By clickhomepage = By.id("ui-id-3");
	
	
	
	public module_1(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void baby_click()
	{
		driver.findElement(baby).click();
	}
	
	public void prod()
	{
		driver.findElement(prod1).click();
	}
	
	public void age()
	{
		driver.findElement(ag).click();
	}
	public void p1()
	{
		driver.findElement(prod).click();
	}
	public void addto()
	{
		driver.findElement(basket).click();
	}
	public void viewbasket()
	{
		driver.findElement(view).click();
		
	}
	public void checkout()
	{
		driver.findElement(check).click();
	}
	
	public void bab()
	{
		driver.findElement(baby).click();
	}
	public void prod_2()
	{
		driver.findElement(prod2).click();
	}
	public void ag()
	{
		driver.findElement(age).click();
	}
	public void pro()
	{
		driver.findElement(pr).click();
	}
	public void bas()
	{
		driver.findElement(basket1).click();
	}
	public void vie()
	{
		driver.findElement(view1).click();
	}
	public void ch()
	{
		driver.findElement(check1).click();
	}
	public void clickhomepage()
	{
		driver.findElement(clickhomepage).click();
	}
	
	
}
