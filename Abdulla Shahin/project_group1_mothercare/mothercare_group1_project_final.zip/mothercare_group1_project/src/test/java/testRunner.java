import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(format= {"pretty", "json:target/output.json", "html:target/html"},
		features= {"src\\test\\resources\\com\\features\\1login_og.feature",  "src\\test\\resources\\com\\features\\2accinfo.feature","src\\test\\resources\\com\\features\\3wishlist.feature", "src\\test\\resources\\com\\features\\4shoppingbasket.feature","src\\test\\resources\\com\\features\\5storefinder.feature", "src\\test\\resources\\com\\features\\6search.feature","src\\test\\resources\\com\\features\\7sale.feature", "src\\test\\resources\\com\\features\\8babycare.feature", "src\\test\\resources\\com\\features\\9logout.feature"}, 
		glue= {"com.stepDefinition"})
public class testRunner {

}
