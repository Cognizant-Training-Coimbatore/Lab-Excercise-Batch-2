package excelutility;


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class excel_utility 
	{
		
	public String read_excel(int a,int b) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream file=new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\javaprograms\\mothercare\\src\\test\\resources\\com\\testdata\\mothercare.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");

		XSSFRow row=sheet.getRow(a);
		XSSFCell cell=row.getCell(b);
		String category=cell.getStringCellValue();
		return category;
		
	}
	
	public String read_excel_search(int a,int b) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet2");

		XSSFRow row=sheet.getRow(a);
		XSSFCell cell=row.getCell(b);
		String category=cell.getStringCellValue();
		return category;
		
}
	public String read_excel_store(int a,int b) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet3");

		XSSFRow row=sheet.getRow(a);
		XSSFCell cell=row.getCell(b);
		String category=cell.getStringCellValue();
		return category;
	}
}