package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelread 
{
	public String Category(int a,int b) throws IOException {
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_testdata.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(b);
			String category=cell.getStringCellValue();
			return category;
	}
	public String Subcategory(int c,int d) throws IOException {
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_testdata.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
			XSSFRow row=sheet.getRow(c);
			XSSFCell cell=row.getCell(d);
			String subcategory=cell.getStringCellValue();
			return subcategory;
	}
	public String age(int e,int f) throws IOException {
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_testdata.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
			XSSFRow row=sheet.getRow(e);
			XSSFCell cell=row.getCell(f);
			String age=cell.getStringCellValue();
			return age;
	}
	public String product(int g,int h) throws IOException {
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_testdata.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
			XSSFRow row=sheet.getRow(g);
			XSSFCell cell=row.getCell(h);
			String product=cell.getStringCellValue();
			return product;
	}
}

