package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
	
	public  String excel_pnumber(int n)throws IOException, InvalidFormatException{
		
		File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell1 =row.getCell(0);
	    String s1 =cell1.getStringCellValue();
	    return s1;
	}
		
	public String excel_street1(int n) throws InvalidFormatException, IOException
	{

		File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell2 =row.getCell(1);
		 String s2 =cell2.getStringCellValue();
		return s2;
	}
	
	
	public String excel_street2(int n) throws InvalidFormatException, IOException
	{

		File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		
		XSSFCell cell3 =row.getCell(2);
		 String s3 =cell3.getStringCellValue();
	return s3;
	}
	
	public String excel_city(int n) throws InvalidFormatException, IOException
	{

		File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell4 =row.getCell(3);
		 String s4 =cell4.getStringCellValue();
	return s4;
	}

	
	public String excel_state(int n) throws InvalidFormatException, IOException
	{
        File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell5 =row.getCell(4);
		 String s5 =cell5.getStringCellValue();
		return s5;
	}
	
	public String excel_zip(int n) throws InvalidFormatException, IOException
	{
		File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
		
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);

		XSSFCell cell6 =row.getCell(5);
		 String s6 =cell6.getStringCellValue();
	return s6;
	}
	
	public String excel_country(int n) throws InvalidFormatException, IOException
	{File fil=new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx");
	
	@SuppressWarnings("resource")
	XSSFWorkbook workbook=new XSSFWorkbook(fil);
	XSSFSheet sheet=workbook.getSheet("Sheet1");
	XSSFRow row = sheet.getRow(n);

		XSSFCell cell7 =row.getCell(6);
		 String s7 =cell7.getStringCellValue();
		return s7;
	}
		
	public String excel_module(int r,int c) throws IOException {
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\address.xlsx"));
		@SuppressWarnings("resource")
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet("Sheet2");

		XSSFRow row=sheet.getRow(r);
		XSSFCell cell=row.getCell(c);
		String category=cell.getStringCellValue();
		return category;
		}
		
		
		
		
		
}


