package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_data 
{
	public String read_excel(int a) throws IOException
	
	{
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
		XSSFWorkbook wk=new XSSFWorkbook(file);
		XSSFSheet sheet=wk.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
		
		XSSFRow row=sheet.getRow(a);
		XSSFCell cell=row.getCell(1);
		String pwd=cell.getStringCellValue();
		return pwd;
	}

public String read_excel1(int b) throws IOException
	
	{
		FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
		XSSFWorkbook wk=new XSSFWorkbook(file);
		XSSFSheet sheet=wk.getSheet("Sheet1");
		int count=sheet.getLastRowNum();
		System.out.println(count);
		
		XSSFRow row=sheet.getRow(b);
		XSSFCell cell1=row.getCell(2);
		String pwd=cell1.getStringCellValue();
		return pwd;
	}
public String read_excel2(int c) throws IOException

{
	FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
	XSSFWorkbook wk=new XSSFWorkbook(file);
	XSSFSheet sheet=wk.getSheet("Sheet1");
	int count=sheet.getLastRowNum();
	System.out.println(count);
	
	XSSFRow row=sheet.getRow(c);
	XSSFCell cell2=row.getCell(3);
	String pwd=cell2.getStringCellValue();
	return pwd;
}

public String read_excel3(int e,int f) throws IOException

{
	FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
	XSSFWorkbook wk=new XSSFWorkbook(file);
	XSSFSheet sheet=wk.getSheet("Sheet1");
	int count=sheet.getLastRowNum();
	System.out.println(count);
	
	XSSFRow row=sheet.getRow(e);
	XSSFCell cell2=row.getCell(f);
	String pwd=cell2.getStringCellValue();
	return pwd;
}
public String read_excel4(int e,int f) throws IOException

{
	FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
	XSSFWorkbook wk=new XSSFWorkbook(file);
	XSSFSheet sheet=wk.getSheet("Sheet1");
	int count=sheet.getLastRowNum();
	System.out.println(count);
	
	XSSFRow row=sheet.getRow(e);
	XSSFCell cell2=row.getCell(f);
	String pwd=cell2.getStringCellValue();
	return pwd;
}
public String read_excel5(int e,int f) throws IOException

{
	FileInputStream file=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_group1_project\\src\\test\\resources\\com\\testdata\\mothercare_data.xlsx"));
	XSSFWorkbook wk=new XSSFWorkbook(file);
	XSSFSheet sheet=wk.getSheet("Sheet1");
	int count=sheet.getLastRowNum();
	System.out.println(count);
	
	XSSFRow row=sheet.getRow(e);
	XSSFCell cell2=row.getCell(f);
	String pwd=cell2.getStringCellValue();
	return pwd;
}
}
