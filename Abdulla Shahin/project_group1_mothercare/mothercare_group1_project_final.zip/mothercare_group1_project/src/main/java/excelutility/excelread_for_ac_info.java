package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelread_for_ac_info 
{
	public String excel_read_pwd(int a, int b) throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\ac_info.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow row = sh.getRow(a);
		XSSFCell cell = row.getCell(b);
		String pwd = cell.getStringCellValue();
		
		return pwd;
	}
	
	public String excel_read_pwd2(int a,int b) throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\ac_info.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow row2 = sh.getRow(a);
		XSSFCell cell2 = row2.getCell(b);
		String pwd2 = cell2.getStringCellValue();
		System.out.println(pwd2);
		return pwd2;
	}
	
	public String excel_read_pwd3(int a, int b) throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("C:\\Users\\admin\\Desktop\\java\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\ac_info.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow row3 = sh.getRow(a);
		XSSFCell cell3 = row3.getCell(b);
		String pwd3 = cell3.getStringCellValue();
		
		return pwd3;
	}
}
