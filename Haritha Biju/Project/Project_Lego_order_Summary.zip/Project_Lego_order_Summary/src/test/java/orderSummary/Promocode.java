package orderSummary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseclass.WrapperClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class Promocode extends WrapperClass
{
	static WebElement mybag,promodrop,promobox,promoapply,error,export,acccookies,searchopen,search,fproduct,addtobag;
	static String promo,porf="Fail",product;
	int i,j=16;
	static ExcelReadWrite wc=new ExcelReadWrite();
	@Given("^I am on my bag page$")
	public void i_am_on_my_bag_page() throws Throwable
	{
		launchApplication("Chrome","https://www.lego.com/en-us");
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
		searchopen.click();
		product="Iron man";
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		TimeUnit.SECONDS.sleep(2);
		search.submit();
		TimeUnit.SECONDS.sleep(1);
		fproduct=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/a/h2/span"));
		fproduct.click();
		TimeUnit.SECONDS.sleep(2);
		addtobag=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[7]/div[1]/div[2]/button"));
		addtobag.click();
		driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div/ol/li[1]/a/span/span")).click();
		TimeUnit.SECONDS.sleep(2);
		mybag=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[1]/nav/ul[2]/li[3]/a"));
		mybag.click();
	}

	@When("^I enter a promocode$")
	public void i_enter_a_promocode() throws Throwable
	{
		for(i=16;i<=18;i++)
		{
		promo=wc.readExcelData(i);
		promodrop=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[2]/div/button/div"));
		promodrop.click();
		promobox=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[2]/div/div/div[1]/div/div/div/label/input"));
		promobox.click();
		promobox.sendKeys(promo);
		promoapply=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[2]/div/div/div[1]/div/button"));
		promoapply.click();
		TimeUnit.SECONDS.sleep(4);
		error=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[4]/div[1]/div/div[1]/div/div/div/label/span[2]"));
		System.out.println(error.getText());
		if(error.isDisplayed())
		{
			wc.writeExcelData("<Please enter a valid code> is displayed", i,5);
			System.out.println("Invalid code");
			j++;
		}
		else
		{
			wc.writeExcelData("<Please enter a valid code> is not displayed", i,5);
		}
		driver.navigate().refresh();
		TimeUnit.SECONDS.sleep(3);
		}

	}

	@Then("^I validate the outcomes$")
	public void i_validate_the_outcomes() throws Throwable
	{
		if(j==19)
		{
			porf="Pass";
		}
		System.out.println("Promocode "+porf+"ed");
		wc.writeExcelData(porf,19,6);
	
	}

}
