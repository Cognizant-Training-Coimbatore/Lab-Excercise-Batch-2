package orderSummary;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseclass.WrapperClass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class Shipment extends WrapperClass
{
	static int i=19,j=19;
	static String shipexcel,shipping,porf="Fail";
	static WebElement shipdrop,shipselect;
	static ExcelReadWrite wc=new ExcelReadWrite();
	
	@When("^I select a shipment option$")
	public void i_select_a_shipment_option() throws Throwable
	{
		List<WebElement> ship=driver.findElements(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[3]/div/div/label[*]/div[2]/div/span[1]"));
		System.out.println(ship);
		for(WebElement shipselect: ship)
		{
			j++;
		shipdrop=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[3]/div/button/div"));
		shipdrop.click();
		shipexcel=wc.readExcelData(i);
		i++;
		  shipping=shipselect.getText();
		  System.out.println(shipping);
		  if(shipping.equals(shipexcel))
		    {
		    shipselect.click();
		    TimeUnit.SECONDS.sleep(2);
		    }
		}
		driver.navigate().refresh();
		TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I validate the shipment option$")
	public void i_validate_the_shipment_option() throws Throwable
	{
		if(j==22)
		{
			porf="Pass";
		}
		System.out.println("Shipment "+porf+"ed");
		wc.writeExcelData(porf,22,6);
	    
	}


}
