package orderSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import baseclass.WrapperClass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class Pincode extends WrapperClass
{
	static WebElement zipbox,zipapply,checkout,error;
	static String zip,porf="Fail";
	static int i,j=22;
	JavascriptExecutor jse6 = (JavascriptExecutor) driver;
	static ExcelReadWrite wc=new ExcelReadWrite();
	@When("^I enter a pincode$")
	public void i_enter_a_pincode() throws Throwable 
	{
		for(i=22;i<=24;i++)
		{
		zipbox=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[4]/div[1]/div/div[1]/div/div/div/label/input"));
		zipbox.click();
		zip=wc.readExcelData(i);
		zipbox.sendKeys(zip);
		zipapply=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[4]/div[1]/div/div[1]/div/button"));
		zipapply.click();
		error=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[4]/div[1]/div/div[1]/div/div/div/label/span[2]"));
		if(i!=22)
		{
			if(error.isDisplayed())
			{
				wc.writeExcelData("<Something went wrong> is displayed", i,5);
				System.out.println("Invalid zip code");
				j++;
			}
		}
		}
	}

	@Then("^I validate whether the order can be placed$")
	public void i_validate_whether_the_order_can_be_placed() throws Throwable 
	{
		if(j==24)
		{
			porf="Pass";
		}
		System.out.println("Pincode "+porf+"ed");
		wc.writeExcelData(porf,24,6);
		checkout=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div/div[4]/div[2]/a/div"));
		checkout.click();
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		screenshot("C://Users//Admin//Pictures//Screenshots//total bill.PNG");
	
	}


}
