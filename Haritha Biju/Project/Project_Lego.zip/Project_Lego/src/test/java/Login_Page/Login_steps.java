package Login_Page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import baseclass.WrapperClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.excel_data;

public class Login_steps extends WrapperClass
{

	@Given("^I want to open the Lego Website$")
	public void i_want_to_open_the_Lego_Website() throws Throwable
	{
		launchApplication("chrome","https://www.lego.com/en-us");
	}

	@When("^I enter user name and password$")
	public void i_enter_user_name_and_password() throws Throwable 
	{
		login loginObj=new login(driver);
		excel_data excelObj=new excel_data();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button")).click();
		int j=1;int k=1;
		for(int i=1;i<5;i++)
		{	TimeUnit.SECONDS.sleep(1);
			loginObj.account();
			TimeUnit.SECONDS.sleep(1);
			loginObj.signIn();
			TimeUnit.SECONDS.sleep(1);
			
			System.out.println(excelObj.readExcelData(i,3,1)+" "+excelObj.readExcelData(i,4,1));
			TimeUnit.SECONDS.sleep(2);
			loginObj.username(excelObj.readExcelData(i,3,1));
			TimeUnit.SECONDS.sleep(2);
			loginObj.password(excelObj.readExcelData(i,4,1));
			loginObj.enter();
			try
			{driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button")).click();}
			catch (Exception e1) 
			{}
			try
			{
				TimeUnit.SECONDS.sleep(2);
				loginObj.account();
				TimeUnit.SECONDS.sleep(1);
				screenshot("C:\\Users\\Admin\\eclipse-workspace\\Project_Lego\\src\\test\\resources\\com\\testData\\Valid_Log_In"+j+".jpg");
				j++;
				loginObj.logout();
				TimeUnit.SECONDS.sleep(2);
				if(i==1)
				{
					excelObj.writeExcelData("The user is able to log in",i,6,1);
					excelObj.writeExcelData("Pass",i,7,1);
				}
				else
				{
					excelObj.writeExcelData("An log in error message is be displayed",i,6,1);
					excelObj.writeExcelData("Fail",i,7,1);
				}
				
			}
			catch (Exception e) 
			{
				if(driver.findElement(By.xpath("//*[@id=\"loginform\"]/span")).isDisplayed())
				{ 
					screenshot("C:\\Users\\Admin\\eclipse-workspace\\Project_Lego\\src\\test\\resources\\com\\testData\\Invalid_Log_In"+k+".jpg");
					k++;
					String s=driver.findElement(By.xpath("//*[@id=\"loginform\"]/span")).getText();
					System.out.println(s);
					if(i!=1)
					{
						excelObj.writeExcelData("An log in error message is displayed",i,6,1);
						excelObj.writeExcelData("Pass",i,7,1);
					}
					else
					{
						excelObj.writeExcelData("No error displayed",i,6,1);
						excelObj.writeExcelData("Fail",i,7,1);
					}
					
					System.out.println("Negative Testcase");
					driver.navigate().to("https://www.lego.com/en-us");
					try
					{
					driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button")).click();
					}
					catch(Exception ex)
					{}
					
				}
			}
		}
	}

	@Then("^I check and close the website$")
	public void i_check_and_close_the_website(DataTable arg1) throws Throwable
	{
		TimeUnit.SECONDS.sleep(2);
	    quit();
	}


}
