package Login_Page;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\com\\Features\\Login\\", glue= "Login_Page")
public class testrunner1
{

}
