package testDefination;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.excelRead;

public class testSteps extends excelRead  {
WebDriver driver;
@Given("^Navigate to lego shop website$")
public void navigate_to_lego_shop_website() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("https://www.lego.com/en-us"); // Going to home page
	driver.manage().window().maximize();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button")).click(); //explore
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button")).click(); //accept cookies
}

@When("^Product is selected by retrieving data from excel sheet$")
public void product_is_selected_by_retrieving_data_from_excel_sheet() throws Throwable
{
	//excelRead ex=new excelRead();
	//ex.readdata1();
	FileInputStream fis = new FileInputStream("C:\\Users\\Pearl\\eclipse-workspace\\Project1\\TestdataLego.xlsx");
	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	XSSFSheet sheet = workbook.getSheetAt(0);
	XSSFRow row=sheet.getRow(0);
	int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

	try
	{
	for (int i = 1; i <rowCount+1; i++)
	{
	    row = sheet.getRow(i);
	    
	    for (int j = 0; j <row.getLastCellNum(); j++)
	    {
	    	//cell = row.getCell(j);
	    	Actions a1=new Actions(driver);
	    		WebElement ew=  new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/nav/ul/li[2]/button")));
	    		try
	    		{
	    			WebElement quest=driver.findElement(By.xpath("//*[@id=\"noButton\"]"));
	    			quest.click();
	    		}
	    		catch(Exception e)
	    			{}
	    			// WebElement ew=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/nav/ul/li[2]/button"));
	    		a1.moveToElement(ew).perform();
	    		//new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"bltb9d6f2110f37ddd5\"]/div/div[1]/button[3]"))).click();

	    		driver.findElement(By.xpath("//*[@id=\"bltb9d6f2110f37ddd5\"]/div/div[1]/button[3]")).click();
	    		String value=row.getCell(j).getStringCellValue();
	    		System.out.print(value);
	    		System.out.println();
	    		//  System.out.println(j);
	    		//  new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.linkText(value))).click();
	    		driver.findElement(By.linkText(value)).click();
	    		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	    		if((j==1) && (i==1) )
	    		{
				       String e=  new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"main-content\"]/div/div[3]/div/div[1]/span[2]/span"))).getText();
				       System.out.println("Age displayed:"+e);
				         //  int rowCount2 = sheet.getLastRowNum()-sheet.getFirstRowNum();
				       XSSFSheet sheet2 = workbook.getSheet("Sheet2");
				       XSSFRow row1=sheet2.getRow(0);
				       XSSFCell cell1=row1.getCell(i);
				       String compare1=cell1.getStringCellValue();
				       System.out.println("Age from excel sheet:"+compare1);
	         
				       if(e.equals(compare1))
				       {
				    	   	System.out.println("Age is matching");
				       }
				       else
				    	   System.out.println("Age isnt matching");
	         
				       String   mystring =e.replace("+", " ");
						System.out.println(mystring);
				       //int intstr = Integer.parseInt(mystring);
				      // int intstr2 = Integer.parseInt(compare2);
				     
				      // if(intstr>3 && intstr<=5)
				    	//   System.out.println("Age :"+intstr+" "+"is in the range"+ value);
	    		}
	    }
	    
	    	System.out.println();
	 }

	}catch (TimeoutException e) {
	       // TODO: handle exception
	       System.out.println(e.toString());}

	}
	


@Then("^Items are selected$")
public void items_are_selected() throws Throwable {
   
}
}
