package excelutility;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

;


public class excelRead {
	protected FileInputStream fis ;
	protected XSSFWorkbook workbook;
	protected XSSFSheet sheet;
	protected XSSFSheet sheet2;
	protected XSSFRow row;
	protected XSSFRow row1;
	protected XSSFCell cell;
	//int colnum=row.getLastCellNum();
	//int rownum=sheet.getLastRowNum()-sheet.getFirstRowNum()-1;
	 
    
	public void readdata1() throws IOException{
		fis = new FileInputStream("C:\\Users\\Pearl\\eclipse-workspace\\Project1\\testdata.xlsx");
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheet("Sheet1");
		// row=sheet.getRow(0);
	//	int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

		
	}
	public void readdata2() throws IOException{
		fis = new FileInputStream("C:\\Users\\Pearl\\eclipse-workspace\\Project1\\testdata.xlsx");
		workbook = new XSSFWorkbook(fis);
		 sheet2 = workbook.getSheet("Sheet2");
		 row1=sheet2.getRow(0);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

		
	}
}
