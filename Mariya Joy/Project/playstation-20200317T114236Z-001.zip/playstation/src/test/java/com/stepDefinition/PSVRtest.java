package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.AllGames;
import com.pages.PSVR;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PSVRtest extends wrapperclass {
	PSVR obj1=new PSVR(driver);
	AllGames obj2=new AllGames(driver);
	@Given("^I am on the homepage of playstation$")
	public void i_am_on_the_homepage_of_playstation() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	}

	@When("^I click  on Games button$")
	public void i_click_on_Games_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		   TimeUnit.SECONDS.sleep(3);
			obj2.click_games();
	}

	@When("^I click on PS VR button$")
	public void i_click_on_PS_VR_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj1.clickPSVR();
	}

	@When("^I click on Tips and Techs Specs$")
	public void i_click_on_Tips_and_Techs_Specs() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj1.clickTips();
	}

	@When("^I click on See the Tech Specs$")
	public void i_click_on_See_the_Tech_Specs() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj1.clickseetech();
	}

	@When("^I click on CUH-ZVR(\\d+) series$")
	public void i_click_on_CUH_ZVR_series(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj1.clickCUH();
	}

	@Then("^specifications about the product should be displayed$")
	public void specifications_about_the_product_should_be_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(3);
		screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\PSVR.jpg");
		TimeUnit.SECONDS.sleep(3);
		quit();
	}

}
