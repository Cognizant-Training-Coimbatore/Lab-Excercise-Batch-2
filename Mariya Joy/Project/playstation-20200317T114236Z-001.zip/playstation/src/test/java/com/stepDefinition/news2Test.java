package com.stepDefinition;

import java.util.concurrent.TimeUnit;


import com.pages.news2;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelRead1;

public class news2Test extends wrapperclass
{
	news2 obj=new news2(driver);
	@Given("^Open the application$")
	public void open_the_application() throws Exception  
	{
		launchApplication("chrome", "https://www.playstation.com/en-us/");
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^I click on news$")
	public void i_click_on_news() throws Exception
	{
		 obj.news();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on PS Blog$")
	public void click_on_PS_Blog() throws Exception
	{
		obj.PSBlog();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on first link$")
	public void click_on_first_link() throws Exception
	{
		obj.flink();
		  TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on search$")
	public void click_on_search() throws Exception 
	{
		obj.search1();
		 TimeUnit.SECONDS.sleep(5);
	}

	@When("^fill search tab$")
	public void fill_search_tab() throws Exception 
	{
		ExcelRead1 dat=new ExcelRead1();
		 obj.enter_text(dat.excel_search_data(1));
		  TimeUnit.SECONDS.sleep(5);
	}

	@Then("^should display the nextnews$")
	public void should_display_the_nextnews() throws Exception 
	{
		extentreport(1); 
		quit();
	}


}
