package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;


public class PSVR extends wrapperclass {
	public PSVR(WebDriver driver)
	{
		this.driver=driver;
	}
public void clickPSVR()
{
	driver.findElement(By.id("link-secondary--msg-ps-vr")).click();
}
public void clickTips()
{
	driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div[1]/ul/li[3]/a")).click();
}
public void clickseetech()
{
	driver.findElement(By.xpath("//a[@aria-label='See the Tech Specs - Tips and Specs']")).click();
}
public void clickCUH()
{
	driver.findElement(By.xpath("//a[@aria-label='CUH-ZVR1 Series - Tips and Specs']")).click();
}

}
