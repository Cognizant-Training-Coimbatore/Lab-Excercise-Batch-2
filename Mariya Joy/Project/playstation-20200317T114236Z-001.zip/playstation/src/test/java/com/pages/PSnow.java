package com.pages;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;


public class PSnow extends wrapperclass
{
	public PSnow(WebDriver driver)
	{
		this.driver=driver;
		
	}
public void games()
{
	driver.findElement(By.id("menu-button-primary--msg-games")).click();
}
public void PS_now()
{
	driver.findElement(By.id("link-secondary--msg-ps-now")).click();	
}
public void PS_games()
{
	driver.get("https://www.playstation.com/en-us/explore/playstation-now/games/");
}
public void fgame()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("window.scrollBy(0,800)");

	driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div[2]/div[2]/div/div/div[3]/div[2]/div/div[1]/div[2]/div/figure/a/picture/img")).click();
}
public void buy()
{
	driver.findElement(By.xpath("//a[@class='tertiary-menu-cta']")).click();
}
public void download() throws InterruptedException
{
	driver.findElement(By.xpath("//*[@id=\"buynow\"]/div/div/div[2]/div[2]/div[2]/div/a")).click();
	TimeUnit.SECONDS.sleep(5);
	Set<String> allWindowHandles = driver.getWindowHandles();
	for(String handle : allWindowHandles)
	{
	driver.switchTo().window(handle);
	}

}

}


