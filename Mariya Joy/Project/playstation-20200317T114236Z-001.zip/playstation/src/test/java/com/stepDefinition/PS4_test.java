package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.PS4;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PS4_test extends wrapperclass
{
	PS4 obj4=new PS4(driver);
	@Given("^I am on the Homepage$")
	public void i_am_on_the_Homepage() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	    TimeUnit.SECONDS.sleep(5);
	    
	}

	@Given("^I click on Hardware$")
	public void i_click_on_Hardware() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj4.hardware();
	    
	}

	@Given("^I click on ps(\\d+)$")
	public void i_click_on_ps(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj4.ps();
	    
	}

	@Given("^I click on learnmore$")
	public void i_click_on_learnmore() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj4.learn();
	   
	}

	@Given("^I click on browse games$")
	public void i_click_on_browse_games() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
	    obj4.browse();
	    TimeUnit.SECONDS.sleep(5);
	    screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\playstation5.jpg");
	 
	}

	@Then("^I Validate the Outcomes$")
	public void i_Validate_the_Outcomes() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
	    driver.quit();
	}



}
