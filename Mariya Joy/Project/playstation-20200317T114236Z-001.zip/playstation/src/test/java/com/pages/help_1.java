package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import baseclass.wrapperclass;

public class help_1 extends wrapperclass
{

	public help_1(WebDriver driver)
	{
	this.driver=driver;
	}
	public void click_on_help()
	{
	driver.findElement(By.id("menu-button-primary--msg-help")).click();
	}
	
	public void click_on_HelpAndSupport()
	{
	driver.findElement(By.id("link-secondary--msg-help-support")).click();
	}
	
	public void click_on_PRODUCTSandSUBSCRIPTIONS()
	{
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/header/div[3]/div[1]/span[1]/a")).click();
	}
	
	public void click_on_PlayStationVR()
	{
	driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div[2]/a/div")).click();
	}
	
	public void click_on_Read_more() throws InterruptedException
	{
	driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[3]/div/div[1]/div/div[2]/a")).click();
	
	
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	
      WebElement Element = driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/div/a/div"));
      js.executeScript("arguments[0].scrollIntoView();", Element);
	}

	public void sshot() throws IOException, InterruptedException
	{
		TimeUnit.SECONDS.sleep(5);
		screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\ss1.jpg");
		TimeUnit.SECONDS.sleep(3);
		quit();
	}
	
	
}
