package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.Order_More;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelReadWrite;

public class Order_More_Test extends wrapperclass
{
Order_More more=new Order_More(driver);

@Given("^open the browser$")
public void open_the_browser() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   launchApplication("chrome","https://www.playstation.com/en-us/");
   TimeUnit.SECONDS.sleep(5);
   
   
}

@When("^I click on Shop Menu$")
public void i_click_on_Shop_Menu() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	more.shop();
	
}

@When("^I click on Official merchandise button$")
public void i_click_on_Official_merchandise_button() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	more.merchand();
}

@When("^I click on New arrival link$")
public void i_click_on_New_arrival_link() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	more.new_arrival();
	
}

@When("^I enter an item on Search field$")
public void i_enter_an_item_on_Search_field() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	ExcelReadWrite ex=new ExcelReadWrite();
	
	more.enter_item(ex.excel_searchpassitem(1));
	
}

@When("^I click on Search tab$")
public void i_click_on_Search_tab() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	more.click_search_tab();
}

@When("^I click on a Item$")
public void i_click_on_a_Item() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	more.click_item();
	
}

@When("^I fill the Quantity in Quantity field$")
public void i_fill_the_Quantity_in_Quantity_field() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	TimeUnit.SECONDS.sleep(5);
	ExcelReadWrite ex=new ExcelReadWrite();
	more.enter_quantity(ex.excel_quantityno(1));

}

@When("^I click Add to Cart option$")
public void i_click_Add_to_Cart_option() throws Exception {
    // Write code here that turns the phrase above into concrete actions

	TimeUnit.SECONDS.sleep(5);
	more.add_to_cart();
	
}

@Then("^I should get Alert message$")
public void i_should_get_Alert_message() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	extentreport(0);
	screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\Order_More.jpg");
	TimeUnit.SECONDS.sleep(5);
	driver.quit();
	

}

}
