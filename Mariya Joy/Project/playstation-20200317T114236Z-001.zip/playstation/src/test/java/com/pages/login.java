package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.wrapperclass;
import excelutility.Excel_read_write;



public class login extends wrapperclass {
	public login(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void sign()
	{
		driver.findElement(By.xpath("//*[@id=\"ember338\"]")).click();
	}
		public void negativeDetails() throws IOException, InterruptedException
		{
			Excel_read_write obj=new Excel_read_write();
			String email=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",3, 0);
			String password=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",3, 1);
			driver.findElement(By.xpath("//*[@id=\"ember19\"]")).sendKeys(email);
			driver.findElement(By.xpath("//*[@id=\"ember22\"]")).sendKeys(password);
			driver.findElement(By.xpath("//*[@id=\"ember24\"]/button")).click();
			TimeUnit.SECONDS.sleep(120);
			try
			{
				driver.findElement(By.id("ember591")).click();
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","pass", 3, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","logged", 3, 3);
			}
			catch(Exception e)
			{
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","fail", 3, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","Did not log in", 3, 3);
			}
			}
		public void invalidPassword() throws IOException, InterruptedException
		{
			Excel_read_write obj=new Excel_read_write();
			String email=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",2, 0);
			String password=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",2, 1);
			driver.findElement(By.xpath("//*[@id=\"ember19\"]")).sendKeys(email);
			driver.findElement(By.xpath("//*[@id=\"ember22\"]")).sendKeys(password);
			driver.findElement(By.xpath("//*[@id=\"ember24\"]/button")).click();
			TimeUnit.SECONDS.sleep(120);
			try
			{
				driver.findElement(By.id("ember591")).click();
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","pass", 2, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","logged in", 2, 3);
			}
			catch(Exception e)
			{
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","fail", 2, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","did not log in", 2, 3);
			}
			}
		public void positiveDetails() throws IOException, InterruptedException
		{
			Excel_read_write obj=new Excel_read_write();
			String email=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",1, 0);
			String password=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",1, 1);
			driver.findElement(By.xpath("//*[@id=\"ember19\"]")).sendKeys(email);
			driver.findElement(By.xpath("//*[@id=\"ember22\"]")).sendKeys(password);
			driver.findElement(By.xpath("//*[@id=\"ember24\"]/button")).click();
			TimeUnit.SECONDS.sleep(120);		
			try
			{
				Actions action = new Actions(driver);
				WebElement element = driver.findElement(By.id("ember591"));
				action.moveToElement(element).perform();
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","pass", 1, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","logged in ", 1, 3);
			}
			catch(Exception e)
			{
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","fail", 1, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","Did not log in", 1, 3);
			}
			
		TimeUnit.SECONDS.sleep(2);	
		}
		public void logout() throws InterruptedException, IOException
		{
			Excel_read_write obj=new Excel_read_write();
			driver.findElement(By.id("ember591")).click();
			TimeUnit.SECONDS.sleep(3);
			driver.findElement(By.id("sb-button-list__onSignOut")).click();
			TimeUnit.SECONDS.sleep(5);
			try
			{
				Actions action = new Actions(driver);
				WebElement element = driver.findElement(By.xpath("//button[@class='sb-skeleton-signin-button']"));
				action.moveToElement(element).perform();
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","pass", 4, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","logged out ", 4, 3);
			}
			catch(Exception e)
			{
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","fail", 4, 4);
				obj.writeDataToPosition("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx","Did not log out", 4, 3);
			}
		}
}
