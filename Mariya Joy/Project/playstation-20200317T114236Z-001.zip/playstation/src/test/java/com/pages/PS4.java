package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;


public class PS4 extends wrapperclass
{
	public PS4(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void hardware()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-hardware\"]")).click();
	}
	public void ps()
	{
		driver.findElement(By.xpath("//a[@class='shared-nav__secondary-anchor shared-nav-anchor dtm-no-track shared-nav-link-icon shared-nav-link-icon--ps4']")).click();
		
	}
	public void learn()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[9]/section/div[2]/div[2]/div/div/div[2]/div[2]/div/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
	}
	public void browse()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[5]/section/div[2]/div[2]/div/div/div/div[2]/div/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        
	}


}
