package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;



public class Gallery extends wrapperclass 
{
	public Gallery(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void hardware()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-hardware\"]")).click();
	}
	public void psvr()
	{
		driver.findElement(By.xpath("//a[@class='shared-nav__secondary-anchor shared-nav-anchor dtm-no-track shared-nav-link-icon shared-nav-link-icon--psvr']")).click();
		
	}
	public void gallery()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div[1]/ul/li[4]/a")).click();
	}
	public void scrnsht()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div[2]/div[2]/div[2]/a/span[1]")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
	}
	public void close()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[2]/section/div[2]/div[2]/div[2]/a/span[2]")).click();
	}
}
