package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;


public class shopremove extends wrapperclass
{
	public shopremove(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	public void shop()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-shop\"]")).click();
		
	}
	public void merchand()
	{
		driver.findElement(By.xpath("//*[@id=\"link-secondary--msg-official-merchandise\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"holiday_splash_close\"]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"invites_close\"]/span")).click();
		
		
	}
	public void new_arrival() throws InterruptedException
	{
		
		driver.findElement(By.xpath("//*[@id=\"footerCategories\"]/div/div[2]/div[2]/div[1]/ul/li[1]/a")).click();
		
		
	}
	public void enter_item(String d)
	{
		driver.findElement(By.xpath("//*[@id=\"Header\"]/div/div[3]/div/form/div/input")).sendKeys(d);
		
		
	}
	
	public void click_search_tab()
	{
		driver.findElement(By.xpath("//*[@id=\"Header\"]/div/div[3]/div/form/div/span/button")).click();
		
	}
	public void click_item() throws InterruptedException
	{
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id=\"item_84296b68-8d43-413a-989f-42aab190b5cf_\"]/div[1]/div[2]/a/img")).click();
		
	}
	public void enter_quantity(String e) throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"Variants_0__Value\"]")).clear();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"Variants_0__Value\"]")).sendKeys(e);
	}
	public void add_to_cart()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,50)");
		driver.findElement(By.xpath("//*[@id=\"addToCartButton\"]")).click();
		
	}
	public void basket()
	
	{
		driver.findElement(By.xpath("//*[@id=\"Header\"]/div/div[2]/ul/li[2]/a/span[1]")).click();
		
	}
	
	public void remove()
	{
		driver.findElement(By.xpath("//*[@id=\"cartForm\"]/div[2]/div/div/div/div[2]/div/div[5]/div[3]/a")).click();
		
	}
	

}
