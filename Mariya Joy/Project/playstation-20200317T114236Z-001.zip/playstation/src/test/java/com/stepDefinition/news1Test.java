package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.news1;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class news1Test extends wrapperclass
{
	news1 obj=new news1(driver);
	@Given("^open the website$")
	public void open_the_website() throws Exception
	{
		launchApplication("chrome", "https://www.playstation.com/en-us/");
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^I click on News$")
	public void i_click_on_News() throws Exception
	{
		obj.news();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on Ps$")
	public void click_on_Ps() throws Exception 
	{
		obj.PSBlog();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^I click on Europe$")
	public void i_click_on_Europe() throws Exception 
	{
		 obj.place();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^click First news$")
	public void click_First_news() throws Exception 
	{
		 obj.news2();
		    TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on Categories$")
	public void click_on_Categories() throws Exception 
	{
		 obj.categories();
		    TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on Nostalgia$")
	public void click_on_Nostalgia() throws Exception 
	{
		 obj.nostalgia();
		  TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on from Date$")
	public void click_on_from_Date() throws Exception
	{
		obj.datefrom();
	    TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on to Date$")
	public void click_on_to_Date() throws Exception 
	{
		 obj.dateto();
		   TimeUnit.SECONDS.sleep(5);
	}

	@When("^click on Z to A$")
	public void click_on_Z_to_A() throws Exception 
	{
		 obj.ZA();
		   TimeUnit.SECONDS.sleep(5);
	}

	@Then("^click on First post$")
	public void click_on_First_post() throws Exception 
	{
		obj.fpost();
		extentreport(1);
		   TimeUnit.SECONDS.sleep(5);
		   quit();
	}

	
	
}




