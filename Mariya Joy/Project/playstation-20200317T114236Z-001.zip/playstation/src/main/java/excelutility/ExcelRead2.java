package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead2  
	{

		
		public String excel_emailid(int d) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(d);
			XSSFCell cell=row.getCell(0);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_password2(int e) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(e);
			XSSFCell cell=row.getCell(1);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_cpassword(int f) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(f);
			XSSFCell cell=row.getCell(2);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_city(int g) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(g);
			XSSFCell cell=row.getCell(3);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_state(int h) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(h);
			XSSFCell cell=row.getCell(4);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_postcode(int i) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(i);
			XSSFCell cell=row.getCell(5);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_firstname(int j) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(j);
			XSSFCell cell=row.getCell(6);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
		public String excel_lastname(int k) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation_register.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(k);
			XSSFCell cell=row.getCell(7);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
	}

	