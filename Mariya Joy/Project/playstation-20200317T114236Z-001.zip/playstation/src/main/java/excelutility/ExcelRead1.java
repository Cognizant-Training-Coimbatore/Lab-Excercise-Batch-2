package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead1 
	{

		public String excel_search_data(int a) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\Playstation_news.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(a);
			XSSFCell cell=row.getCell(0);
			String s=cell.getStringCellValue();
			return s;
		}
		public String excel_username(int b) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\Playstation_buy.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(b);
			XSSFCell cell=row.getCell(0);
			String un=cell.getStringCellValue();
			return un;
		}
		public String excel_password(int c) throws IOException
		{
			FileInputStream fil=new FileInputStream(new File("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\testdata\\Playstation_buy.xlsx"));
			XSSFWorkbook workbook=new XSSFWorkbook(fil);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			int count=sheet.getLastRowNum();
			System.out.println(count);
			XSSFRow row=sheet.getRow(c);
			XSSFCell cell=row.getCell(1);
			String pwd=cell.getStringCellValue();
			return pwd;
		}
	}

	