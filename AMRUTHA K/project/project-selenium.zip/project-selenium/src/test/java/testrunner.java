import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"features/searchbox.feature"},glue = {"com.testcase"},plugin= {"usage","json:target/json/irctcreport.json"})
public class testrunner{
	
	
}
