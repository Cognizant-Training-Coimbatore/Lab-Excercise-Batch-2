package com.testcase;

import com.baseclass.WrapperClass;
import com.baseclass.mylogger;
import com.pages.search;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class searchprdt extends WrapperClass {
		mylogger log=new mylogger();
	@Given("^the user is in homepage$")
	public void the_user_is_in_homepage() throws Throwable {
		System.out.println("the application has been launched");
		log.writeLog("the application has been launched");
		launchApplication("chrome","https://www.elc.co.uk/");
	    
	}

	@Given("^the user selects brands$")
	public void the_user_selects_brands() throws Throwable {
		System.out.println("The user selects the brand");
		log.writeLog("The user selects the brand");
		search ob=new search(driver);
		ob.brands();
		ob.excelread();
	   
	}

	@Given("^the user selects a product$")
	public void the_user_selects_a_product() throws Throwable {
		System.out.println("The user selects a prduct");
		log.writeLog("The user selects a prduct");
		search ob=new search(driver);
		ob.product_selection();
	    
	}

	@Given("^then the user adds the product to cart$")
	public void then_the_user_adds_the_product_to_cart() throws Throwable {
		System.out.println("The user adds the product to cart");
		log.writeLog("The user adds the product to cart");
		search ob=new search(driver);
		ob.add_to_basket();
	    
	}

	@Then("^the user checks out from the page$")
	public void the_user_checks_out_from_the_page() throws Throwable {
		System.out.println("the user checks out from the page");
		log.writeLog("the user checks out from the page");
		search ob=new search(driver);
		ob.checkout();
		quit();
	}

	@Given("^the user is in  the homepage$")
	public void the_user_is_in_the_homepage() throws Throwable {
		System.out.println("the application has been launched");
		log.writeLog("the application has been launched");
		launchApplication("chrome","https://www.elc.co.uk/");
		search ob=new search(driver);
		ob.brands();
		
	}

	@Given("^the user selects creativity$")
	public void the_user_selects_creativity() throws Throwable {
		System.out.println("The user selects creativity");
		log.writeLog("The user selects creativity");
		search ob=new search(driver);
		ob.excel2();
		
	}

	@Given("^the user selects the product$")
	public void the_user_selects_the_product() throws Throwable {
		System.out.println("The user selects a prduct");
		log.writeLog("The user selects a prduct");
		search ob=new search(driver);
		ob.product_selection();
	}

	@Given("^then the user adds a product to cart$")
	public void then_the_user_adds_a_product_to_cart() throws Throwable {
		System.out.println("The user adds the product to cart");
		log.writeLog("The user adds the product to cart");
		search ob=new search(driver);
		ob.add_to_basket();
	}

	@Then("^the user check out from the page$")
	public void the_user_check_out_from_the_page() throws Throwable {
		System.out.println("the user checks out from the page");
		log.writeLog("the user checks out from the page");
		search ob=new search(driver);
		ob.checkout();
		quit();
	}




}
