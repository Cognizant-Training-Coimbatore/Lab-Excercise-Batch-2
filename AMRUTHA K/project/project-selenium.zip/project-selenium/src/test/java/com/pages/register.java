package com.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class register {
WebDriver driver;
	
	public register (WebDriver driver)
	{
	this.driver=driver;
	}
	By signin=By.xpath("//*[@class=\"nav__links nav__links--account\"]");
	public void click_register() throws InterruptedException {
		driver.findElement(signin).click();
		Thread.sleep(2000);
	}
	public void excelread() throws IOException, InterruptedException
	{
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcregistr.xlsx"));
		 XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			 XSSFRow row =sheet.getRow(4);
			  XSSFCell cell=row.getCell(1);
			 String un=cell.getStringCellValue();	
			  driver.findElement(By.xpath("//*[@class=\"nice-select\"]")).click();
			  Actions d=new Actions(driver);
			  d.sendKeys(Keys.DOWN).build().perform();
			  d.sendKeys(Keys.ENTER).build().perform();
			  XSSFRow row1 =sheet.getRow(8);
			  XSSFCell cell1=row1.getCell(1);
			  String fname=cell1.getStringCellValue();
			  driver.findElement(By.id("register.firstName")).sendKeys(fname);
			  Thread.sleep(3000);
			  XSSFRow row2 =sheet.getRow(8);
			  XSSFCell cell2=row2.getCell(2);
			  String lname=cell2.getStringCellValue();
			  driver.findElement(By.id("register.lastName")).sendKeys(lname);
			  Thread.sleep(3000);
			  XSSFRow row3 =sheet.getRow(8);
			  XSSFCell cell3=row3.getCell(3);
			  String email=cell3.getStringCellValue();
			  driver.findElement(By.id("register.email")).sendKeys(email);
			  Thread.sleep(3000);
			  XSSFRow row4 =sheet.getRow(8);
			  XSSFCell cell4=row4.getCell(4);
			  String pass=cell4.getStringCellValue();
			  System.out.println(pass);
			  driver.findElement(By.id("password")).sendKeys(pass);
			  
			  Thread.sleep(3000);
			  XSSFRow row5 =sheet.getRow(8);
			  XSSFCell cell5=row5.getCell(5);
			  String cpass=cell5.getStringCellValue();
			  driver.findElement(By.id("register.checkPwd")).sendKeys(cpass);
			  Thread.sleep(3000);
			  
	}
	public void excelread2() throws IOException, InterruptedException
	{
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcregistr.xlsx"));
		 XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			 XSSFRow row =sheet.getRow(4);
			  XSSFCell cell=row.getCell(1);
			 String un=cell.getStringCellValue();	
			  driver.findElement(By.xpath("//*[@class=\"nice-select\"]")).click();
			  Actions d=new Actions(driver);
			  d.sendKeys(Keys.DOWN).build().perform();
			  d.sendKeys(Keys.ENTER).build().perform();
			  XSSFRow row1 =sheet.getRow(9);
			  XSSFCell cell1=row1.getCell(1);
			  String fname=cell1.getStringCellValue();
			  driver.findElement(By.id("register.firstName")).sendKeys(fname);
			  Thread.sleep(3000);
			  XSSFRow row2 =sheet.getRow(9);
			  XSSFCell cell2=row2.getCell(2);
			  String lname=cell2.getStringCellValue();
			  driver.findElement(By.id("register.lastName")).sendKeys(lname);
			  Thread.sleep(3000);
			  XSSFRow row3 =sheet.getRow(9);
			  XSSFCell cell3=row3.getCell(3);
			  String email=cell3.getStringCellValue();
			  driver.findElement(By.id("register.email")).sendKeys(email);
			  Thread.sleep(3000);
			  XSSFRow row4 =sheet.getRow(9);
			  XSSFCell cell4=row4.getCell(4);
			  String pass=cell4.getStringCellValue();
			 System.out.println(pass);
			  driver.findElement(By.id("password")).sendKeys(pass);
			  Thread.sleep(3000);
			   XSSFRow row5 =sheet.getRow(9);
			  XSSFCell cell5=row5.getCell(5);
			  String cpass=cell5.getStringCellValue();
			  driver.findElement(By.id("register.checkPwd")).clear();
			  driver.findElement(By.id("register.checkPwd")).sendKeys(cpass);
			  Thread.sleep(3000);
	}
	public void submit()
	{
		driver.findElement(By.xpath("//*[@id=\"toyshopRegisterForm\"]/div[12]/button")).click();
		
	}
}