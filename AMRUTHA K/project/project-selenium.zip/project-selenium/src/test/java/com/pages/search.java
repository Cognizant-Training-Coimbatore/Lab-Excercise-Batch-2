package com.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class search {
	
	WebDriver driver;
	public search (WebDriver driver)
	{
	this.driver=driver;
	}
	public void brands() throws InterruptedException
	{
		//driver.findElement(By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[5]/span[1]/a")).click();
		   
		  WebElement btn=driver.findElement(By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[5]/span[1]/a"));
		  Actions actions=new Actions(driver);
		  actions.moveToElement(btn).build().perform();
		   Thread.sleep(5000);
	}
	public void excelread() throws IOException, InterruptedException
	{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc1forgop.xlsx"));
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	 XSSFSheet sheet=workbook.getSheet("Sheet1");
	 XSSFRow row =sheet.getRow(0);
	 XSSFCell cell=row.getCell(1);
	 String un=cell.getStringCellValue();
	 List<WebElement> ab=driver.findElements(By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[5]/div/div/div/div[1]/ul/li"));

	   for(WebElement a:ab)
	   {
	   
	    //System.out.println(a.getText());
	    if(a.getText().contains(un))
	    { //System.out.println(a.getText());
	   
	    a.click();
	    Thread.sleep(2000);
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,250)", "");
	    break;
	    }
	   
	   
	   }
	}
	   
	   public void product_selection() throws InterruptedException
	{
	driver.findElement(By.xpath("//*[@class=\"product__listing product__grid\"]/div[3]/div/a")).click();
	Thread.sleep(2000);
	}
	public void add_to_basket() throws InterruptedException
	{
	driver.findElement(By.xpath("//*[@id=\"addToCartButton\"]")).click();
	Thread.sleep(2000);
	}
	public void checkout() throws InterruptedException
	{
	driver.findElement(By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a")).click();
	Thread.sleep(2000);
	}
	 public void excel2() throws IOException, InterruptedException
	  {
	  FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc1forgop.xlsx"));
	 XSSFWorkbook workbook = new XSSFWorkbook(fil);
	 XSSFSheet sheet=workbook.getSheet("Sheet1");
	 XSSFRow row =sheet.getRow(0);
	 XSSFCell cell=row.getCell(2);
	 
	String un=cell.getStringCellValue();

	 List<WebElement> ab=driver.findElements(By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[2]/div/div/div/div[1]/ul/li"));

	   for(WebElement a:ab)
	   {
	   
	    //System.out.println(a.getText());
	    if(a.getText().contains(un))
	    { //System.out.println(a.getText());
	   
	    a.click();
	   
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,250)", "");
	    break;
	    }
	   
	   }
	   XSSFRow row1 =sheet.getRow(1);
	   XSSFCell cell1=row1.getCell(2);
	   
	   String cc=cell1.getStringCellValue();
	   
	   System.out.println(cc);
	   List<WebElement> bc=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
	   for(WebElement b:bc)
	   {
	    //System.out.println(b.getText());
	   
	    if(b.getText().contains(cc))
	    {
	    //System.out.println(b.getText());
	    TimeUnit.SECONDS.sleep(2);
	    b.click();
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,250)", "");
	    break;
	    }
	   
	   }
	   Thread.sleep(2000);
	/*driver.findElement(By.xpath("//*[@class=\"product__listing product__grid\"]/div[1]/div/a")).click();
	Thread.sleep(5000);
	//Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"addToCartButton\"]")).click();
	Thread.sleep(4000);
	driver.findElement(By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a")).click();
	Thread.sleep(4000);*/

	  }


}
