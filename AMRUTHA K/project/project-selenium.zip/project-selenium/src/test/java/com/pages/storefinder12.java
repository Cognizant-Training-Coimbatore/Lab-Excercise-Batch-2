package com.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class storefinder12 {
	WebDriver driver;
	By store=By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[1]/a");
	By nearstore=By.xpath("//*[@id=\"storeFinder\"]/div/div[2]/div/div/div/ul/li[1]/a/button");
	By region=By.xpath("//*[@id=\"store_regions\"]/ul/li");
	By find=By.xpath("//*[@id=\"storelocator-query\"]");
	By searchbtn=By.xpath("//*[@id=\"storeFinderForm\"]/div/span/button");
	public storefinder12(WebDriver driver)
	{
	this.driver=driver;
	}
	public void ab()
	{
		driver.findElement(store).click();
	}
	public void cd()
	{
		driver.findElement(nearstore).click();
	}
	public void region()
	{
		driver.findElement(region).click();
	}
	public void searchbn()
	{
		driver.findElement(searchbtn).click();
	}
	public void excelfindstore() throws IOException, InterruptedException
	{
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\storefinder.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			  XSSFRow row =sheet.getRow(0);
			  XSSFCell cell=row.getCell(1);
			  
			 String a=cell.getStringCellValue();	
			driver.findElement(find).sendKeys(a);
			TimeUnit.SECONDS.sleep(2);
			
			
		
}

	public void check1() throws IOException
	{
		XSSFWorkbook workbook =null;
		XSSFSheet sheet=null;
		File fil = new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\pass_or_fail_apar.xlsx");
		FileInputStream fis=new FileInputStream(fil);

		workbook= new XSSFWorkbook(fis);
		  sheet=workbook.getSheetAt(0);
		  XSSFRow row=sheet.getRow(1);
		  XSSFCell cell=row.getCell(0);
		String s=cell.getStringCellValue();
		XSSFRow row1=sheet.getRow(1);
		  XSSFCell cell1=row.getCell(1);
		  String p=cell1.getStringCellValue();

		


		if(s==p) {  
			 XSSFRow row2=sheet.getRow(1);
			  XSSFCell cell2=row2.createCell(2);
	
		cell2.setCellValue("pass");

		}
		else {
			 XSSFRow row2=sheet.getRow(1);
			  XSSFCell cell2=row2.createCell(2);

		cell2.setCellValue("Fail");
		}


		FileOutputStream file = new FileOutputStream(fil);
		workbook.write(file);
		file.close();
		       
		}

	public void excelfindstorebyletter() throws IOException, InterruptedException
	{
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\storefinder.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			  XSSFRow row =sheet.getRow(0);
			  XSSFCell cell=row.getCell(3);
			  
			 String b=cell.getStringCellValue();	
			 TimeUnit.SECONDS.sleep(2);
				
			driver.findElement(find).sendKeys(b);
			 TimeUnit.SECONDS.sleep(2);
		
}
	
	public void excelfindstorebyregion() throws IOException, InterruptedException
	{
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\storefinder.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			  XSSFRow row =sheet.getRow(1);
			  XSSFCell cell=row.getCell(4);
			  
			 String un=cell.getStringCellValue();	
			
			  List<WebElement> ab=driver.findElements(By.xpath("//*[@id=\"store_regions\"]/ul/li"));
		
	    for(WebElement a:ab)
	    { 
	    	
	    	
	    	if(a.getText().contains(un))
	    	{ 
	    		a.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    	
	    }
	   XSSFRow row1 =sheet.getRow(0);
		  XSSFCell cell1=row1.getCell(5);
		  
		 String b=cell1.getStringCellValue();	
		 TimeUnit.SECONDS.sleep(2);
		driver.findElement(find).sendKeys(b);
		System.out.println(b);
	
}
}
