package com.testcase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.baseclass.mylogger;
import com.excelutility.excellogin_search;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class testSteps_Searchbox {
	WebDriver driver=new ChromeDriver();
	com.pages.teststeps_source_searchbox obj2=new com.pages.teststeps_source_searchbox(driver);
	excellogin_search data=new excellogin_search();
	mylogger Log=new mylogger();
	@Given("^I am on the homepage to do a single keyword search$")
	public void i_am_on_the_homepage_to_do_a_single_keyword_search() throws Throwable {
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		driver.get("https://www.elc.co.uk/");
		driver.manage().window().maximize();
		System.out.println("Opened browser");
		Log.writeLog("VALIDATING SEARCHBOX srch01");
	}

	@When("^I do a single keyword search for \\(\\.\\.\\.\\)$")
	public void i_do_a_single_keyword_search_for() throws Throwable {
		
		System.out.println(data.excel_searchbox(1));
		obj2.single_keyword_search(data.excel_searchbox(1));
		Log.writeLog("Single keyword search is done");
	}
	@Then("^I see a single keyword search result page with more than zero results$")
	public void i_see_a_single_keyword_search_result_page_with_more_than_zero_results() throws Throwable {
	    obj2.searchbtn_click();
	    String status="";
	    String val=obj2.gettext();
	    data.excel_searchbox_write(1,2,val);
	    if(val.contains("Products found"))
	    {
	    	status="PASS";
	    }
	    else
	    {
	    	status="FAIL";
	    }
    	data.excel_searchbox_write(1,3,status);
    	Log.writeLog("I see a single keyword search result page with more than zero results");
	}
	@Given("^I am on the homepage to do a search with multiple keywords$")
	public void i_am_on_the_homepage_to_do_a_search_with_multiple_keywords() throws Throwable {
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		driver.get("https://www.elc.co.uk/");
		driver.manage().window().maximize();
		Log.writeLog("I am on the homepage to do a search with multiple keywords srch02");
	}

	@When("^I do a multiple keyword search for \\(\\.\\.\\. \\.\\.\\.\\)$")
	public void i_do_a_multiple_keyword_search_for() throws Throwable {
		obj2.multiple_keyword_search(data.excel_searchbox(2));
		Log.writeLog("Multiple keyword search is done");
	}

	@Then("^I see a multiple keyword search result page with more than zero results$")
	public void i_see_a_multiple_keyword_search_result_page_with_more_than_zero_results() throws Throwable {
		 obj2.searchbtn_click();
		 String status="";
		    String val=obj2.gettext1();
		    data.excel_searchbox_write(2,2,val);
		    if(val.contains("Products found"))
		    {
		    	status="PASS";
		    }
		    else
		    {
		    	status="FAIL";
		    }
	    	data.excel_searchbox_write(2,3,status);
	    	Log.writeLog("I see a multiple keyword search result page with more than zero results");
		    
	}
	@Given("^I am on the homepage to do a search with numbers$")
	public void i_am_on_the_homepage_to_do_a_search_with_numbers() throws Throwable {
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		driver.get("https://www.elc.co.uk/");
		driver.manage().window().maximize();
		Log.writeLog("I am on the homepage to do a search with numbers");
	}

	@When("^I do a number keyword search for \\(\\.\\.\\. \\.\\.\\.\\)$")
	public void i_do_a_number_keyword_search_for() throws Throwable {
		obj2.multiple_keyword_search(data.excel_searchbox(3));
		Log.writeLog("I do a number keyword search");
	}

	@Then("^No items are displayed$")
	public void no_items_are_displayed() throws Throwable {
		obj2.searchbtn_click();
		String status="";
	    String val=obj2.gettext2();
	    data.excel_searchbox_write(3,2,val);
	    if(val.contains("0 items found"))
	    {
	    	status="PASS";
	    }
	    else
	    {
	    	status="FAIL";
	    }
    	data.excel_searchbox_write(3,3,status);
		    
    	Log.writeLog("No items are displayed");
	}

	@And("^A screenshot is taken$")
	public void a_screenshot_is_taken() throws Throwable {
	  obj2.screenshot("C:\\Users\\Admin\\Java Programs\\early_learning_project\\src\\test\\resources\\screenshots\\searchbox.png");
	  Log.writeLog("A screenshot is taken");
	}

}
