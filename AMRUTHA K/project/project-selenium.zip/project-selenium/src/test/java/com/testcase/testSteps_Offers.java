package com.testcase;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.baseclass.mylogger;
import com.excelutility.excellogin;
import com.excelutility.excelloginpp;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class testSteps_Offers {
	WebDriver driver=new ChromeDriver();
	com.pages.teststeps_source_offers obj1=new com.pages.teststeps_source_offers(driver);
	excelloginpp dat=new excelloginpp();
	mylogger Log=new mylogger();
	@Given("^I want click on Offers module$")
	public void i_want_click_on_Offers_module() throws Throwable {
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		driver.get("https://www.elc.co.uk/");
		driver.manage().window().maximize();
		System.out.println("Opened browser");
		obj1.offers_click();
	   System.out.println("1");
	   Log.writeLog("TC1: Browser is opened and offer module is clicked");
	}
	
	@When("^I enter learning skills\"([^\"]*)\"$")
	public void i_enter_learning_skills(String arg1) throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(1));
		TimeUnit.SECONDS.sleep(5);
		System.out.println(dat.excel_learningskill(1));
		System.out.println("2");
		Log.writeLog("Discover the world filter is selected");
	}
	
	
	@When("^I enter brands \"([^\"]*)\"$")
	public void i_enter_brands(String arg1) throws Throwable {
		obj1.Brand_select(dat.excel_brand(1));
		TimeUnit.SECONDS.sleep(5);
		System.out.println(dat.excel_brand(1));
		 System.out.println("3");
		 Log.writeLog("Big city brand is selected");
	}
	


	@When("^I enter age \"([^\"]*)\"$")
	public void i_enter_age(String arg1) throws Throwable {
		obj1.Age_select(dat.excel_age(1));
		TimeUnit.SECONDS.sleep(5);
		System.out.println(dat.excel_age(1));
		 System.out.println("4");
		 Log.writeLog("3 - 4 years age is selected");
	}

	@When("^I enter price \"([^\"]*)\"$")
	public void i_enter_price(String arg1) throws Throwable {
	obj1.Price_select(dat.excel_price(1));
		TimeUnit.SECONDS.sleep(5);
		System.out.println(dat.excel_price(1));
		 System.out.println("5");
		 Log.writeLog("15-29.9 Euro is selected");
	}

	@When("^I click Add to Basket$")
	public void i_click_Add_to_Basket() throws Throwable {
         obj1.btn1_click();
		 System.out.println("6");
		 Log.writeLog("Add to basket is clicked");
	}

	@When("^I select Home delivery$")
	public void i_select_Home_delivery() throws Throwable {
		 obj1.homedelivery_click();
		 System.out.println("7");
		 Log.writeLog("Home delivery is clicked");
	}

	@When("^I click Add to basket$")
	public void i_click_Add_to_basket() throws Throwable {
		  obj1.btn2_click();
		 System.out.println("8");
		 Log.writeLog("Add to basket is clicked");
	}

	@When("^I click Check out$")
	public void i_click_Check_out() throws Throwable {
		 obj1.check_out();
		 System.out.println("9");
		 Log.writeLog("Check out is clicked");
	}

	@Then("^I close the brower$")
	public void i_close_the_brower() throws Throwable {
		 driver.quit();
		 System.out.println("8");
		 Log.writeLog("Browser is closed");
	}
	@When("^I want to enter learning skills\"([^\"]*)\"$")
	public void i_want_to_enter_learning_skills(String arg1) throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(2));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Learning skill selected");
	}

	@When("^I want to enter brands \"([^\"]*)\"$")
	public void i_want_to_enter_brands(String arg1) throws Throwable {
		obj1.Brand_select(dat.excel_brand(2));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Brand is selected");
	}

	@When("^I want to enter age \"([^\"]*)\"$")
	public void i_want_to_enter_age(String arg1) throws Throwable {
		obj1.Age_select(dat.excel_age(2));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Age filter is selected");
	}

	@When("^I want to enter price \"([^\"]*)\"$")
	public void i_want_to_enter_price(String arg1) throws Throwable {
		obj1.Price_select(dat.excel_price(2));
		TimeUnit.SECONDS.sleep(3);
		
	}

	@When("^I want to click Add to Basket$")
	public void i_want_to_click_Add_to_Basket() throws Throwable {
		 obj1.btn3_click();
		 Log.writeLog("Add to basket is clicked");
	}
	@When("^I entered learning skills\"([^\"]*)\"$")
	public void i_entered_learning_skills(String arg1) throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(3));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Learning skill filter is selected");
	 	}

	@When("^I entered brands \"([^\"]*)\"$")
	public void i_entered_brands(String arg1) throws Throwable {
		obj1.Brand_select(dat.excel_brand(3));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Brand filter is selected");
	}

	@When("^I entered age \"([^\"]*)\"$")
	public void i_entered_age(String arg1) throws Throwable {
		obj1.Age_select(dat.excel_age(3));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Age filter is selected");
	}

	@When("^I entered price \"([^\"]*)\"$")
	public void i_entered_price(String arg1) throws Throwable {
		obj1.Price_select(dat.excel_price(3));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Price filter is selected");
	}

	@When("^I clicked Add to Basket$")
	public void i_clicked_Add_to_Basket() throws Throwable {
		obj1.btn4_click();
		Log.writeLog("Add to basket is clicked");
	}
	@When("^I enterd learning skills\"([^\"]*)\"$")
	public void i_enterd_learning_skills(String arg1) throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(4));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Learning skills filter is selected");
	}

	@When("^I enterd brands \"([^\"]*)\"$")
	public void i_enterd_brands(String arg1) throws Throwable {
		obj1.Brand_select(dat.excel_brand(4));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Brand filter is selected");
	}

	@When("^I enterd age \"([^\"]*)\"$")
	public void i_enterd_age(String arg1) throws Throwable {
		obj1.Age_select(dat.excel_age(4));
		TimeUnit.SECONDS.sleep(3);
		Log.writeLog("Age is selected");
	}

	@When("^I clickd Add to Basket$")
	public void i_clickd_Add_to_Basket() throws Throwable {
		obj1.btn5_click();
		Log.writeLog("Add to basket is clicked");
    }
	@When("^I selectd learning skills$")
	public void i_selectd_learning_skills() throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(5));
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I selectd brands$")
	public void i_selectd_brands() throws Throwable {
		obj1.Brand_select(dat.excel_brand(5));
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I selectd age$")
	public void i_selectd_age() throws Throwable {
		obj1.Age_select(dat.excel_age(5));
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I selectd price$")
	public void i_selectd_price() throws Throwable {
		obj1.Age_select(dat.excel_price(5));
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I clicksd Add to Basket$")
	public void i_clicksd_Add_to_Basket() throws Throwable {
		obj1.btn6_click();
	}
	@When("^I enter two learning skills filters$")
	public void i_enter_two_learning_skills_filters() throws Throwable {
		obj1.Learningskills_select(dat.excel_learningskill(1));
		TimeUnit.SECONDS.sleep(3);
		obj1.Learningskills_select_twice(dat.excel_learningskill(3));
	}
	@When("^I enter click Add to Basket$")
	public void i_enter_click_Add_to_Basket() throws Throwable {
		obj1.btn7_click();
	}
}