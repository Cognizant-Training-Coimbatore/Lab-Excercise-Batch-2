package com.testcase;

import java.util.concurrent.TimeUnit;

import com.baseclass.WrapperClass;
import com.baseclass.mylogger;

import com.pages.storefinder12;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class storefinder extends WrapperClass{
	mylogger object=new mylogger();
	@Given("^Application open in a browser$")
	public void application_open_in_a_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		 launchApplication("chrome","https://www.elc.co.uk/");
		 
		 object.writeLog("Application launched");
	}

	@Given("^click on store finder$")
	public void click_on_store_finder() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   storefinder12 obj12=new storefinder12(driver);
	   obj12.ab();
	
		 object.writeLog("Clicked on the store finder");
	}

	@When("^I on nearest entertainer store$")
	public void i_on_nearest_entertainer_store() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 storefinder12 obj12=new storefinder12(driver);
		 obj12.cd();
		
		 object.writeLog("Clicked on the nearest entertainer store ");
	}

	@When("^find the store by giving  the city name$")
	public void find_the_store_by_giving_the_city_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 storefinder12 obj12=new storefinder12(driver);
		 obj12.excelfindstore();
		 obj12.check1();
		
		 object.writeLog("Selected the store by giving the store name ");
	}
	@When("^find the store by giving  the first letter of the city name$")
	public void find_the_store_by_giving_the_first_letter_of_the_city_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 storefinder12 obj12=new storefinder12(driver);
		 obj12.excelfindstorebyletter();
		
		 object.writeLog("Selected the store by giving the  first letter of the city name ");
	}

@When("^find the store by selecting  a particular region$")
public void find_the_store_by_selecting_a_particular_region() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 storefinder12 obj12=new storefinder12(driver);
	 obj12.excelfindstorebyregion();
	
	 object.writeLog("Selected the store by giving  a particular region ");
}



	@Then("^I click on search$")
	public void i_click_on_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 storefinder12 obj12=new storefinder12(driver);
		 obj12.searchbn();
	    TimeUnit.SECONDS.sleep(2);
	   
		 object.writeLog("Clicked on the search button ");
	    quit();
	}


}
