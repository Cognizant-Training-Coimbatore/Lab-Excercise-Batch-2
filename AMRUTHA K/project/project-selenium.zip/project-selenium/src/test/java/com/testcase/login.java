package com.testcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;

import com.baseclass.mylogger;
import com.baseclass.WrapperClass;
import com.pages.loginpage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class login extends WrapperClass {
	mylogger obj1=new mylogger();
	@Given("^I want to open website$")
	public void i_want_to_open_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome", "https://www.elc.co.uk/");
	}

	@Given("^navigate_join_to_signin$")
	public void navigate_join_to_signin() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		loginpage obj=new loginpage(driver);
		mylogger obj1=new mylogger();
		obj.loginlink();
	    obj1.writeLog("login page opens..");
	}

	@Given("^click login$")
	public void click_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		loginpage obj=new loginpage(driver);
		 TimeUnit.SECONDS.sleep(2);
		obj.loginbuttonclick();
	    TimeUnit.SECONDS.sleep(2);
	    obj1.writeLog("clicked on login button");
	   
	}

	@Then("^close browser$")
	public void close_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		   
		quit();
		obj1.writeLog("close the browser");
	}
	@Given("^login credentials (\\d+)$")
	public void login_credentials(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		loginpage obj=new loginpage(driver);
		obj.emailfield_and_pass(arg1);
		
	
		obj1.writeLog("entered username and password");
		
		
		
	}
	@Given("^if login fails take screenshot(\\d+)$")
	public void if_login_fails_take_screenshot(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

          loginpage obj=new loginpage(driver);
		String a="Sign Out";
		
	    if(driver.getPageSource().contains(a)) {
	    	
	    	obj1.writeLog("successfully logged in");
	    	obj.pass_and_fail(arg1, 1);
	    }
	    else {
	    	screenshot("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\screnshot\\img"+arg1+".png");
	    	obj1.writeLog("invalid login");
	    	obj.pass_and_fail(arg1, 2);
	    }
		
	}
	
	
	

	@Given("^click on forget password$")
	public void click_on_forget_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   loginpage obj=new loginpage(driver);
	   obj.forgotpassword();
	   TimeUnit.SECONDS.sleep(2);
	}

	@Given("^assert if a dialogue box present or not$")
	public boolean assert_if_a_dialogue_box_present_or_not() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		try
	    {
	        driver.findElement(By.id("cboxLoadedContent"));
	       
	        System.out.println("password reset dialog is present");
	        obj1.writeLog("validated password reset");
	        return true;
	        
	    } 
	    catch (NoAlertPresentException Ex)
	    {
	    	  obj1.writeLog("validation  fails");
	    	System.out.println("password reset dialog is not present");
	        return false;
	    } 
	}
	@Given("^click on paypal$")
	public void click_on_paypal() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 loginpage obj=new loginpage(driver);
		 obj.connectpaypal();
	}


}
