package com.pages;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.excelutility.ExcelReadWrite;

public class productlist_page extends ExcelReadWrite
{
	public static int i=16;
	WebDriver driver;
	public productlist_page(WebDriver driver) 
	{
		this.driver = driver;
	}
	
	public void category() throws IOException
	{
		i++;
		driver.findElement(By.linkText("Type of toy")).click();
		//String main_catgry = "Dolls";
		
		String main_catgry = read_excel(i,2);
		//String sub_catgry ="Doll's accessories";
		i++;
		String sub_catgry =read_excel(i, 2);

		List<WebElement> main = driver.findElements(By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[1]/div/div/div[1]/div"));

		for(WebElement el1 : main)
		{
		//System.out.println(el1.getText());
		if(el1.getText().contains(sub_catgry))
		{
		driver.findElement(By.linkText(sub_catgry)).click();
		break;
		}

		}
	}
	
	public void productLister_page()
	{
		String title = driver.getTitle();
		 System.out.println(title);
		 
	}
	public void learning_skills() throws InterruptedException, IOException
	{
		i++;
		String learning_skills = "Learning Skills";
		//String learning_skills_sub ="Social skills";
		String learning_skills_sub =read_excel(i, 2);
		List<WebElement> learning_skill_list = driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
		int j=0;
		filter1:
		for(WebElement e1 :learning_skill_list)
		{
		j++;
		System.out.println(e1+" :"+"\n"+e1.getText());
		if(e1.getText().contains(learning_skills_sub))
		{
		System.out.println(e1+" :"+"\n"+e1.getText()+"\n"+j);
		//e1.click();
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		// js.executeScript("arguments[0].click();",e1);
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li["+j+"]/form/label/span/span[1]"));
		e.click();
		TimeUnit.SECONDS.sleep(2);
		break filter1;

		}
		}

	}
	
	public void brands() throws InterruptedException, IOException
	{
		i++;
		String Brands ="Brands";
		//String Brands_sub ="Cupcake";
		String Brands_sub =read_excel(i, 2);
		List<WebElement> brands_list = driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li"));
		int j1=0;
		filter1:
		for(WebElement e1 :brands_list)
		{
		j1++;
		System.out.println(e1+" :"+"\n"+e1.getText());
		if(e1.getText().contains(Brands_sub))
		{
		System.out.println(e1+" :"+"\n"+e1.getText()+"\n"+j1);
		//e1.click();
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		// js.executeScript("arguments[0].click();",e1);
		if(j1==1)
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li/span/a"));
		e.click();
		}
		else
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li["+j1+"]/span/a"));
		e.click();
		}
		TimeUnit.SECONDS.sleep(2);
		break filter1;

		}
		}


	}
	
	public void age() throws InterruptedException, IOException
	{
		i++;
		String Age ="Age";
		//String Age_sub ="4 years +";
		String  Age_sub = read_excel(i, 2);
		List<WebElement> age_list = driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li"));
		int j2=0;
		filter1:
		for(WebElement e1 :age_list)
		{
		j2++;
		System.out.println(e1+" :"+"\n"+e1.getText());
		if(e1.getText().contains(Age_sub))
		{
		System.out.println(e1+" :"+"\n"+e1.getText()+"\n"+j2);
		//e1.click();
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		// js.executeScript("arguments[0].click();",e1);
		if(j2==1)
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li/form/label/span/span[1]"));
		e.click();
		}
		else
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li["+j2+"]/form/label/span/span[1]"));
		e.click();
		}
		TimeUnit.SECONDS.sleep(2);
		break filter1;

		}
		}
	}
	
	public void price() throws InterruptedException, IOException
	{
		i++;
		String Price ="Price";
		//String Price_sub ="£15 - £29.99";
		String Price_sub = read_excel(i,2);
		System.out.println("Product"+ i+read_excel(i, 2));
		List<WebElement> price_list = driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li"));
		int j3=0;
		filter1:
		for(WebElement e1 :price_list)
		{
		j3++;
		System.out.println(e1+" :"+"\n"+e1.getText());
		if(e1.getText().contains(Price_sub))
		{
		System.out.println(e1+" :"+"\n"+e1.getText()+"\n"+j3);
		//e1.click();
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		// js.executeScript("arguments[0].click();",e1);
		if(j3==1)
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li/form/label/span/span[1]"));
		e.click();
		}
		else
		{
		WebElement e = driver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li["+j3+"]/form/label/span/span[1]"));
		e.click();
		}
		TimeUnit.SECONDS.sleep(2);
		break filter1;

		}
		}
	}
	
	public void product() throws IOException
	{
		i++;
		//String Product ="Cupcake Dolly Collection Set";
		String Product =read_excel(i, 2);
		System.out.println("Product"+ i+read_excel(i, 2));
		List<WebElement> product_list = driver.findElements(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div"));
		int j4=0;
		filter1:
		for(WebElement e1 :product_list)
		{
			j4++;
			System.out.println(e1+" :"+"\n"+e1.getText());
			if(e1.getText().contains(Product))
			{
				driver.findElement(By.linkText(Product)).click();
				/*
				System.out.println(e1+" :"+"\n"+e1.getText()+"\n"+j);
				//e1.click();
				//JavascriptExecutor js = (JavascriptExecutor)driver;
				// js.executeScript("arguments[0].click();",e1);
				if(j3==1)
				{
					WebElement e = driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div"));
					e.click();
				}
				else
				{
					WebElement e = driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div["+j4+"]"));
					e.click();
				}
				TimeUnit.SECONDS.sleep(2);
				break filter1;
				 	*/

			}
		
		}
		write_excel(Product, 17,4);
		String a= read_excel(17,3);
		String b = read_excel(17, 4);
		if(a.equalsIgnoreCase(b))
		{
			write_excel("Pass", 17, 5);
		}
		else
		{
			write_excel("Fail", 17, 5);
		}
	}
		public void to_cart() throws InterruptedException
		{
			driver.findElement(By.xpath("//*[@id=\"addToCartButton\"]")).click();
		TimeUnit.SECONDS.sleep(2);
			driver.findElement(By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a")).click();
          driver.quit();
		}
		
		
	}
