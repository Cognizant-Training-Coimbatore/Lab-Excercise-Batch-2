package com.testcase;

import java.util.concurrent.TimeUnit;

import com.baseclass.WrapperClass;
import com.excelutility.excellogin;
import com.pages.mybasket;
import com.pages.search;
import com.pages.signin;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class mybaskettest extends WrapperClass {
	@Given("^the user has added an item to shopping basket$")
	public void the_user_has_added_an_item_to_shopping_basket() throws Throwable {
		launchApplication("chrome","https://www.elc.co.uk/");
		Thread.sleep(2000);
		signin ob=new signin(driver);
		
		 ob.click_signin();
		excellogin dat=new excellogin();
		TimeUnit.SECONDS.sleep(5);
		ob.username(dat.excel_username(1));
		TimeUnit.SECONDS.sleep(5);
		ob.password(dat.excel_password(1));
		
	}

	@When("^the user  click the my basket icon$")
	public void the_user_click_the_my_basket_icon() throws Throwable {
		mybasket ob=new mybasket(driver);
	    ob.mybasketsel();
	}

	@Then("^the user lands on shopping basket page$")
	public void the_user_lands_on_shopping_basket_page() throws Throwable {
		System.out.println("The user lands on the shopping page");
	}

	@Then("^the user  see the product in my basket$")
	public void the_user_see_the_product_in_my_basket() throws Throwable {
		System.out.println("the user sees the product on the page");
		screenshot("C:\\Users\\admin\\Desktop\\newmaven\\project_sample\\src\\test\\resources\\com\\screenshot\\page.jpg");
		quit();
	}

	@Given("^the user is on product detail page$")
	public void the_user_is_on_product_detail_page() throws Throwable {
		launchApplication("chrome","https://www.elc.co.uk/");
		Thread.sleep(2000);
		search ob1=new search(driver);
		ob1.brands();
		ob1.excelread();
		
	}

	@When("^the user selects the appropriate filters$")
	public void the_user_selects_the_appropriate_filters() throws Throwable {
		search ob1=new search(driver);
		ob1.product_selection();
	}

	@When("^the user clicks add to basket button$")
	public void the_user_clicks_add_to_basket_button() throws Throwable {
		search ob1=new search(driver);
		ob1.add_to_basket();
	}

	@Then("^the selected product adds to my basket$")
	public void the_selected_product_adds_to_my_basket() throws Throwable {
		search ob1=new search(driver);
		ob1.checkout();
		Thread.sleep(2000);
		quit();
	}



}
