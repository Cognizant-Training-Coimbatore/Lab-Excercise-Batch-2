package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import com.excelutility.ExcelReadWrite;

public class login_page extends ExcelReadWrite
{
	WebDriver driver;
	public login_page(WebDriver driver) 
	{
		this.driver = driver;
	}

	public void title_login_page() throws IOException
	{
		 driver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[2]")).click();
		 String actual_title = driver.getTitle();
		 System.out.println(actual_title);
		 String expected_title ="Login | Early Learning Centre";
		//Assert.assertEquals("Login | Early Learning Centre", title);
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(actual_title.contains(expected_title))
		 {
			 ob.write_excel("Pass",1,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 1,5);
		 }
		 
	}
	
	public void enter_un_pwd(String username ,String password) throws IOException
	{
		String un = read_excel(2, 2);
		String pwd = read_excel(3, 2);
		driver.findElement(By.name("j_username")).sendKeys(un);
		 driver.findElement(By.name("j_password")).sendKeys(pwd);
	}

	public void login_btn()
	{
		WebElement loginBtn =driver.findElement(By.xpath("//*[@id=\"loginForm\"]/button"));
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", loginBtn);
	}
	
	public void account_page() throws IOException
	{
		 String title = driver.getTitle();
		 System.out.println("My Account Page title ::"+ title);
		 String e12 = driver.getCurrentUrl();
		// Assert.assertEquals("https://www.elc.co.uk/my-account",e12);
		 String exp ="https://www.elc.co.uk/my-account";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(e12.contains(exp))
		 {
			 ob.write_excel("Pass", 6,5);
			 ob.write_excel("Pass", 2,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 6,5);
			 ob.write_excel("Fail", 2,5);
		 }
	}
	
	public void log_out() throws InterruptedException, IOException
	{
		 driver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[3]")).click();
		 String title = driver.getCurrentUrl();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		//Assert.assertEquals("Toys & Games | Early Learning Centre", title);
		 String exp1 ="https://www.elc.co.uk/";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(title.contains(exp1))
		 {
			 ob.write_excel("Pass", 7,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 7,5);
		 }
	}
	
	public void track_your_order() throws InterruptedException, IOException
	{
		WebElement e1 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[1]"));
	     e1.click();
	     String title = driver.getCurrentUrl();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
		//Assert.assertEquals("https://www.elc.co.uk/my-account/orders", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/orders";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(title.contains(exp2))
		 {
			 ob.write_excel("Pass", 8,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 8,5);
		 }
	}
	
	public void personal_details() throws InterruptedException, IOException
	{

	    WebElement e2 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[2]"));
	    e2.click();
	    String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			//Assert.assertEquals("https://www.elc.co.uk/my-account/update-profile", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/update-profile";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 9,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 9,5);
		 }
	}
	
	public void update_personal_details() throws InterruptedException
	{
		WebElement e3 = driver.findElement(By.xpath("//*[@id=\"toyshopUpdateProfileForm\"]/div[1]/div/div/span"));
		e3.click();
		WebElement e4 = driver.findElement(By.xpath("//*[@id=\"toyshopUpdateProfileForm\"]/div[1]/div/div/ul/li[7]"));
		e4.click();
		 TimeUnit.SECONDS.sleep(2);
	}
	
	public void wishlist() throws InterruptedException, IOException
	{
		WebElement e5 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[3]"));
		 e5.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
		//Assert.assertEquals("https://www.elc.co.uk/my-account/wishlist", current_url);
		String exp2 ="https://www.elc.co.uk/my-account/wishlist";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 10,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 10,5);
		 }
	}
	
	public void my_interest() throws InterruptedException, IOException
	{
		WebElement e5 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[4]"));
		 e5.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
		//Assert.assertEquals("https://www.elc.co.uk/my-account/wishlist", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/my-interests";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 11,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 11,5);
		 }
	}
	public void saved_basket() throws IOException, InterruptedException
	{
		 WebElement e7 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[2]"));
		TimeUnit.SECONDS.sleep(2);
		 e7.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 String current_url = driver.getCurrentUrl();
		//Assert.assertEquals("https://www.elc.co.uk/my-account/saved-carts", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/saved-carts";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 12,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 12,5);
		 }
	}
	
	public void address_book() throws InterruptedException, IOException
	{
		 WebElement e8 = driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[5]"));
		 e8.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			//Assert.assertEquals("https://www.elc.co.uk/my-account/address-book", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/address-book";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 13,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 13,5);
		 }
	}
	
	public void payment_details() throws InterruptedException, IOException
	{
		WebElement e9 = driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[1]"));
		e9.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		String current_url = driver.getCurrentUrl();
		//Assert.assertEquals("https://www.elc.co.uk/my-account/payment-details", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/payment-details";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 14,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 14,5);
		 }
	}
	
	public void update_password() throws InterruptedException, IOException
	{
		WebElement e10=driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[4]"));
		 e10.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			//Assert.assertEquals("https://www.elc.co.uk/my-account/update-password", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/update-password";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 15,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 15,5);
		 }
	}
	
	public void update_email() throws InterruptedException, IOException
	{
		WebElement e11 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[3]"));
		 e11.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
		// Assert.assertEquals("https://www.elc.co.uk/my-account/update-email", current_url);
		 String exp2 ="https://www.elc.co.uk/my-account/update-email";
		 ExcelReadWrite ob = new ExcelReadWrite();
		 if(current_url.contains(exp2))
		 {
			 ob.write_excel("Pass", 16,5);
		 }
		 else
		 {
			 ob.write_excel("Fail", 16,5);
		 }
	}
}
