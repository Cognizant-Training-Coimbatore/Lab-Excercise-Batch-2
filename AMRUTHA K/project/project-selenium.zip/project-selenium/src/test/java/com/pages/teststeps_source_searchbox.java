package com.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class teststeps_source_searchbox {
WebDriver driver;
By searchbox=By.xpath("//*[@id=\"js-site-search-input\"]");
By searchbtn=By.xpath("/html/body/main/header/nav[1]/div/div/div[6]/div/div/div/form/div/span/button/i");

public teststeps_source_searchbox(WebDriver driver) {
	this.driver=driver;
	
}
public void single_keyword_search(String p) throws InterruptedException
{
	System.out.println(p);
	driver.findElement(searchbox).sendKeys(p);
	 TimeUnit.SECONDS.sleep(3);
	 
}
public void searchbtn_click() throws InterruptedException
{
	//System.out.println("One");
	driver.findElement(searchbtn).click();
	//System.out.println("Two");
	 TimeUnit.SECONDS.sleep(3);
}
public void multiple_keyword_search(String p) throws InterruptedException
{
	driver.findElement(searchbox).sendKeys(p);
	 TimeUnit.SECONDS.sleep(3);
}
public void number_search(String p) throws InterruptedException
{
	
	driver.findElement(searchbox).sendKeys(p);
	 TimeUnit.SECONDS.sleep(3);
}
public void screenshot(String path) throws IOException
{
	TakesScreenshot ts=((TakesScreenshot)driver);
	File Source=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Source,new File(path));
}
public String gettext()
{		 
	 String s=driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div/div/div/div[2]/div[2]/div")).getText();
	 System.out.println(s);
	return s;
}
public String gettext1()
{		 
	 String s=driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div")).getText();
	 System.out.println(s);
	return s;
}
public String gettext2()
{		 
	 String s=driver.findElement(By.xpath("/html/body/main/div[5]/div")).getText();
	 System.out.println(s);
	return s;
}

}
