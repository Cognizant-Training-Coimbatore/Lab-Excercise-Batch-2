package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signin {
	WebDriver driver;
	By signin=By.xpath("//*[@class=\"nav__links nav__links--account\"]");
	By username=By.id("j_username");
	By password=By.id("j_password");
	By login=By.xpath("//*[@id=\"loginForm\"]/button ");
	public signin(WebDriver driver)
	{
		this.driver=driver;
	}
	public void click_signin() throws InterruptedException {
		driver.findElement(signin).click();
		Thread.sleep(2000);
		
	}
	public void username(String value1) throws InterruptedException
	{
		driver.findElement(username).sendKeys(value1);
		Thread.sleep(2000);
	}
	public void password(String value2) throws InterruptedException
	{
		driver.findElement(password).sendKeys(value2);
		Thread.sleep(2000);
	}
	public void click_login() throws InterruptedException
	{
		driver.findElement(login).click();
		Thread.sleep(2000);
	}

}
