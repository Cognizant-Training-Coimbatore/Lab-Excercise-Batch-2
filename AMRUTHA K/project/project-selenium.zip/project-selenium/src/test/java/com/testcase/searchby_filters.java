package com.testcase;



import com.baseclass.WrapperClass;
import com.baseclass.mylogger;

import com.pages.search_by_filters;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchby_filters extends WrapperClass {
mylogger object=new mylogger();
@Given("^I want to search in shop by  learning skills$")
public void i_want_to_search_in_shop_by_learning_skills() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	launchApplication("chrome","https://www.elc.co.uk/"); 
	 
	 object.writeLog("Application launched");
}

@Given("^I want to click on  the Discover the world$")
public void i_want_to_click_on_the_Discover_the_world() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	  // Write code here that turns the phrase above into concrete actions
    search_by_filters obj2=new  search_by_filters(driver);
    obj2.shop();
   
	 object.writeLog("Clicked on the Discover the world");
    
}

@When("^I want to select  multiple filters$")
public void i_want_to_select_multiple_filters() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 search_by_filters obj2=new  search_by_filters(driver);
	 obj2.excelread();
	
	 object.writeLog("Selected the multiple filters");
}
@When("^I want to add some new filters$")
public void i_want_to_add_some_new_filters() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search_by_filters obj2=new  search_by_filters(driver);
	obj2.excel2();
	
	 object.writeLog("Added new filters ");
}
@Given("^I want to give a specific brand$")
public void i_want_to_give_a_specific_brand() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search_by_filters obj2=new  search_by_filters(driver);
	obj2.excelbrand();
	 
	 object.writeLog("Selected a specific brand");
}

@Given("^I want to give a pdt by giving specific age$")
public void i_want_to_give_a_pdt_by_giving_specific_age() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search_by_filters obj2=new  search_by_filters(driver);
	obj2.excelage();
	
	 object.writeLog("Selected a specific age");
}
@Given("^I want to give a pdt by selecting specific price only$")
public void i_want_to_give_a_pdt_by_selecting_specific_price_only() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search_by_filters obj2=new  search_by_filters(driver);
	obj2.excelprice();
	 
	 object.writeLog("Selected a specific price");
}
@Given("^I want to give a pdt by selecting other option as new pdt$")
public void i_want_to_give_a_pdt_by_selecting_other_option_as_new_pdt() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	search_by_filters obj2=new  search_by_filters(driver);
	obj2.excelotheroptions();
	
	 object.writeLog("Selected other option as new pdt");
}


@When("^I click on the product$")
public void i_click_on_the_product() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 search_by_filters obj2=new  search_by_filters(driver);
	 obj2.pdt();
	
	 object.writeLog("Clicked on the product");
}

@When("^I want to add   the product into the  cart$")
public void i_want_to_add_the_product_into_the_cart() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 search_by_filters obj2=new  search_by_filters(driver);
	 obj2.basket();
}

@When("^I want to  checkout$")
public void i_want_to_checkout() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 search_by_filters obj2=new  search_by_filters(driver);
	 obj2.checkout();
	
	 object.writeLog("Successfully checked out");
}

@Then("^I want to close  browser$")
public void i_want_to_close_browser() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	 object.writeLog("Closed the browser");
   quit();
}


}
