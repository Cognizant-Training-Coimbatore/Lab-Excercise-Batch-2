package com.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class teststeps_source_offers {
	WebDriver driver;
	By offers=By.linkText("Offers");
	By skills=By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li");
	By skills_twice=By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li");
	By brands=By.xpath("//div[@id=\"product-facet\"]/div[3]/div[2]/ul/li/span/a");
	By age=By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li");
    By price=By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li");
	By btn1=By.xpath("//*[@id=\"addToCartForm541114\"]/a");
	By homedelivery=By.xpath("//*[@id=\"addToCartForm\"]/div[1]/div[1]");
	By btn2=By.xpath("//*[@id=\"addToCartButton\"]/p");	
	By btn3=By.xpath("//*[@id=\"addToCartForm541086\"]/a");
	By btn4=By.xpath("//*[@id=\"addToCartForm540425\"]/a");
	By btn5=By.xpath("//*[@id=\"addToCartForm540300\"]/a");
	By btn6=By.xpath("//*[@id=\"addToCartForm540468\"]/a");
	By btn7 =By.xpath("//*[@id=\"addToCartForm540593\"]/a");
	By checkout=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");
	//*[@id="product-facet"]/div[5]/div[2]
public teststeps_source_offers(WebDriver driver) {
	this.driver=driver;
	
}
public void offers_click() throws InterruptedException
{
	driver.findElement(offers).click();
	TimeUnit.SECONDS.sleep(3);
}
public void Learningskills_select(String skill) throws InterruptedException
{
	System.out.println(skill);
	
	List<WebElement> learningskills=driver.findElements(skills);
	
	for(WebElement e : learningskills)
	{
		System.out.println(e.getText());
		if(e.getText().contains(skill))
		{
			e.click();
			
			break;
			
		}
	}
	TimeUnit.SECONDS.sleep(3);
	}
public void Learningskills_select_twice(String skill) throws InterruptedException
{
	
	
	List<WebElement> learningskills=driver.findElements(skills_twice);
	
	for(WebElement e : learningskills)
	{
		System.out.println(e.getText());
		if(e.getText().contains(skill))
		{
			e.click();
			
			break;
			
		}
	}
	TimeUnit.SECONDS.sleep(3);
	}

public void Brand_select(String brand) throws InterruptedException
{
	System.out.println(brand);
	List<WebElement> brandlist=driver.findElements(brands);
	for(WebElement p: brandlist)
	{
		System.out.println(p.getText());
		if(p.getText().contains(brand))
		{
			System.out.println(p.getText());
			p.click();
			break;
			
		}
	 TimeUnit.SECONDS.sleep(3);
}
}
public void Age_select(String a) throws InterruptedException
{
System.out.println(a);
	List<WebElement> agelist=driver.findElements(age);
	for(WebElement p: agelist)
	{
		System.out.println(p.getText());
		if(p.getText().contains(a))
		{
			System.out.println(p.getText());
			p.click();
			
			break;
		}
		}}
public void Price_select(String money) throws InterruptedException
{
	System.out.println(money);
	List<WebElement> pricelist=driver.findElements(price);
	for(WebElement p: pricelist)
	{
		System.out.println(p.getText());
		if(p.getText().contains(money))
		{
			System.out.println("kdjlrljclrflud");
			System.out.println(p.getText());
			p.click();
			
			break;
		}
		}

}

public void btn1_click() throws InterruptedException
{
	driver.findElement(btn1).click();
	 TimeUnit.SECONDS.sleep(3);
}
public void homedelivery_click() throws InterruptedException
{
	driver.findElement(homedelivery).click();
	 TimeUnit.SECONDS.sleep(3);
	 
}
public void btn2_click() throws InterruptedException
{
	driver.findElement(btn2).click();
	 TimeUnit.SECONDS.sleep(3);
	 
}
public void btn3_click() throws InterruptedException
{
	driver.findElement(btn3).click();
	 TimeUnit.SECONDS.sleep(3);
}
public void btn4_click() throws InterruptedException
{
	driver.findElement(btn4).click();
	TimeUnit.SECONDS.sleep(3);
	
}
public void btn5_click() throws InterruptedException
{
	driver.findElement(btn5).click();
	TimeUnit.SECONDS.sleep(3);
	
}
public void btn6_click() throws InterruptedException
{
	driver.findElement(btn6).click();
	TimeUnit.SECONDS.sleep(3);
}
public void btn7_click() throws InterruptedException
{
	driver.findElement(btn7).click();
	TimeUnit.SECONDS.sleep(3);
}
public void check_out() throws InterruptedException
{
	driver.findElement(checkout).click();
	TimeUnit.SECONDS.sleep(3);
}

}
