package com.testcase;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.baseclass.WrapperClass;
import com.baseclass.mylogger;
import com.pages.register;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class registration extends WrapperClass{
	mylogger log=new mylogger();
	@Given("^Launch the application$")
	
	public void launch_the_application() throws Throwable {
		 launchApplication("chrome","https://www.elc.co.uk/");
		 log.writeLog("Early Learning Application has been launched");
	}

	@Given("^User clicks register button$")
	public void user_clicks_register_button() throws Throwable {
		register ob=new register(driver);
		   ob.click_register();
	  log.writeLog("User clicks the Sign in/Register button");
	}


	@When("^User enters name,mail and password$")
	public void user_enters_name_mail_and_password() throws Throwable {
		register ob=new register(driver);
		   ob.excelread();
		   log.writeLog("User enters the Name");
		   log.writeLog("User enters the Email id");
		   log.writeLog("User clicks the Password");
	}

	@Then("^User clicks register$")
	public void user_clicks_register() throws Throwable {
		register ob=new register(driver);
		   ob.submit();
		   Thread.sleep(3000);
		   log.writeLog("User clicks the Register button");
		   screenshot("C:\\Users\\Admin\\Desktop\\mainproject\\myproject2\\src\\test\\resources\\com\\screenshot\\register.jpg");
		    quit();
	}
	
	@Given("^Launch application$")
	public void launch_application() throws Throwable {
		 launchApplication("chrome","https://www.elc.co.uk/");
		 log.writeLog("Early Learning Application has been launched");
	}

	@Given("^User click the register button$")
	public void user_click_the_register_button() throws Throwable {
		register ob=new register(driver);
		   ob.click_register();
		   log.writeLog("User clicks the Sign in/Register button");
	}

	@When("^User enter the name,mailid and password$")
	public void user_enter_the_name_mailid_and_password() throws Throwable {
		register ob=new register(driver);
		   ob.excelread2();
		   log.writeLog("User enters the Name");
		   log.writeLog("User enters the Email id");
		   log.writeLog("User clicks the Password");
	}

	@Then("^User clicks the register button$")
	public void user_clicks_the_register_button() throws Throwable {
		register ob=new register(driver);
		   ob.submit();
		   log.writeLog("User clicks the Register button");
		   quit();
	}




}
