package com.testcase;

import java.util.concurrent.TimeUnit;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;

import com.aventstack.extentreports.model.ExceptionInfo;
import com.baseclass.WrapperClass;
import com.baseclass.mylogger;
import com.pages.loginpage;
import com.pages.filters;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class outdoorsearch1 extends WrapperClass {
	
	By typeoftoy=By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li/span/a");
	By brandlist=By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li/span/a");
	By age=By.xpath("//*[@id=\"product-facet\"]/div[4]/div[2]/ul/li");
	
	By otheroption=By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li");
	By price=By.xpath("//*[@id=\"product-facet\"]/div[6]/div[2]/ul/li");
	
	
	By typeoftoy1=By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li/span/a");
	By brandlist1=By.xpath("//*[@id=\"product-facet\"]/div[4]/div[2]/ul/li/span/a");
	By age1=By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li");
	By otheroption1=By.xpath("//*[@id=\"product-facet\"]/div[6]/div[2]/ul/li");
	By price1=By.xpath("//*[@id=\"product-facet\"]/div[7]/div[2]/ul/li");
	mylogger obj1=new mylogger();
	
	@Given("^I want to search in outdoor$")
	public void i_want_to_search_in_outdoor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   launchApplication("chrome", "https://www.elc.co.uk/");
	   obj1.writeLog("launch application");
	   loginpage obj=new loginpage(driver);
	   obj.oudoorclick();
	   
	}

	@Given("^i want to click in fst product$")
	public void i_want_to_click_in_fst_product() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 loginpage obj=new loginpage(driver);
		 obj.productclick();
		 obj1.writeLog("select first product");
	}

	@When("^i want add product into cart$")
	public void i_want_add_product_into_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 loginpage obj=new loginpage(driver);
		try { 
			
			obj.addbasket();}
		catch(Exception e) {
			
			System.out.println("product not available");
			
		}
		
	}

	@When("^i want to check out$")
	public void i_want_to_check_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 loginpage obj=new loginpage(driver);
		try { TimeUnit.SECONDS.sleep(2); 
		
		try {	obj.checkout();}
		catch(Exception e) {
			driver.findElement(By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a")).click();
		}
			
		 TimeUnit.SECONDS.sleep(2);}
		catch(Exception e){
			 System.out.println("cannot check out  ");
		 }
	}

	@Then("^i want to close browser$")
	public void i_want_to_close_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    quit();
	}
	
	@Given("^add first filters$")
	public void add_first_filters() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 filters obj1=new filters(driver);
		obj1.filtersselect(0, 5);
	}
	@When("^i want to add filtered product into cart$")
	public void i_want_to_add_filtered_product_into_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div")).click();
	  
	}

   @Given("^add multiple first filters$")
   public void add_multiple_first_filters() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	   
	   filters obj1=new filters(driver);
	   obj1.multfiltersselect(0, 1, 0, 5);
	   TimeUnit.SECONDS.sleep(2);
	  
	   
     }

   @When("^i want to add mult filtered product into cart$")
    public void i_want_to_add_mult_filtered_product_into_cart() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	   driver.findElement(By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div")).click();
	   driver.findElement(By.id("addToCartButton")).click();
	 
}
   
   @Given("^add type of toy filters$")
   public void add_type_of_toy_filters() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	  filters obj1=new filters(driver);
       obj1.typeoftoy(1,3, driver.findElements(typeoftoy));
   }
   
   @Given("^add type of brand$")
   public void add_type_of_brand() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   filters obj1=new filters(driver);
	   obj1.brandfilters(2,3,driver.findElements(brandlist));
   }
   @Given("^add age filters$")
   public void add_age_filters() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   filters obj1=new filters(driver);
	   obj1.agefilters(3,4,driver.findElements(age));
     
   }
   @Given("^add otheroption$")
   public void add_otheroption() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   filters obj1=new filters(driver);
	   obj1.otheroption(4,1, driver.findElements(otheroption));
   }

   @Given("^add price filter$")
   public void add_price_filter() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   filters obj1=new filters(driver);
	   obj1.pricefilter(5,3, driver.findElements(price));
   }
   @Given("^add learning skill and type of toy filters$")
   public void add_learning_skill_and_type_of_toy_filters() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   
		
	   filters obj1=new filters(driver);
	   obj1.filtersselect(0, 5);
	   obj1.typeoftoy(1, 3,driver.findElements(typeoftoy1));
	   
   }
   @Given("^add all filters once$")
   public void add_all_filters_once() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	  
		filters obj1=new filters(driver);
		obj1.filtersselect(0, 1);
		//obj1.typeoftoy(1, 3,driver.findElements(typeoftoy1));
		
		//obj1.brandfilters(2, 1,driver.findElements(brandlist1));
		obj1.agefilters(3, 6,driver.findElements(age1));
		obj1.otheroption(4, 2,driver.findElements(otheroption1));
		obj1.pricefilter(5, 2,driver.findElements(price1));
      
   }



}
