package com.testcase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.WrapperClass;
import com.pages.login_page;
import com.pages.productlist_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition extends WrapperClass{

	 WebDriver driver;

	
	 @Given("^user is on Home Page$")
	 public void user_already_on_login_page(){
		
	 System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	 driver = new ChromeDriver();
	 driver.get("https://www.elc.co.uk/");
	 driver.manage().window().maximize();
	 }
	
	 @When("^title of login page$")
	 public void title_of_login_page() throws Throwable 
	 {
		 /*
		 driver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[2]")).click();
		 String title = driver.getTitle();
		 System.out.println(title);
		Assert.assertEquals("Login | Early Learning Centre", title);
		*/
		 login_page lp = new login_page(driver);
		 lp.title_login_page();
		 
	 }

	 //Reg Exp:
	 //1. \"([^\"]*)\"
	 //2. \"(.*)\"
	
	 @Then("^user enters \"(.*)\" and \"(.*)\"$")
	 public void user_enters_username_and_password(String username, String password) throws IOException
	 {
		 /*
		 driver.findElement(By.name("j_username")).sendKeys(username);
		 driver.findElement(By.name("j_password")).sendKeys(password);
		 */
		login_page lp = new login_page(driver);
		lp.enter_un_pwd(password, password);
	 }
	
	 @Then("^user clicks on login button$")
	 public void user_clicks_on_login_button() 
	 {
		 /*
		 WebElement loginBtn =driver.findElement(By.xpath("//*[@id=\"loginForm\"]/button"));
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", loginBtn);
		 */
		login_page lp = new login_page(driver);
		lp.login_btn();
	 }
	
	
	 @Then("^user is on account page$")
	 public void user_is_on_account_page() throws IOException
	 {
		 /*
	 String title = driver.getTitle();
	 System.out.println("My Account Page title ::"+ title);
	 String e12 = driver.getCurrentUrl();
	 Assert.assertEquals("https://www.elc.co.uk/my-account",e12);
	 */
		 login_page lp = new login_page(driver);
		 lp.account_page();
	 }
	 /*
	 @Then("^user moves to new contact page$")
	 public void user_moves_to_new_contact_page() 
	 {
		//driver.switchTo().frame("mainpanel");
		//Actions action = new Actions(driver);
		//action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Contacts')]"))).build().perform();
		//driver.findElement(By.xpath("//a[contains(text(),'New Contact')]")).click();
		
		}
	 
	 @Then("^user enters contact details \"(.*)\" and \"(.*)\" and \"(.*)\"$")
	 public void user_enters_contacts_details(String firstname, String lastname, String position)
	 {
		// driver.findElement(By.id("first_name")).sendKeys(firstname);
		 //driver.findElement(By.id("surname")).sendKeys(lastname);
		 //driver.findElement(By.id("company_position")).sendKeys(position);
		 //driver.findElement(By.xpath("//input[@type='submit' and @value='Save']")).click();
	 }
	 */

	 @Then("^Close the browser$")
	 public void close_the_browser()
	 {
		 driver.quit();
	 }
	
	
	//added steps
	 @Then("^user logs out$")
	 public void user_logs_out() throws Throwable 
	 {
		 /*
		 driver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[3]")).click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		Assert.assertEquals("Toys & Games | Early Learning Centre", title);
		*/
		 login_page lp = new login_page(driver);
		 lp.log_out();
	 }

	 @Then("^user clicks on track your order$")
	 public void user_clicks_on_track_your_order() throws Throwable 
	 {
		 /*
	     WebElement e1 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[1]"));
	     e1.click();
	     String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			Assert.assertEquals("https://www.elc.co.uk/my-account/orders", current_url);
			*/
		 login_page lp = new login_page(driver);
		 lp.track_your_order();
		 
	   }

	 @Then("^user clicks on Personal details$")
	 public void user_clicks_on_Personal_details() throws Throwable 
	 {/*
	    WebElement e2 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[2]"));
	    e2.click();
	    String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			Assert.assertEquals("https://www.elc.co.uk/my-account/update-profile", current_url);
			*/
		 login_page lp = new login_page(driver);
		 lp.personal_details();
	}

	 @Then("^user update Personal Details$")
	 public void user_update_Personal_Details() throws Throwable 
	 {
		 /*
		WebElement e3 = driver.findElement(By.xpath("//*[@id=\"toyshopUpdateProfileForm\"]/div[1]/div/div/span"));
		e3.click();
		WebElement e4 = driver.findElement(By.xpath("//*[@id=\"toyshopUpdateProfileForm\"]/div[1]/div/div/ul/li[7]"));
		e4.click();
		 TimeUnit.SECONDS.sleep(2);
		 */
		 login_page lp = new login_page(driver);
		 lp.update_personal_details();
	 }

	 @Then("^user clicks on Wishlist$")
	 public void user_clicks_on_Wishlist() throws Throwable 
	 {
		 /*
		 WebElement e5 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[3]"));
		 e5.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
		Assert.assertEquals("https://www.elc.co.uk/my-account/wishlist", current_url);
		*/
		 login_page lp = new login_page(driver);
		 lp.wishlist();
		 
		 }

	 @Then("^user clicks on my Interest$")
	 public void user_clicks_on_my_Interest() throws Throwable 
	 {
		 /*
		 WebElement e6 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[4]"));
		 e6.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			Assert.assertEquals("https://www.elc.co.uk/my-account/my-interests", current_url);
			*/
		 login_page lp = new login_page(driver);
		 lp.my_interest();
	 }

	 @Then("^user clicks on Saved Basket$")
	 public void user_clicks_on_Saved_Basket() throws Throwable
	 {
		 /*
		 WebElement e7 =driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[2]"));
		 e7.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 String current_url = driver.getCurrentUrl();
		Assert.assertEquals("https://www.elc.co.uk/my-account/saved-carts", current_url);
		*/
		 login_page lp = new login_page(driver);
		 lp.saved_basket();
     }

	 @Then("^user clicks on Address Book$")
	 public void user_clicks_on_Address_Book() throws Throwable 
	 {
		 /*
		 WebElement e8 = driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[5]"));
		 e8.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			Assert.assertEquals("https://www.elc.co.uk/my-account/address-book", current_url);
			*/
		 login_page lp = new login_page(driver);
		 lp.address_book();
 }

	 @Then("^user clicks on Payment Details$")
	 public void user_clicks_on_Payment_Details() throws Throwable 
	 {
		 /*
		WebElement e9 = driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[2]/li[1]"));
		e9.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		String current_url = driver.getCurrentUrl();
		Assert.assertEquals("https://www.elc.co.uk/my-account/payment-details", current_url);
		*/
		 login_page lp = new login_page(driver);
		 lp.payment_details();
	 }

	 @Then("^user clicks on Update Password$")
	 public void user_clicks_on_Update_Password() throws Throwable 
	 {
		 /*
		 WebElement e10=driver.findElement(By.xpath("/html/body/main/div[4]/div/div/div/ul[1]/li[4]"));
		 e10.click();
		 String title = driver.getTitle();
		 System.out.println(title);
		 TimeUnit.SECONDS.sleep(2);
		 String current_url = driver.getCurrentUrl();
			Assert.assertEquals("https://www.elc.co.uk/my-account/update-password", current_url);
			*/
		 login_page lp= new login_page(driver);
		 lp.update_password();
		 
	 }

	 @Then("^user clicks on Update Email$")
	 public void user_clicks_on_Update_Email() throws Throwable 
	 {
		 login_page lp = new login_page(driver);
		 lp.update_email();
	 }
	 

	 @When("^I select a Product lister page from the menu$")
	 public void i_select_a_Product_lister_page_from_the_menu() throws Throwable 
	 {
	    productlist_page ob = new productlist_page(driver);
	    ob.category();
	 }

	 @Then("^I am on the Product lister page$")
	 public void i_am_on_the_Product_lister_page() throws Throwable 
	 {
	     productlist_page ob = new productlist_page(driver);
	    ob.productLister_page();
	 }
	 
	 @When("^I select the filter \\(learning skills,brands,age,price\\)$")
	 public void i_select_the_filter_learning_skills_brands_age_price() throws Throwable 
	 {
		 productlist_page ob = new productlist_page(driver);
		    ob.learning_skills();
		    ob.brands();
		    ob.age();
		    ob.price();
	 }

	 @Then("^the page is filtered to only show desired products$")
	 public void the_page_is_filtered_to_only_show_desired_products() throws Throwable 
	 {
	    productlist_page ob = new productlist_page(driver);
	    ob.product();
	    ob.to_cart();
	 }
}
