package com.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class search_by_filters {
WebDriver driver;
By shop=By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[6]/span[1]/a");
By shop1=By.linkText("Shop by learning skill");
By select=By.xpath("//*[@id=\"catDisc\"]/div/a");

By pdt2=By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]");
By pdt3=By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div/a");
By product=By.xpath("/html/body/main/div[4]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]");

By basket2=By.xpath("//*[@id=\"addToCartButton\"]/p");

By checkout2=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");


By addbasket=By.xpath("//*[@id=\"addToCartForm540477\"]/a/p");
By checkout=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");

public search_by_filters (WebDriver driver)
{
this.driver=driver;
}
public void shop()
{
driver.findElement(shop).click();

driver.findElement(select).click();
}

public void excelread() throws IOException, InterruptedException
{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
	  @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  XSSFRow row =sheet.getRow(0);
		  XSSFCell cell=row.getCell(2);
		  
		 String un=cell.getStringCellValue();	
		
		  List<WebElement> ab=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
	
    for(WebElement a:ab)
    { 
    	
    	System.out.println(a.getText());
    	if(a.getText().contains(un))
    	{ System.out.println(a.getText());
    		 
    		a.click();
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		js.executeScript("window.scrollBy(0,250)", "");
    		break;
    	}
    	
    }
    XSSFCell cell1=row.getCell(3);
    String an=cell1.getStringCellValue();
    List<WebElement> bc=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li"));
    for(WebElement b:bc)
    { 
    	
    	System.out.println(b.getText());
    	if(b.getText().contains(an))
    	{ System.out.println(b.getText());
    		 
    		b.click();
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		js.executeScript("window.scrollBy(0,250)", "");
    		break;
    	}
    
    } 
}
   public void excel2() throws IOException, InterruptedException
   {
	   FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
			  XSSFRow row =sheet.getRow(0);
			  XSSFCell cell=row.getCell(2);
			  
			 String un=cell.getStringCellValue();	
			
			  List<WebElement> ab=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
		
	    for(WebElement a:ab)
	    { 
	    	
	    	
	    	if(a.getText().contains(un))
	    	{ System.out.println(a.getText());
	    		 
	    		a.click();
	    		
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    	
	    }
	    XSSFRow row1 =sheet.getRow(2);
	    XSSFCell cell1=row1.getCell(2);
	    
	    String cc=cell1.getStringCellValue();
	    
	    System.out.println(cc);
	    List<WebElement> bc=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li/span/a"));
	    for(WebElement b:bc)
	    { 
	    	
	    	
	    	if(b.getText().contains(cc))
	    	{ 
	    		System.out.println(b.getText());
	    		TimeUnit.SECONDS.sleep(2);
	    		b.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
	    
	    XSSFRow row2 =sheet.getRow(1);
	    XSSFCell cell2=row2.getCell(3);
	    String vb=cell2.getStringCellValue();
	    List<WebElement> ak=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li"));
	  
	    for(WebElement c:ak)
	    { 
	    	
	    	
	    	if(c.getText().contains(vb))
	    	{ System.out.println(c.getText());
	    	TimeUnit.SECONDS.sleep(2);
	    		c.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
	    XSSFRow row3 =sheet.getRow(3);
	    XSSFCell cell3=row3.getCell(2);
	    String gh=cell3.getStringCellValue();
	    List<WebElement> kl=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li"));
	  
	    for(WebElement d:kl)
	    { 
	    	
	    	
	    	if(d.getText().contains(gh))
	    	{ System.out.println(d.getText());
	    		 
	    		d.click();
	    		TimeUnit.SECONDS.sleep(2);
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
   }
public void excelbrand() throws IOException, InterruptedException
{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
	  @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	  XSSFSheet sheet=workbook.getSheet("Sheet1");
	  XSSFRow row4 =sheet.getRow(2);
	    XSSFCell cell4=row4.getCell(2);
	    
	    String dd=cell4.getStringCellValue();
	    
	    System.out.println("element"+dd);
	    List<WebElement> jk=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li/span/a"));
	    for(WebElement e:jk)
	    { 
	    	System.out.println(e.getText());
	    	
	    	if(e.getText().contains(dd))
	    	{ 
	    		
	    		System.out.println("element is"+e.getText());
	    		TimeUnit.SECONDS.sleep(2);
	    		e.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
}

public void excelage() throws IOException, InterruptedException
{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
	  @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	  XSSFSheet sheet=workbook.getSheet("Sheet1");
	  XSSFRow row5 =sheet.getRow(1);
	    XSSFCell cell5=row5.getCell(1);
	    
	    String ff=cell5.getStringCellValue();
	    
	    System.out.println("element"+ff);
	    List<WebElement> ss=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[3]/div[2]/ul/li"));
	    for(WebElement h:ss)
	    { 
	    	System.out.println(h.getText());
	    	
	    	if(h.getText().contains(ff))
	    	{ 
	    		
	    		System.out.println(h.getText());
	    		TimeUnit.SECONDS.sleep(2);
	    		h.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
}
public void excelprice() throws IOException, InterruptedException
{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
	  @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	  XSSFSheet sheet=workbook.getSheet("Sheet1");
	  XSSFRow row5 =sheet.getRow(3);
	    XSSFCell cell6=row5.getCell(1);
	    
	    String hh=cell6.getStringCellValue();
	    
	    System.out.println("element"+hh);
	    List<WebElement> pp=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[5]/div[2]/ul/li"));
	    for(WebElement i:pp)
	    { 
	    	System.out.println(i.getText());
	    	
	    	if(i.getText().contains(hh))
	    	{ 
	    		
	    		System.out.println(i.getText());
	    		TimeUnit.SECONDS.sleep(2);
	    		i.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
}
public void excelotheroptions() throws IOException, InterruptedException
{
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc_apar.xlsx"));
	  @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	  XSSFSheet sheet=workbook.getSheet("Sheet1");
	  XSSFRow row5 =sheet.getRow(4);
	    XSSFCell cell6=row5.getCell(2);
	    
	    String ll=cell6.getStringCellValue();
	    
	    System.out.println("element"+ll);
	    List<WebElement> mk=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[4]/div[2]/ul/li"));
	    for(WebElement o:mk)
	    { 
	    	System.out.println(o.getText());
	    	
	    	if(o.getText().contains(ll))
	    	{ 
	    		
	    		System.out.println(o.getText());
	    		TimeUnit.SECONDS.sleep(2);
	    		o.click();
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(0,250)", "");
	    		break;
	    	}
	    
	    } 
}

public void pdt()
{
	driver.findElement(product).click();
	
}

public void basket()
{
	driver.findElement(basket2).click();
}
public void checkout()
{
	driver.findElement(checkout2).click();
}
}
