package com.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class filters {
	
	
	WebDriver driver;
	public filters(WebDriver driver) {
		this.driver=driver;
	}
	
	public void filtersselect(int rw,int cl) throws IOException, InterruptedException {
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  XSSFRow row =sheet.getRow(rw);
		 
			  int count=0;
			  XSSFCell cell=row.getCell(cl);
			  String un=cell.getStringCellValue();
			  List<WebElement> list=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
			int c= list.size();
			System.out.println(c);
			  for(WebElement a:list) {
				  count++;
				  System.out.println(a.getText());
		
			 if(a.getText().contains(un)) {
				 System.out.println(a.getText());
				  TimeUnit.SECONDS.sleep(2);
				
				a.click();
				break;
			                               }
		            
	                                 }
	                                                                                     }
			  public void multfiltersselect(int rw,int cl,int rw1,int cl1) throws IOException, InterruptedException {
					FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
					  @SuppressWarnings("resource")
					XSSFWorkbook workbook = new XSSFWorkbook(fil);
					  XSSFSheet sheet=workbook.getSheet("Sheet1");
					  XSSFRow row =sheet.getRow(rw);
					 
						  int count=0;
						  XSSFCell cell=row.getCell(cl);
						  String un=cell.getStringCellValue();
						  List<WebElement> list=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
						int c= list.size();
						System.out.println(c);
						  for(WebElement a:list) {
							  count++;
							  System.out.println(a.getText());
					
						 if(a.getText().contains(un)) {
							 System.out.println(a.getText());
							  TimeUnit.SECONDS.sleep(2);
							
							a.click();
							break;
							
						  }}
						 List<WebElement> list1=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li"));
							
						 XSSFCell cell1=row.getCell(cl1);
						  String un1=cell1.getStringCellValue();
						  for(WebElement b:list1) {
							  count++;
							  System.out.println(b.getText());
					
						 if(b.getText().contains(un1)) {
							 System.out.println(b.getText());
							  TimeUnit.SECONDS.sleep(2);
							
							b.click();
							
							break;
						  }
						
					            
				            }	 
						 
			  }
			  

		  
		  
	
	
	
	
	
	
	
	
//to select a particular type of toy from the list 
public void typeoftoy(int br1,int bc1, List<WebElement> list) throws IOException, InterruptedException {
		
		//to read the excel file
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  XSSFRow row2 =sheet.getRow(br1);
		 
			  
			  XSSFCell cell2=row2.getCell(bc1);
			  String un1=cell2.getStringCellValue();
			
			int c= list.size();
			System.out.println(c);
			  for(WebElement h:list) {
				
				  System.out.println("list="+h.getText());
				  System.out.println(un1);
	//to check whether the extracted value present in the list
			 if(h.getText().contains(un1)){
				
				 
				System.out.println("elament"+h.getText());
				  
				h.click();   //if present click that list element
				TimeUnit.SECONDS.sleep(2);
				break;
				
			 }
			
			  
			  }}
		
		
//to select a particular brand from the list 
  public void brandfilters(int br1,int bc1,List<WebElement> list1) throws IOException, InterruptedException {
					
					
					FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
					  @SuppressWarnings("resource")
					XSSFWorkbook workbook = new XSSFWorkbook(fil);
					  XSSFSheet sheet=workbook.getSheet("Sheet1");
					  XSSFRow row =sheet.getRow(br1);
					 
						 
						  XSSFCell cell2=row.getCell(bc1);
						  String un1=cell2.getStringCellValue();
						  
						int c= list1.size();
						System.out.println(c);
						  for(WebElement h:list1) {
							
							  System.out.println("list="+h.getText());
							  System.out.println(un1);
							//to check whether the extracted value present in the list
						 if(h.getText().contains(un1)){
							
							 
							System.out.println("elament"+h.getText());
							  
							h.click(); //if present click that list element
							TimeUnit.SECONDS.sleep(2);
							break;
							
						  }


						  } }
//to select a particular age group from the list 
	  public void agefilters(int br1,int bc1,List<WebElement> list1) throws IOException, InterruptedException {
								
								
								FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
								  @SuppressWarnings("resource")
								XSSFWorkbook workbook = new XSSFWorkbook(fil);
								  XSSFSheet sheet=workbook.getSheet("Sheet1");
								  XSSFRow row =sheet.getRow(br1);
								 
									  
									  XSSFCell cell3=row.getCell(bc1);
									  String un2=cell3.getStringCellValue();
									 
									int c= list1.size();
									System.out.println(c);
									  for(WebElement h:list1) {
										
										  System.out.println("list="+h.getText());
										  System.out.println(un2);
						//to check whether the extracted value present in the list
									 if(h.getText().contains(un2)){
										
										 
										System.out.println("elament"+h.getText());
										  
										h.click(); //if present click that list element
										TimeUnit.SECONDS.sleep(2);
										break;
										
									  }


									  } }
	//to select a particular option from the list 
  public void otheroption(int br1,int bc1,List<WebElement> list1) throws IOException, InterruptedException {
								
								
								FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
								  @SuppressWarnings("resource")
								XSSFWorkbook workbook = new XSSFWorkbook(fil);
								  XSSFSheet sheet=workbook.getSheet("Sheet1");
								  XSSFRow row =sheet.getRow(br1);
								 
									  
									  XSSFCell cell2=row.getCell(bc1);
									  String un1=cell2.getStringCellValue();
									  
									int c= list1.size();
									System.out.println(c);
									  for(WebElement h:list1) {
										
										  System.out.println("list="+h.getText());
										  System.out.println(un1);
				//to check whether the extracted value present in the list		
										  if(h.getText().contains(un1)){
										
										 
										System.out.println("elament"+h.getText());
										  
										h.click(); //if present click that list element
										TimeUnit.SECONDS.sleep(2);
										break;
										
									  }


									  } }

//to select a particular price range from the list 
	  public void pricefilter(int br1,int bc1,List<WebElement> list1) throws IOException, InterruptedException {
								
								
								FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
								  @SuppressWarnings("resource")
								XSSFWorkbook workbook = new XSSFWorkbook(fil);
								  XSSFSheet sheet=workbook.getSheet("Sheet1");
								  XSSFRow row =sheet.getRow(br1);
								 
									 
									  XSSFCell cell2=row.getCell(bc1);
									  String un1=cell2.getStringCellValue();
									 
									int c= list1.size();
									System.out.println(c);
									  for(WebElement h:list1) {
										
										  System.out.println("list="+h.getText());
										  System.out.println(un1);
		//to check whether the extracted value present in the list						  
									 if(h.getText().contains(un1)){
										
										 
										System.out.println("elament"+h.getText());
										  
										h.click(); //if present click that list element
										TimeUnit.SECONDS.sleep(2);
										break;
										
									  }


									  } }








}
