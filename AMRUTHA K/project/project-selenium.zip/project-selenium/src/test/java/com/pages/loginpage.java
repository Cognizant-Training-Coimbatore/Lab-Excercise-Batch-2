package com.pages;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class loginpage {
	By login= By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[2]/a");
	By loginbutton=By.xpath("//*[@id=\"loginForm\"]/button");
	By email=By.id("j_username");
	By password=By.id("j_password");
	By outdoor=By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[3]/span/a");
	By product1=By.xpath("/html/body/main/div[5]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]");
	By addcart=By.id("addToCartButton");
	By addcart1=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");
	By checkout=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");
	By frgtpaswd=By.xpath("//*[@id=\"loginForm\"]/div[4]/a");
	By paypal=By.id("LIwPPundefined");
	By frgtpswdfield=By.id("forgottenPwd.email");
	By resetbutton=By.xpath("//*[@id=\"forgottenPwdForm\"]/div/button");
	WebDriver driver;
	public loginpage(WebDriver driver) {
		this.driver=driver;
	}
	public void oudoorclick() throws InterruptedException {
		// TODO Auto-generated method stub
		
       driver.findElement(outdoor).click();
	}
	
	public void productclick() {
		// TODO Auto-generated method stub
       driver.findElement(product1).click();
	}
	public void addbasket() {
		// TODO Auto-generated method stub
       driver.findElement(addcart).click();
	}
	public void checkout() {
		// TODO Auto-generated method stub
       driver.findElement(addcart).click();
	}
	public void loginlink() {
		// TODO Auto-generated method stub
       driver.findElement(login).click();
	}
	public void emailfield_and_pass(int id) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\logindata.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  int k=sheet.getLastRowNum();
		  System.out.println(k);
		  
		
		  XSSFRow row =sheet.getRow(id);
		 
			 
			  XSSFCell cell=row.getCell(0);
			  String un=cell.getStringCellValue();
			  driver.findElement(email).sendKeys(un);
			  XSSFCell cell1=row.getCell(1);
			  String un1=cell1.getStringCellValue();
			  driver.findElement(password).sendKeys(un1);
			  fil.close();
		  
		
		
       
	}
	@SuppressWarnings("resource")
	public void pass_and_fail(int id,int id2) throws IOException, InvalidFormatException {
		// TODO Auto-generated method stub
		XSSFWorkbook workbook =null;
		XSSFSheet sheet=null;
		File fil = new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\logindata.xlsx");
		FileInputStream fis=new FileInputStream(fil);
		 
		 workbook= new XSSFWorkbook(fis);
		   sheet=workbook.getSheetAt(0);
		   XSSFRow row=sheet.getRow(id);
		   XSSFCell cell=row.createCell(3);
		  int k=sheet.getLastRowNum();
		  System.out.println(k);
		
		

		 System.out.println("at the cell");
		 
			 
			 
			if(id2==1) {  
			cell.setCellType(CellType.STRING);
			cell.setCellValue("pass");
			
			}
			else {
				cell.setCellType(CellType.STRING);
				cell.setCellValue("Fail");
			}
			 
			
			FileOutputStream file = new FileOutputStream(fil);
			workbook.write(file);
		file.close();
       
	}
	
	public void loginbuttonclick() {
		driver.findElement(loginbutton).click();
	                                }
	public void connectpaypal() throws InterruptedException {
		  driver.findElement(paypal).click();
		  TimeUnit.SECONDS.sleep(2);
		System.out.println(driver.getTitle());  
		
		
	}
public void forgotpassword() {
		  
		driver.findElement(frgtpaswd).click();
		driver.findElement(frgtpswdfield).sendKeys("tkamrutha97@gmail.com");
		 driver.findElement(resetbutton).click();
		
		
	}
	
	
	

}












