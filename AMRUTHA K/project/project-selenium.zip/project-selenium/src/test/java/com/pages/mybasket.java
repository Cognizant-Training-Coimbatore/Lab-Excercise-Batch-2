package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class mybasket {
WebDriver driver;
	
	
	public mybasket(WebDriver driver)
	{
		this.driver=driver;
	}
public void mybasketsel() throws InterruptedException
{
	driver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div/div[5]/ul/li/div/div/div[1]/a/span ")).click();
	Thread.sleep(2000);
	 JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,350)", "");
	    Thread.sleep(2000);
}

}
