package com.pages;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Outdoor {
	By login= By.xpath("/html/body/main/header/nav[1]/div/div/div[3]/ul/li[3]/ul/li[2]/a");
	By loginbutton=By.xpath("//*[@id=\"loginForm\"]/button");
	By email=By.id("j_username");
	By password=By.id("j_password");
	By outdoor=By.xpath("/html/body/main/header/nav[2]/div/ul[2]/li[3]/span/a");
	By product1=By.xpath("/html/body/main/div[5]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]");
	By addcart=By.id("addToCartButton");
	By checkout=By.xpath("//*[@id=\"addToCartLayer\"]/div[1]/div[2]/a");
	By filter= By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul");
	WebDriver driver;
	public Outdoor(WebDriver driver) {
		this.driver=driver;
	}
	public void oudoorclick() throws InterruptedException {
		// TODO Auto-generated method stub
		
       driver.findElement(outdoor).click();
	}
	
	public void productclick() {
		// TODO Auto-generated method stub
       driver.findElement(product1).click();
	}
	public void addbasket() {
		// TODO Auto-generated method stub
       driver.findElement(addcart).click();
	}
	public void checkout() {
		// TODO Auto-generated method stub
       driver.findElement(addcart).click();
	}
	public void loginlink() {
		// TODO Auto-generated method stub
       driver.findElement(login).click();
	}
	public void emailfield(String id) {
		// TODO Auto-generated method stub
       driver.findElement(email).sendKeys(id);
	}
	public void passwordfield(String pass) {
		// TODO Auto-generated method stub
       driver.findElement(password).sendKeys(pass);
	}
	public void loginbuttonclick() {
		driver.findElement(loginbutton).click();
	}
	public void filtersselect(int rw,int cl) throws IOException, InterruptedException {
		FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  XSSFRow row =sheet.getRow(rw);
		 
			  int count=0;
			  XSSFCell cell=row.getCell(cl);
			  String un=cell.getStringCellValue();
			  List<WebElement> list=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
			int c= list.size();
			System.out.println(c);
			  for(WebElement a:list) {
				  count++;
				  System.out.println(a.getText());
		
			 if(a.getText().contains(un)) {
				 System.out.println(a.getText());
				  TimeUnit.SECONDS.sleep(2);
				
				a.click();
				break;
			  }
		            
	            }
	}
			  public void multfiltersselect(int rw,int cl,int rw1,int cl1) throws IOException, InterruptedException {
					FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elc.xlsx"));
					  @SuppressWarnings("resource")
					XSSFWorkbook workbook = new XSSFWorkbook(fil);
					  XSSFSheet sheet=workbook.getSheet("Sheet1");
					  XSSFRow row =sheet.getRow(rw);
					 
						  int count=0;
						  XSSFCell cell=row.getCell(cl);
						  String un=cell.getStringCellValue();
						  List<WebElement> list=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[1]/div[2]/ul/li"));
						int c= list.size();
						System.out.println(c);
						  for(WebElement a:list) {
							  count++;
							  System.out.println(a.getText());
					
						 if(a.getText().contains(un)) {
							 System.out.println(a.getText());
							  TimeUnit.SECONDS.sleep(2);
							
							a.click();
							
							
						  }
						 List<WebElement> list1=driver.findElements(By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li"));
							
						 XSSFCell cell1=row.getCell(cl1);
						  String un1=cell1.getStringCellValue();
						  for(WebElement b:list1) {
							  count++;
							  System.out.println(b.getText());
					
						 if(b.getText().contains(un1)) {
							 System.out.println(b.getText());
							  TimeUnit.SECONDS.sleep(2);
							
							b.click();
							
							
						  }
						
					            
				            }	  
			  
			  }}}


