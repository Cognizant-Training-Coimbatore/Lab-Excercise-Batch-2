package com.baseclass;

import org.apache.log4j.Logger;


public class mylogger {
public	static Logger log=Logger.getLogger(mylogger.class.getName());
	public  void writeLog(String s) {
		// TODO Auto-generated method stub
		
		log.info(s);
		
		
	}
	

}
