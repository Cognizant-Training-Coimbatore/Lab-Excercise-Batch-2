package com.excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExcelReadWrite 
{
	public static XSSFSheet sh ;
	public static XSSFRow Row;
	public static int trow;
	public static int tcol;
	public static String value;
	public static FileOutputStream fos ;
    public static XSSFCell cell;
    public static int row;
/*
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		write_excel("Pass",9,5);
		read_excel(1,0);
	}
	
*/
    	public static void write_excel(String data,int rn,int cn) throws IOException 
		{
		// TODO Auto-generated method stub
			XSSFWorkbook workbook;
			XSSFSheet sheet;
			FileInputStream inputStream;
			FileOutputStream outputStream;
			//inputStream = new FileInputStream(new File("C:\\Users\\user\\Documents\\sample.xlsx"));
			File file = new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\Testdatasoni.xlsx");
			FileInputStream fis = new FileInputStream(file);
			 XSSFWorkbook  wb = new XSSFWorkbook(fis);
		
			sheet = wb.getSheet("Sheet1");	
			
			//int newRowNumber = sheet.getLastRowNum() + 1;
			//int cellnum = 0;
			
			XSSFRow row = sheet.getRow(rn);
			XSSFCell cell = row.createCell(cn);
			cell.setCellType(CellType.STRING);
			cell.setCellValue(data);
			
			//inputStream.close();
			
			outputStream = new FileOutputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\Testdatasoni.xlsx"));
			wb.write(outputStream);
	        outputStream.close();
		}
	



		public static String read_excel(int rn,int cn) throws IOException 
		{
			File file = new File("D:\\\\amrutha\\\\junitworkspace\\\\project-selenium\\\\src\\\\test\\\\resources\\\\com\\\\testdata\\\\Testdatasoni.xlsx");
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook  wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheetAt(0);
		
			int trow = sh.getLastRowNum();
			int tcol = (sh.getRow(0).getLastCellNum())+1;
			int row =rn;
			String value = (sh.getRow(rn).getCell(cn)).getStringCellValue();
			System.out.println(value);
			fis.close();
			return value;
			
		}
	}	
	
