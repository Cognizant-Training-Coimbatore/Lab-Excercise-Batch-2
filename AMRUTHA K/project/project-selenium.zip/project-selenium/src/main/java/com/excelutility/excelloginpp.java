package com.excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelloginpp {
	//To read and return learning skill,brand,age,price
	public  String excel_learningskill(int a) throws IOException {
		 FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcpp.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  
			  XSSFRow row =sheet.getRow(a);
			  XSSFCell cell=row.getCell(0);
			  String sk=cell.getStringCellValue();			  
         return sk;
}
	//TO read and return password
	public  String excel_brand(int a) throws IOException {
		  
		  FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcpp.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		 
		  
			  XSSFRow row =sheet.getRow(a);
			  XSSFCell cell1=row.getCell(1);
			  String br=cell1.getStringCellValue();
          
		return br;
}
	//TO read and return from point
			public  String excel_age(int a) throws IOException {
				  
				  FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcpp.xlsx"));
				  @SuppressWarnings("resource")
				XSSFWorkbook workbook = new XSSFWorkbook(fil);
				  XSSFSheet sheet=workbook.getSheet("Sheet1");
				 
				  
					  XSSFRow row =sheet.getRow(a);
					  XSSFCell cell1=row.getCell(2);
					  String ag=cell1.getStringCellValue();
		          
				return ag;
			}
				//TO read and return destination point
				public  String excel_price(int a) throws IOException {
					  
					  FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\elcpp.xlsx"));
					  @SuppressWarnings("resource")
					XSSFWorkbook workbook = new XSSFWorkbook(fil);
					  XSSFSheet sheet=workbook.getSheet("Sheet1");
					 
					  
						  XSSFRow row =sheet.getRow(a);
						  XSSFCell cell1=row.getCell(3);
						  String pr=cell1.getStringCellValue();
			          
					return pr;
			
				}
	
	}