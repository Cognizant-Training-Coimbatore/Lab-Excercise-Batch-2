package com.excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class excellogin_search {
	/*public static void main(String[] args) throws IOException
	{
		excel_searchbox(1);
		System.out.println(excel_searchbox(1));
	}*/
	protected WebDriver driver;
	public String excel_searchbox(int a) throws IOException {
		 FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\searchbox.xlsx"));
		  @SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		  XSSFSheet sheet=workbook.getSheet("Sheet1");
		  
			  XSSFRow row =sheet.getRow(a);
			  XSSFCell cell=row.getCell(0);
			  String sk=cell.getStringCellValue();		
			  fil.close();
        return sk;
        
}
	public void excel_searchbox_write(int a,int b,String s) throws IOException
	{
		FileInputStream file=new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\searchbox.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		//Getting the sheet
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		//Ascertaining the row
		XSSFRow row=sheet.getRow(a);
		//Ascertaining zeroth cell
		XSSFCell cell = row.createCell(b);
		//Setting value of the cell as the string 
		cell.setCellValue(s);
		//saving the result in testOp.xlsx
		FileOutputStream fileout = new FileOutputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\searchbox.xlsx"));
		workbook.write(fileout);
		fileout.close();
}
	
	public String read_excel(int rn,int cn) throws IOException
	{
	File file = new File("C:\\Users\\Admin\\Desktop\\searchbox.xlsx");
	FileInputStream fis = new FileInputStream(file);
	XSSFWorkbook  wb = new XSSFWorkbook(fis);
	XSSFSheet sh = wb.getSheetAt(0);

	int trow = sh.getLastRowNum();
	int tcol = (sh.getRow(0).getLastCellNum())+1;
	int row =rn;
	String value = (sh.getRow(rn).getCell(cn)).getStringCellValue();
	System.out.println(value);
	fis.close();
	return value;

	}
	public String excel_read(int rw,int cl) throws IOException {
	FileInputStream fil = new FileInputStream(new File("D:\\amrutha\\junitworkspace\\project-selenium\\src\\test\\resources\\com\\testdata\\searchbox.xlsx"));
	 @SuppressWarnings("resource")
	XSSFWorkbook workbook = new XSSFWorkbook(fil);
	 XSSFSheet sheet=workbook.getSheet("Sheet1");
	 XSSFRow row =sheet.getRow(rw);
	 XSSFCell cell=row.getCell(cl);
	 String un=cell.getStringCellValue();
	 return un;
	 }
/*public void check1() throws IOException
	{
	XSSFWorkbook workbook =null;
	XSSFSheet sheet=null;
	File fil = new File("C:\\\\Users\\\\Admin\\\\Desktop\\\\readwrite.xlsx");
	FileInputStream fis=new FileInputStream(fil);

	workbook= new XSSFWorkbook(fis);
	 sheet=workbook.getSheetAt(0);
	 XSSFRow row=sheet.getRow(1);
	 XSSFCell cell=row.getCell(1);
	String s=cell.getStringCellValue();
	XSSFRow row1=sheet.getRow(1);
	 XSSFCell cell1=row.getCell(2);
	 String p=cell1.getStringCellValue();




	if(s==p) {  
	XSSFRow row2=sheet.getRow(1);
	 XSSFCell cell2=row2.createCell(3);

	cell2.setCellValue("pass");

	}
	else {
	XSSFRow row2=sheet.getRow(1);
	 XSSFCell cell2=row2.createCell(3);

	cell2.setCellValue("Fail");
	}


	FileOutputStream file = new FileOutputStream(fil);
	workbook.write(file);
	file.close();
	     
	}
	*/
	                              
}
