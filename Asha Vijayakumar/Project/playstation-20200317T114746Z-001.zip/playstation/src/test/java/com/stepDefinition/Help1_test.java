package com.stepDefinition;

import java.util.concurrent.TimeUnit;


import com.pages.help_1;
import com.pages.help_2;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Help1_test extends wrapperclass
{

	help_1 hp1 = new help_1(driver);
	
	@Given("^I am in the Home page$")
	public void login_to_the_application() throws Exception
	{
	    // Write code here that turns the phrase above into concrete actions
	   
		launchApplication("chrome", "https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(3);
		
	}

	
	
	
	@When("^I click on Help$")
	public void i_click_on_Help() throws Exception
	{
	    // Write code here that turns the phrase above into concrete actions
	
		TimeUnit.SECONDS.sleep(3);
		hp1.click_on_help();
	}

	@When("^I click on Help & Support$")
	public void i_click_on_Help_Support() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp1.click_on_HelpAndSupport();
	}

	@When("^I click on PRODUCTS & SUBSCRIPTIONS$")
	public void i_click_on_PRODUCTS_SUBSCRIPTIONS() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp1.click_on_PRODUCTSandSUBSCRIPTIONS();
	}

	@When("^I click on PlayStation VR$")
	public void i_click_on_PlayStation_VR() throws Exception
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp1.click_on_PlayStationVR();
	}

	@When("^I click on Read more$")
	public void i_click_on_Read_more() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp1.click_on_Read_more();
	}

	@Then("^I validate the outcomes_b$")
	public void i_validate_the_outcomes() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(3);
		hp1.sshot();
	}
	
	
	
	
	
	//next...........................................
	
	
	
	help_2 hp2 = new help_2(driver);
	
	@When("^I click on Help_a$")
	public void i_click_on_Help_a() throws Exception
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp2.click_on_help();
	  
	}
	
	@When("^I click on Help & Support_a$")
	public void i_click_on_Help_Support_a() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
	 
		TimeUnit.SECONDS.sleep(3);
		hp2.click_on_HelpAndSupport();
	}

	@When("^I click on ACCOUNT MANAGEMENT$")
	public void i_click_on_ACCOUNT_MANAGEMENT() throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions

		TimeUnit.SECONDS.sleep(3);
		hp2.click_on_ACCOUNT_MANAGEMENT();
	}

	

	@When("^I click on PS(\\d+): (\\d+)-Step Verification$")
	public void i_click_on_PS_Step_Verification(int arg1, int arg2) throws Exception 
	{
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		hp2.click_on_PS4_2_Step_Verification();
	}

	@Then("^I validate the outcomes_a$")
	public void i_validate_the_outcomes_a() throws Exception
	{
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(3);
		hp2.outcome();
		
	}

	
	
	
	
	
	
}
