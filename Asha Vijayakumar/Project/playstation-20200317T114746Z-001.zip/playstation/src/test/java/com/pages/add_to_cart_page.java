package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;

public class add_to_cart_page extends wrapperclass{

	public add_to_cart_page(WebDriver driver) 
	{
		this.driver=driver;
	}
	public void click_on_service()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-services\"]")).click();
	}
	public void click_on_psplus()
	{
		driver.findElement(By.xpath("//*[@class=\"shared-nav__secondary-anchor shared-nav-anchor dtm-no-track shared-nav-link-icon shared-nav-link-icon--psplus\"]")).click();
	}
	public void click_on_online_multiplayer()
	{
		driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div[1]/ul/li[1]/a")).click();
	}
	public void click_on_join_today()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[1]/section/div/div[2]/div/div[1]/div[3]/div[2]/div/a")).click();
	}
	public void click_on_month_membership_join_today()
	{
		driver.findElement(By.xpath("//*[@id=\"page-content\"]/div[2]/div[8]/section/div[2]/div[2]/div/div[3]/div[4]/div[2]/div/a")).click();
	}
}
