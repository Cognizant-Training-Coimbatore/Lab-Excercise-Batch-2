package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import baseclass.wrapperclass;



public class Discount_rate extends wrapperclass
{

	public Discount_rate(WebDriver driver)

	{
		this.driver=driver;
		
	}
	public void click_shop()
	{
		driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-shop\"]")).click();
		
	}
	public void click_digital()
	{
		driver.findElement(By.xpath("//*[@id=\"link-secondary--msg-digital-games-and-services\"]")).click();
		
	}
	public void click_offers()
	{
		driver.findElement(By.xpath("//*[@id=\"ember892\"]/span")).click();
		
	}
	public void click_anyoffer()
	{
		driver.findElement(By.xpath("//*[@id=\"ember1979\"]")).click();
		
	}
	public void click_item() throws InterruptedException
	{
		driver.findElement(By.xpath("//div[@class='product-image__img product-image__img--main']")).click();
		
	}
	
		
}
	

