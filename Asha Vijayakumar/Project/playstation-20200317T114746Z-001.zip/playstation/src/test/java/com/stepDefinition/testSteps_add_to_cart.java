package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pages.add_to_cart_page;
import com.pages.free_game_add_to_cart;


import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelRead1;

public class testSteps_add_to_cart extends wrapperclass
{
	add_to_cart_page addc = new add_to_cart_page(driver);
	free_game_add_to_cart faddc = new free_game_add_to_cart(driver);
	@Given("^I want to navigate to the service menu$")
	public void i_want_to_navigate_to_the_service_menu() throws Exception {
	    launchApplication("chrome", "https://www.playstation.com/en-us");
	}

	@When("^I click on service button$")
	public void i_click_on_service_button() throws Exception 
	{
	    addc.click_on_service();
	}

	@When("^I click on PS Plus button$")
	public void i_click_on_PS_Plus_button() throws Exception {
	    addc.click_on_psplus();
	}

	@When("^I click on Online Multiplayer$")
	public void i_click_on_Online_Multiplayer() throws Exception
	{
	    addc.click_on_online_multiplayer();
	}

	@When("^I click on Join Today$")
	public void i_click_on_Join_Today() throws Exception {
	    addc.click_on_join_today();
	}

	@When("^I click on (\\d+)-Month membership join today$")
	public void i_click_on_Month_membership_join_today(int arg1) throws Exception 
	{
		TimeUnit.SECONDS.sleep(5);
		addc.click_on_month_membership_join_today();
	}

	@Then("^The item is added to the cart and show \"([^\"]*)\"$")
	public void the_item_is_added_to_the_cart_and_show(String arg1) throws Exception {
	    System.out.println(arg1);
	    quit();
	}
	@Given("^I want to navigate to the service$")
	public void i_want_to_navigate_to_the_service() throws Exception {
		launchApplication("chrome", "https://www.playstation.com/en-us");
	}

	@When("^I click on service$")
	public void i_click_on_service() throws Exception {
		addc.click_on_service();
	}

	@When("^I click on PS Plus$")
	public void i_click_on_PS_Plus() throws Exception {
		addc.click_on_psplus();
	}

	@When("^I click on Free Game$")
	public void i_click_on_Free_Game() throws Exception {
	    faddc.click_on_free_game();
	}

	@When("^I click on game$")
	public void i_click_on_game() throws Exception {
	    faddc.click_on_game();
	}

	@When("^I click on add to cart$")
	public void i_click_on_add_to_cart() throws Exception {
	    faddc.click_on_add_to_cart();
	    TimeUnit.SECONDS.sleep(5);
	    ExcelRead1 dat=new ExcelRead1();
	    String user=dat.excel_username(1);
		driver.findElement(By.xpath("//*[@id=\"ember19\"]")).sendKeys(user);
		String pass=dat.excel_password(1);
		driver.findElement(By.xpath("//*[@id=\"ember22\"]")).sendKeys(pass);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//*[@id=\"ember24\"]/button")).click();
		TimeUnit.MINUTES.sleep(2);
		WebElement item = driver.findElement(By.xpath("//*[@id=\"ember2079\"]/div[1]/div[2]/div[1]/div/div[1]/span"));
		if(item.getText()!=null)
		{
			System.out.println("successfully added");
		}
		else
			System.out.println("cannnot add the item");
		quit();
		driver.quit();
	}

	@Then("^The item is added and show \"([^\"]*)\"$")
	public void the_item_is_added_and_show(String arg1) throws Exception {
		extentreport(1);
	    System.out.println(arg1);
	    
	}
}
