package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.shopremove;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelReadWrite;

public class shopremoveTest extends wrapperclass 
{
	shopremove remove=new shopremove(driver);
	
	@Given("^Login in the application$")
	public void login_in_the_application() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
		
	  TimeUnit.SECONDS.sleep(5);
	  
	}

	@When("^I click on shop Menu$")
	public void i_click_on_shop_Menu() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.shop();
	}

	@When("^I click on official merchandise button$")
	public void i_click_on_official_merchandise_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.merchand();
		  
	}

	@When("^I click on New arrivals link$")
	public void i_click_on_New_arrivals_link() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.new_arrival();
	}

	@When("^I enter an item on Search tab$")
	public void i_enter_an_item_on_Search_tab() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  ExcelReadWrite read=new ExcelReadWrite();
		  
		  remove.enter_item(read.excel_searchpass(1));
	}

	@When("^I click on search tab$")
	public void i_click_on_search_tab() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.click_search_tab();
		  
	}

	@When("^I click on a item$")
	public void i_click_on_a_item() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.click_item();
		  
	}

	@When("^I fill the Quantity in quantity field$")
	public void i_fill_the_Quantity_in_quantity_field() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  ExcelReadWrite read=new ExcelReadWrite();
		  remove.enter_quantity(read.excel_quantity(1));
	}

	@When("^I click Add to cart option$")
	public void i_click_Add_to_cart_option() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.add_to_cart();
	}

	@When("^I click on basket option$")
	public void i_click_on_basket_option() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		 TimeUnit.SECONDS.sleep(5);
		 remove.basket();
		 
	}

	@When("^I click on Remove option$")
	public void i_click_on_Remove_option() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  TimeUnit.SECONDS.sleep(5);
		  remove.remove();
		  
	}

	@Then("^I should get Removed message$")
	public void i_should_get_Removed_message() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		  extentreport(1);
		  TimeUnit.SECONDS.sleep(5);
		  screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\shopremove.png");
		  
		  driver.quit();
		  
	}



}
