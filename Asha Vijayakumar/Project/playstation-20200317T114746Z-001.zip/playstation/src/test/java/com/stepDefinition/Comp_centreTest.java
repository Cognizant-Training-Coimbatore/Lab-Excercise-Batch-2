package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.AllGames;
import com.pages.Comp_centre;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Comp_centreTest extends wrapperclass {
	Comp_centre obj1=new Comp_centre(driver);
	AllGames obj2=new AllGames(driver);
	@Given("^I am in the homepage of playstation$")
	public void i_am_in_the_homepage_of_playstation() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	}

	@Given("^I click the Games button$")
	public void i_click_the_Games_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    TimeUnit.SECONDS.sleep(5);
	    obj2.click_games();
	}

	@When("^I click Competition centre$")
	public void i_click_Competition_centre() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		obj1.comp_cen();
	}

	@When("^I click on Watch button$")
	public void i_click_on_Watch_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		obj1.watch();
	}

	@When("^I click on View All$")
	public void i_click_on_View_All() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		obj1.viewall();
	}

	@When("^I click on Games and select Fifa and click apply$")
	public void i_click_on_Games_and_select_Fifa_and_click_apply() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		obj1.game();
		TimeUnit.SECONDS.sleep(3);
		obj1.fifa();
	}

	@When("^I click on Fifa game$")
	public void i_click_on_Fifa_game() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(5);
		obj1.fifaimg();
	}

	@Then("^information about competition is displayed$")
	public void information_about_competition_is_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(5);
		screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\fifa.jpg");
		quit();
	}
}
