package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;


public class Comp_centre extends wrapperclass {
public Comp_centre(WebDriver driver)
{
	this.driver=driver;
}
public void comp_cen()
{
	driver.findElement(By.xpath("//*[@id=\"link-link-list--msg-games-3\"]/span")).click();
}
public void watch()
{
	driver.findElement(By.xpath("//*[@id=\"jetstream-tertiary-nav\"]/div/div/div/div[1]/ul/li[1]/a")).click();
}
public void viewall()
{
	driver.findElement(By.xpath("//*[@id=\"main\"]/div[2]/section[1]/div/div[1]/a")).click();
}
public void game()
{
	driver.findElement(By.xpath("//*[@id=\"main\"]/section/div[1]/div[1]/div[1]")).click();
}
public void fifa() throws InterruptedException
{
	driver.findElement(By.xpath("//*[@id=\"main\"]/section[2]/div[1]/div[1]/div[2]/div/button[3]")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"main\"]/section/div[1]/div[1]/div[2]/button")).click();
	}
public void fifaimg() throws InterruptedException
{
	driver.findElement(By.xpath("//*[@id=\"main\"]/section[2]/div[1]/div[3]/div/div/div[2]/a/div/div/div[1]")).click();
	TimeUnit.SECONDS.sleep(3);
	JavascriptExecutor js = (JavascriptExecutor) driver;
    WebElement Element = driver.findElement(By.xpath("//*[@id=\"main\"]/section/div[1]/div/div[2]/figure/img"));		
    js.executeScript("arguments[0].scrollIntoView();", Element);
}

}
