package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import baseclass.wrapperclass;



public class news2 extends wrapperclass
{

	public news2(WebDriver driver)
	{
		this.driver=driver;
		
	}
	public void news()
	{
	driver.findElement(By.xpath("//*[@id=\"menu-button-primary--msg-news\"]")).click();
	}
	public void PSBlog()
	{
	driver.findElement(By.id("link-secondary--msg-ps-blog")).click();	
	}
	public void flink() throws InterruptedException
	{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)");
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"post-222260\"]/div/h3/a")).click();
	}
	
	
	public void search1()
	{
	driver.findElement(By.xpath("//*[@id=\"site-navigation\"]/div[2]/button")).click();
	}
	
	
	public void enter_text(String a) throws InterruptedException
	{
	driver.findElement(By.id("search-input")).sendKeys(a);
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.id("search-input")).sendKeys(Keys.ENTER);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,350)");

	}

}
