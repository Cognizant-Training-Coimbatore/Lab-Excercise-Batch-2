package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.login;
import com.pages.register;
import com.pages.troublesignin;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.ExcelRead2;

public class accountTest extends wrapperclass {
	register obj=new register(driver);
	ExcelRead2 obj1=new  ExcelRead2();
	login obj2=new login(driver);
	troublesignin obj3=new troublesignin(driver);
	@Given("^Open the browser$")
	public void open_the_browser() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(3);
		obj.signin();
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click create account button$")
	public void i_click_create_account_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
		obj.createaccnt();
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click on start button$")
	public void i_click_on_start_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.start();
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter email address$")
	public void i_enter_email_address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.emailid(obj1.excel_emailid(1));
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter password$")
	public void i_enter_password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.password(obj1.excel_password2(1));
	   TimeUnit.SECONDS.sleep(3);
	   obj.cpassword(obj1.excel_cpassword(1));
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click next(\\d+) button$")
	public void i_click_next_button(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 obj.next();
	 TimeUnit.SECONDS.sleep(120);
	}

	@When("^I enter country$")
	public void i_enter_country() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.country();
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter dob$")
	public void i_enter_dob() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.dob();
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter city$")
	public void i_enter_city() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.city(obj1.excel_city(1));
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter state$")
	public void i_enter_state() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj.state(obj1.excel_state(1));
	    TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter postcode$")
	public void i_enter_postcode() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  obj.postcode(obj1.excel_postcode(1));
	  TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter onlineid$")
	public void i_enter_onlineid() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj.onlineid();
	    TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter first name$")
	public void i_enter_first_name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.fname(obj1.excel_firstname(1));
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter last name$")
	public void i_enter_last_name() throws Exception {
	   obj.lname(obj1.excel_lastname(1));
	   TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click continue button$")
	public void i_click_continue_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  obj.click_continue();
	  TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I click agree button$")
	public void i_click_agree_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj.click_agree();
	   TimeUnit.SECONDS.sleep(3);
	   quit();
	}

	@Given("^I am on the homepage of playststion$")
	public void i_am_on_the_homepage_of_playststion() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click on the Sign In button$")
	public void i_click_on_the_Sign_In_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj2.sign();
	    TimeUnit.SECONDS.sleep(3);
	}

	@When("^I enter the Username and Password$")
	public void i_enter_the_Username_and_Password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	obj2.positiveDetails();
	TimeUnit.SECONDS.sleep(3);
	quit();
	launchApplication("chrome","https://www.playstation.com/en-us/");
	TimeUnit.SECONDS.sleep(3);
	obj2.invalidPassword();
	TimeUnit.SECONDS.sleep(3);
	quit();
	TimeUnit.SECONDS.sleep(3);
	launchApplication("chrome","https://www.playstation.com/en-us/");
	obj2.negativeDetails();
	TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I click on Submit button$")
	public void i_click_on_Submit_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   quit();
	}

	@When("^I enter valid Username and Password and sign in to the account$")
	public void i_enter_valid_Username_and_Password_and_sign_in_to_the_account() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(3);
		obj2.positiveDetails();
		TimeUnit.SECONDS.sleep(3);
		
		
	}

	@Then("^Iclick on logout button$")
	public void iclick_on_logout_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   obj2.logout();
	   TimeUnit.SECONDS.sleep(3);
	   quit();
	}

	@Given("^I am on the signin page of playstation$")
	public void i_am_on_the_signin_page_of_playstation() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
		TimeUnit.SECONDS.sleep(3);
	}

	@When("^I click on Trouble Signing In button$")
	public void i_click_on_Trouble_Signing_In_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj3.clicktroublesignin();
	    TimeUnit.SECONDS.sleep(3);
	    
	}

	@When("^I click on Reset your password button$")
	public void i_click_on_Reset_your_password_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj3.clickreset();
	    TimeUnit.SECONDS.sleep(3);
	}

	@When("^I fill the email field$")
	public void i_fill_the_email_field() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj3.fillemail();
	    TimeUnit.SECONDS.sleep(3);
	}

	@Then("^I click on send email$")
	public void i_click_on_send_email() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj3.clicksendemail();
	    TimeUnit.SECONDS.sleep(3);
	    quit();
	}
}
