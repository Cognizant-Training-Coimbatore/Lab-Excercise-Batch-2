package com.stepDefinition;

import java.util.concurrent.TimeUnit;

import com.pages.AllGames;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllGamesTest extends wrapperclass
{
	AllGames obj=new AllGames(driver);
	@Given("^when I am on the homepage$")
	public void when_I_am_on_the_homepage() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	}

	@When("^I click  on the Games button$")
	public void i_click_on_the_Games_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   TimeUnit.SECONDS.sleep(3);
		obj.click_games();
	}

	@When("^I click on All Games button$")
	public void i_click_on_All_Games_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_allgames();
	}

	@When("^I click on New Releases$")
	public void i_click_on_New_Releases() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_newrel();
	}

	@When("^I click on Call of Duty game$")
	public void i_click_on_Call_of_Duty_game() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_call();
	}

	@Then("^information about this game should be displayed$")
	public void information_about_this_game_should_be_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\callofduty.jpeg");
		TimeUnit.SECONDS.sleep(3);
		quit();
	}

	@Given("^when I am on the homepage of playstation$")
	public void when_I_am_on_the_homepage_of_playstation() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	}

	@When("^I click on the Games button(\\d+)$")
	public void i_click_on_the_Games_button(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_games();
	}

	@When("^I click on All Games button(\\d+)$")
	public void i_click_on_All_Games_button(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_allgames();
	}

	@When("^I click on Coming Soon$")
	public void i_click_on_Coming_Soon() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_comsoon();
	}

	@When("^I click on  Nioh (\\d+) game$")
	public void i_click_on_Nioh_game(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_doom();
	}

	@Then("^information about this game should be displayed(\\d+)$")
	public void information_about_this_game_should_be_displayed(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   screenshot("C:\\Users\\admin\\Desktop\\mothercare_baby_fashion\\src\\test\\resources\\com\\screenshot\\doom.jpg"); 
	   TimeUnit.SECONDS.sleep(3);
	   quit();
	}

	@Given("^when I am on the homepage of  playstation(\\d+)$")
	public void when_I_am_on_the_homepage_of_playstation(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.playstation.com/en-us/");
	}

	@When("^I click on the Games button$")
	public void i_click_on_the_Games_button1() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_games();
	}

	@When("^I click on   All Games button$")
	public void i_click_on_All_Games_button1() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_allgames();
	}

	@When("^I click on All releases$")
	public void i_click_on_All_releases() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_allrel();
	}

	@When("^I click on House Flipper game$")
	public void i_click_on_House_Flipper_game() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		TimeUnit.SECONDS.sleep(3);
		obj.click_houseflipper();
	}

	@Then("^many games are displayed$")
	public void many_games_are_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		extentreport(1);
		TimeUnit.SECONDS.sleep(3);
		quit();
	}
}
