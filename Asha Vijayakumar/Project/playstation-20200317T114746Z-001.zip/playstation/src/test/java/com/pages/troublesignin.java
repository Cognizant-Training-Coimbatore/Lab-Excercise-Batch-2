package com.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import baseclass.wrapperclass;
import excelutility.Excel_read_write;


public class troublesignin extends wrapperclass {
public troublesignin(WebDriver driver)
{
	this.driver=driver;
}
public void clicktroublesignin()
{
	driver.findElement(By.id("ember167")).click();
}
public void clickreset() throws InterruptedException
{
	driver.findElement(By.id("ember175")).click();
	TimeUnit.SECONDS.sleep(3);
	 Set<String> allWindowHandles = driver.getWindowHandles();
	 for(String handle : allWindowHandles)
	 {
	 driver.switchTo().window(handle);
	 }
	 }
public void fillemail() throws IOException
{
	 Excel_read_write obj=new Excel_read_write();
	 String email=obj.readExcelData("D:\\stani\\java\\Project_Playstation\\src\\test\\resources\\com\\Testdata\\Playstation.xlsx",1, 0);
	 driver.findElement(By.id("ember15")).sendKeys(email);
}
public void clicksendemail()
{
	driver.findElement(By.id("ember16")).click();
}
}
