package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.baseClass.WrapperClass;

public class filters extends WrapperClass {

	public filters(WebDriver driver) {
		this.driver=driver;
	}
	
	public void slct_prdctfilter()
	{
		driver.findElement(By.xpath("//*[@id=\"filter-trigger\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[2]/ol/li[1]/a")).click();
	}
	public void slct_ctgryfilter()
	{
		driver.findElement(By.xpath("//*[@id=\"filter-trigger\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[2]/a")).click();
		
	}

}
