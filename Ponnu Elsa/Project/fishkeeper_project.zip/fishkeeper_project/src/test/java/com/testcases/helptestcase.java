package com.testcases;


import com.baseClass.WrapperClass;
import com.pages.help;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class helptestcase extends WrapperClass {
    help obj = new help(driver);
	@Given("^the user is in homepage$")
	public void the_user_is_in_homepage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
	    
	}

	@When("^the user selects help and advice$")
	public void the_user_selects_help_and_advice() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_help_and_advice();
	    
	}

	@Then("^validating the page navigation$")
	public void validating_the_page_navigation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean stat=obj.checkurl();
		String s=Boolean.toString(stat);
		System.out.println(s); 
	}

	@Given("^the user clicks on browse freshwater databank$")
	public void the_user_clicks_on_browse_freshwater_databank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_freshwater_databank();
	    
	}

	@When("^user clicks on refine search$")
	public void user_clicks_on_refine_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_refine_search();
	    
	}

	@Then("^user click on pondfish$")
	public void user_click_on_pondfish() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_pondfish();
	    
	}

	@Then("^user selects canary goldfish$")
	public void user_selects_canary_goldfish() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_canary_goldfish();
		obj.close_browser();
	   
	}

	@Given("^user clicck on browse marine databank$")
	public void user_clicck_on_browse_marine_databank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_help_and_advice();
		obj.click_browse_marine_databank();
	   
	}

	@When("^user click on refine search$")
	public void user_click_on_refine_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_refine_search();
	    
	}

	@Then("^user clicks on soft corals$")
	public void user_clicks_on_soft_corals() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_softcoral();
	   
	}

	@Then("^user clicks on button polyps$")
	public void user_clicks_on_button_polyps() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_buttonpolyps();
		obj.close_browser();
	    
	}

	@Given("^the user clicks on plant databank$")
	public void the_user_clicks_on_plant_databank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		close_iframe();
		acpt_cookies();
		obj.click_help_and_advice();
		obj.click_browse_plant_databank();
	    
	}

	@When("^user click on refine search button$")
	public void user_click_on_refine_search_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    obj.click_refine_search();
	}

	@Then("^user clicks on aquarium plant$")
	public void user_clicks_on_aquarium_plant() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_aquarium_plants();
	    
	}

	@Then("^user clicks on ammania gracilis$")
	public void user_clicks_on_ammania_gracilis() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_plant();
		obj.close_browser();
	    
	}

	@Given("^the user clicks on faq$")
	public void the_user_clicks_on_faq() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_help_and_advice();
		obj. clik_faq();
	    
	}

	@When("^user click on tropical$")
	public void user_click_on_tropical() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_tropical();
	   
	}

	@Then("^user clicks on first question$")
	public void user_clicks_on_first_question() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.clik_first_ques();
	  
	}

	@Then("^user clicks on back to faq$")
	public void user_clicks_on_back_to_faq() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.bck_to_faq();
		obj.close_browser();
	    
	}

	@Given("^the user clicks on fish glossary$")
	public void the_user_clicks_on_fish_glossary() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_help_and_advice();
		obj.click_learnmore();
	    
	}

	@When("^user click on d letter$")
	public void user_click_on_d_letter() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_letter_d();
	   
	}

	@Then("^user clicks on dead spot$")
	public void user_clicks_on_dead_spot() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.clik_deadspot();
	    
	}

	@Then("^close browser$")
	public void close_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

}
