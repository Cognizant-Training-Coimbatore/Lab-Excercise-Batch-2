package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.baseClass.WrapperClass;


public class help extends WrapperClass{
	public help(WebDriver driver)
	{
		this.driver = driver;
	}
	public void click_help_and_advice()
	{
		driver.findElement(By.xpath("//*[@id=\"store.menu\"]/nav/ul/li[4]/a/span")).click();
	}
	public boolean checkurl()
	{
		String url=driver.getCurrentUrl();
		return(url.equalsIgnoreCase("https://www.fishkeeper.co.uk/help-and-advice"));
	}
	public void click_freshwater_databank()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[3]/div/div[2]/div[1]/div/div[4]/a")).click();
	}
	public void click_refine_search()
	{
		driver.findElement(By.xpath("//*[@id=\"filter-trigger\"]")).click();
	}
	public void click_pondfish()
	{
		driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div/div[2]/ol/li[4]/a")).click();
	}
	public void click_canary_goldfish()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/section/section/div[3]/div[1]/div[2]/a/div[2]/div[1]")).click();
	}
	public void click_browse_marine_databank()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[3]/div/div[2]/div[2]/div/div[4]/a")).click();
	}
	public void click_softcoral()
	{
		driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div/div[2]/ol/li[4]/a")).click();
	}
	public void click_buttonpolyps()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/section/section/div[3]/div[1]/div[1]/a/div[2]/div[1]")).click();
	}
	public void click_browse_plant_databank()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[3]/div/div[2]/div[3]/div/div[4]/a")).click();
	}
	public void click_aquarium_plants()
	{
		driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div/div[2]/ol/li[3]/a")).click();
	}
	public void click_plant()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/section/section/div[3]/div[1]/div[4]/a/div[2]/div[1]")).click();
	}
	public void clik_faq()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[4]/div/div[2]/div[1]/div/div[4]/a")).click();
	}
	public void click_learnmore()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[4]/div/div[2]/div[4]/div/div[4]/a")).click();
	}
	public void click_tropical()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div[1]/ul/li[3]/a")).click();
	}
	public void clik_first_ques()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div[2]/div/div[3]/div[1]/a")).click();
	}
	public void click_letter_d()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div[1]/ul/li[5]/a")).click();
	}
	public void clik_deadspot()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div[2]/div/div[6]/p[2]")).click();
	}
	public void bck_to_faq()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div[2]/div/a")).click();
	}
	public void close_browser()
	{
		driver.quit();
	}

}
