package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.baseClass.WrapperClass;
import com.excelUtility.excelReadWrite;


public class homepage extends WrapperClass{
String excelPath ="C:\\Users\\Admin\\Desktop\\fishkeeper.xlsx";
excelReadWrite objexcel;
public homepage(WebDriver driver) {

this.driver=driver;
}
public void click_gift()
{
driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[2]/section/div/ul/li[1]/p/a/span[1]")).click();

}
public void click_buy_gift_cards() throws InterruptedException
{
Actions action=new Actions(driver);
//using the Arrow down key in keyboard using Actions method
action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
TimeUnit.SECONDS.sleep(1);                                                                                                                                                                  
action.sendKeys(Keys.ARROW_DOWN).build().perform();


driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[3]/div/div/div[1]/div/div[4]/a")).click();
}
public void issue_card() throws InterruptedException, IOException
{//*[@id="maincontent"]/div[3]/div/div[3]/div/div/div[1]/div/div[4]/a

objexcel=new excelReadWrite(excelPath);
String stname="Issuecard";
int totalRows = objexcel.getTotalRows(stname);
int totalColumns = objexcel.getTotalcolumns(stname);
for(int row = 1;row< totalRows; row++)
{
objexcel.writeExcelData(row, 8, "Pass", stname);
for(int column = 0; column<totalColumns; column++)
{

if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Gift card Number"))
{

driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[2]/div/form/fieldset/div/div[1]/div/input")).sendKeys(objexcel.readExcelData(row, column,stname));

}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("value on gift card"))
{
driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[2]/div/form/fieldset/div/div[2]/div/input")).sendKeys(objexcel.readExcelData(row, column,stname));

}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Message"))
{
driver.findElement(By.name("message")).sendKeys(objexcel.readExcelData(row, column,stname));
}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Full name"))
{

driver.findElement(By.name("fullname")).sendKeys(objexcel.readExcelData(row, column,stname));

}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Address"))
{
driver.findElement(By.name("address")).sendKeys(objexcel.readExcelData(row, column,stname));

}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Email"))
{
driver.findElement(By.name("email")).sendKeys(objexcel.readExcelData(row, column,stname));

}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Contact No"))
{
driver.findElement(By.name("contact_number")).sendKeys(objexcel.readExcelData(row, column,stname));
}
else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Store Purchased from"))
{
driver.findElement(By.name("store")).sendKeys(objexcel.readExcelData(row, column,stname));
}
}

driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[2]/div/form/div/div/button")).click();
TimeUnit.SECONDS.sleep(3);
driver.navigate().to("https://www.fishkeeper.co.uk/gift-cards");
}
driver.navigate().to("https://www.fishkeeper.co.uk/");
}
public void buy_clothing() throws InterruptedException {


Actions act = new Actions(driver);

driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[2]/section/div/ul/li[1]/p/a/span[1]")).click();
TimeUnit.SECONDS.sleep(1);
act.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
act.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
act.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
act.sendKeys(Keys.ARROW_DOWN).build().perform();
    driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[3]/div/div/div[2]/div/div[4]")).click();
Actions action=new Actions(driver);
//using the Arrow down key in keyboard using Actions method
action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();

driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[2]/div/div/div[2]/div/div[3]")).click();

action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
    driver.findElement(By.xpath("//*[@id=\"filter-trigger\"]")).click();
//waiting for 1 second
TimeUnit.SECONDS.sleep(2);
    driver.findElement(By.linkText("In Stock Online")).click();
}

public void add_to_bskt() throws InterruptedException
{
Actions action=new Actions(driver);
//using the Arrow down key in keyboard using Actions method
action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();



driver.findElement(By.xpath("//*[@id=\"products-container\"]/ol/li[3]/div/div/div[3]/div/div")).click();

action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();

driver.findElement(By.xpath("//*[@id=\"product-options-wrapper\"]/div/div/div/div/span[1]")).click();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();


driver.findElement(By.xpath("//*[@id=\"product-addtocart-button\"]")).click();
}
public void check_basket() throws InterruptedException
{
/*Actions act = new Actions(driver);
//WebElement elem = driver.findElement(By.xpath("//a[@title=\"Go to Home Page\"]"));
WebElement elem = driver.findElement(By.xpath(""));
act.moveToElement(elem).build().perform();
act.click().build().perform();
 
 driver.findElement(By.xpath("/html/body/div[4]/header/div[1]/div/div[3]/div/span/svg")).click();
 TimeUnit.SECONDS.sleep(2);*/
driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[2]/div/div/div/a")).click();
TimeUnit.SECONDS.sleep(1);
Actions action=new Actions(driver);
//using the Arrow down key in keyboard using Actions method
action.sendKeys(Keys.ARROW_DOWN).build().perform();
//waiting for 1 second
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();
TimeUnit.SECONDS.sleep(1);
action.sendKeys(Keys.ARROW_DOWN).build().perform();



}
public void close_browser() {

driver.quit();

}
}
