package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.baseClass.WrapperClass;

public class search extends WrapperClass {
	
	public search(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void srch_item()
	{
		driver.findElement(By.id("search")).sendKeys("aquarium",Keys.ENTER);
	}
	
	public String chk_url()
	{
		String check=driver.getCurrentUrl();
		if(check!="https://www.fishkeeper.co.uk/")
		{
			return("Page is navigated");
		}
		else
		{
			return("Failed test");
		}
	}
	public void slctfrm_list()
	{
		driver.findElement(By.xpath("//*[@id=\"qs-option-1\"]/div")).click();
	}

}
