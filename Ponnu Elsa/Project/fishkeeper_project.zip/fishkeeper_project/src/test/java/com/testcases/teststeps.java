package com.testcases;


import com.baseClass.WrapperClass;
import com.pages.homepage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class teststeps extends WrapperClass
{

	homepage obj = new homepage(driver);

	@Given("^I am on the home page$")
	public void i_am_on_the_home_page() throws Throwable {
		launchApplication("chrome", "https:www.fishkeeper.co.uk/");
		 close_iframe();
		 acpt_cookies();
	  
	}

	@When("^I click on gift shop$")
	public void i_click_on_gift_shop() throws Throwable {
		obj.click_gift();
	}

	@When("^I click on the Buy Gift Cards$")
	public void i_click_on_the_Buy_Gift_Cards() throws Throwable {
		obj.click_buy_gift_cards();

	}

	@When("^I type in the issue with card details$")
	public void i_type_in_the_issue_with_card_details() throws Throwable {
		obj.issue_card();
	    System.out.println("submitted");

	}

	@When("^I click on the buy clothing$")
	public void i_click_on_the_buy_clothing() throws Throwable {
		
		obj.buy_clothing();
		obj.add_to_bskt();
		obj.check_basket();
		obj.close_browser();
		
	}

	@When("^I click on reefscape model$")
	public void i_click_on_reefscape_model() throws Throwable {

	}

	@When("^I click on browsebooks$")
	public void i_click_on_browsebooks() throws Throwable {
	    
	}


}

