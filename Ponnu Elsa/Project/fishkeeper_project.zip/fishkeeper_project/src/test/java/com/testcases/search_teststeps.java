package com.testcases;

import org.openqa.selenium.By;

import com.baseClass.WrapperClass;
import com.pages.search;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class search_teststeps extends WrapperClass {
	search obj2=new search(driver);
	
	@Given("^User is on the home page$")
	public void user_is_on_the_home_page() throws Throwable {
	    launchApplication("chrome","https://www.fishkeeper.co.uk/");
	    try {
	    close_iframe();
	    }
	    catch (Exception e) {
			System.out.println("no iframe");
		}
	    close_nxt();
	    acpt_cookies();
	}

	@When("^User searches for a product$")
	public void user_searches_for_a_product() throws Throwable {
		obj2.srch_item();
	   
	}

	@Then("^Check whether the page is navigated$")
	public void check_whether_the_page_is_navigated() throws Throwable {
	    obj2.chk_url();
	    driver.quit();
	}

	@Given("^The User is in the home page$")
	public void the_User_is_in_the_home_page() throws Throwable {
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
	    close_iframe();
	    acpt_cookies();
	}

	@When("^User enters a product in search bar$")
	public void user_enters_a_product_in_search_bar() throws Throwable {
		driver.findElement(By.id("search")).sendKeys("aquarium");
		
	}

	@When("^selects product from listed options$")
	public void selects_product_from_listed_options() throws Throwable {
	    obj2.slctfrm_list();
	}

	@Then("^Check whether the product is displayed$")
	public void check_whether_the_product_is_displayed() throws Throwable {
	    obj2.chk_url();
	    driver.quit();
	}


}
