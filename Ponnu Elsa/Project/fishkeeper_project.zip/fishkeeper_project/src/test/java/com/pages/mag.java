package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.baseClass.WrapperClass;


public class mag extends WrapperClass{
	public mag(WebDriver driver)
	{
		this.driver = driver;
	}
	public void click_magazine()
	{
		driver.findElement(By.xpath("//*[@id=\"store.menu\"]/nav/ul/li[3]/a")).click();
	}
	public boolean checkurl()
	{
		String url=driver.getCurrentUrl();
		return(url.equalsIgnoreCase("https://www.fishkeeper.co.uk/stories"));
	}
	public void click_news()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[1]/a")).click();
	}
	public void click_general_fishkeeping()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[2]/a")).click();
	}
	public void click_our_stores()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[3]/a")).click();
	}
	public void click_aquarium()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[4]/a")).click();
	}
	public void click_pond()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[5]/a")).click();
	}
	public void click_fin()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[6]/a")).click();
	}
	public void click_fishkeeperfry()
	{
		driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/li[7]/a")).click();
	}
	public void click_firstlink1()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[2]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink2()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink3()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink4()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink5()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink6()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void click_firstlink7()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[3]/div[2]/ol/li[1]/div[2]/div[2]/a")).click();
	}
	public void close_browser()
	{
		driver.quit();
	}

}
