package com.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.baseClass.WrapperClass;
import com.excelUtility.excelReadWrite;
import com.pages.login_page;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login_teststeps extends WrapperClass{
login_page obj=new login_page(driver);
	
	String excelPath ="C:\\Users\\Admin\\Desktop\\fishkeeper.xlsx";
	excelReadWrite objexcel;
	
	ExtentReports report = new ExtentReports("src\\test\\resources\\com\\extend_reports\\login_test.html");
	ExtentTest test = report.startTest("Login_TEST");
	
	@Given("^I want to login with username and password$")
	public void i_want_to_login_with_username_and_password() throws Throwable {
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
	    close_iframe();
		}
		catch (Exception e) {
			System.out.println("no iframe");
		}
		close_nxt();
	    acpt_cookies();
	}

	@When("^User clicks on my account$")
	public void user_clicks_on_my_account() throws Throwable {
		obj.click_login();
		test.log(LogStatus.PASS, "Successfully clicked login");
	}

	@When("^enters \"([^\"]*)\"\"([^\"]*)\"$")
	public void enters(String uname, String pswd) throws Throwable {
		obj.pagedown();
	    driver.findElement(By.id("email")).sendKeys(uname);
	    driver.findElement(By.id("pass")).sendKeys(pswd);
	    test.log(LogStatus.PASS,"Successfully passed username and password");
	}
	
	@When("^clicks on sign in$")
	public void clicks_on_sign_in() {
		driver.findElement(By.id("send2")).click();
		test.log(LogStatus.PASS,"Successfully submitted");
	}
	
	@Then("^I verify the \"([^\"]*)\" in step$")
	public void i_verify_the_in_step(String row) throws IOException  {
		int i = Integer.parseInt(row);
		excelReadWrite excel = new excelReadWrite(excelPath);
			if(i>1)
			{
				screenshot("src\\test\\resources\\com\\screenshots\\ss"+i+".jpg");
			}
			
			excel.writeExcelData(i, 2, "Pass","Login");
			report.endTest(test);
			report.flush();
			driver.close();
		}

	

	@Given("^The User is in login page$")
	public void the_User_is_in_login_page() throws Throwable {
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
	    close_iframe();
		}
		catch (Exception e) {
			System.out.println("no iframe");
		}
	    close_nxt();
	    acpt_cookies();
	    obj.click_login();
	}

	@When("^User clicks on forgot password$")
	public void user_clicks_on_forgot_password() throws Throwable {
	    obj.click_forgotpswd();
	}

	@When("^User enters the email account$")
	public void user_enters_the_email_account() throws Throwable {
	    obj.enter_mailid();
	}

	@Then("^Check whether message is displayed saying the mail is sent$")
	public void check_whether_message_is_displayed_saying_the_mail_is_sent() throws Throwable {
		TimeUnit.SECONDS.sleep(4);
	    String msg=driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[2]/div/div/div")).getText();
	    System.out.println(msg);
	    driver.quit();
	}

	@Given("^User is on the login page$")
	public void user_is_on_the_login_page() throws Throwable {
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
	    close_iframe();
		}
		catch (Exception e) {
			System.out.println("no iframe");
		}
	    close_nxt();
	    acpt_cookies();
	    obj.click_login();
	}

	@When("^User clicks on create my account$")
	public void user_clicks_on_create_my_account() throws Throwable {
	    obj.click_createacc();
	}

	@Then("^User enters required information and clicks on create account$")
	public void user_enters_required_information_and_clicks_on_create_account() throws Throwable {
		objexcel=new excelReadWrite(excelPath);
		String stname="CreateAccount";
		int totalRows = objexcel.getTotalRows(stname);
		int totalColumns = objexcel.getTotalcolumns(stname);
			for(int row = 1;row<totalRows; row++)
			{
				objexcel.writeExcelData(row, 10, "Pass", stname);
				for(int column = 0; column<totalColumns; column++)
				{
					
					if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Title"))
					{
						try {
						Select product=new Select(driver.findElement(By.id("prefix")));
						product.selectByVisibleText(objexcel.readExcelData(row, column,stname));
						}
						catch(Exception e)
						{
							System.out.println("no title specified");
						}
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("First Name"))
					{
						driver.findElement(By.id("firstname")).sendKeys(objexcel.readExcelData(row, column,stname));
						
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Last Name"))
					{
						driver.findElement(By.id("lastname")).sendKeys(objexcel.readExcelData(row, column,stname));
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Email"))
					{
						try {
						driver.findElement(By.id("email_address")).sendKeys(objexcel.readExcelData(row, column,stname));
						}
						catch (Exception e) {
							System.out.println("No email specified");
						}
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("ReEmail"))
					{
						try {
						driver.findElement(By.id("email_address_confirm")).sendKeys(objexcel.readExcelData(row, column,stname));
						}
						catch (Exception e) {
							System.out.println("No email specified");
						}
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("Password"))
					{
						try {
						driver.findElement(By.id("password")).sendKeys(objexcel.readExcelData(row, column,stname));
						}
						catch (Exception e) {
							System.out.println("No password specified");
						}
						
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("RePass"))
					{
						try{
						driver.findElement(By.id("password-confirmation")).sendKeys(objexcel.readExcelData(row, column,stname));
						}
						catch (Exception e) {
							System.out.println("No password specified");
						}
						TimeUnit.SECONDS.sleep(3);
						JavascriptExecutor js1 = (JavascriptExecutor) driver;
						js1.executeScript("window.scrollBy(0,-500)", "");
					}
					else if(objexcel.readExcelData(0,column,stname).equalsIgnoreCase("acceptTC"))
					{
						String TandC=objexcel.readExcelData(row, column,stname);
						try
						{
						if(TandC=="Yes")
						{
							TimeUnit.SECONDS.sleep(4);
							
							WebElement element=driver.findElement(By.xpath("//*[@id=\"agreement-1\"]"));
							JavascriptExecutor js = (JavascriptExecutor) driver;
							js.executeScript("arguments[0].click();", element);
							
						}
						}
						catch (Exception e) {
							System.out.println("Unable to tick");
						}
						
					}
										
				}
				try {
			    	driver.findElement(By.xpath("//*[@id=\"form-validate\"]/fieldset[2]/div[2]/div[1]/button")).click();
			    }
			    catch(Exception e)
			    {
			    	System.out.println("unable to create account");
			    }
				screenshot("src\\test\\resources\\com\\screenshots\\login"+row+".jpg");
				
				TimeUnit.SECONDS.sleep(5);
				driver.navigate().to("https://www.fishkeeper.co.uk/customer/account/create/");
			}
			
		    driver.close();
	    
	}

}