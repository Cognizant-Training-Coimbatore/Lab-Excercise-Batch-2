package com.testcases;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.pages.ponds;
import com.baseClass.WrapperClass;
import com.pages.login_page;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ponds_teststeps extends WrapperClass {
ponds obj=new ponds(driver);
public String pro_name="";


@Given("^User is on home page$")
public void user_is_on_home_page() throws Throwable {
   launchApplication("chrome", "https://www.fishkeeper.co.uk/");
   close_iframe();
   acpt_cookies();
   
}

@When("^User clicks a tab$")
public void user_clicks_a_tab() throws Throwable {
obj.click_tabs();
}

@When("^User selects a product$")
public void user_selects_a_product() throws Throwable {

  obj.slct_prdct();
 
}

@When("^add to basket$")
public void add_to_basket() throws Throwable {
pro_name=obj.get_name();
obj.add_to_bskt();


}

@Then("^checks the basket whether the product is added$")
public void checks_the_basket_whether_the_product_is_added() throws Throwable {
   obj.check_bskt();
   
int flag=0;

//Actions act=new Actions(driver);

TimeUnit.SECONDS.sleep(2);
//close_iframe();
List<WebElement> pro_link=driver.findElements(By.tagName("a"));
int num_links=pro_link.size();
for(WebElement name:pro_link)
{
String name_of_pro=name.getText();
if(name_of_pro.equalsIgnoreCase(pro_name))
{
flag=1;
break;
}

}
if(flag==1)
{
System.out.println("Item added to the cart");
}
else
{
System.out.println("Item not in the cart");
}
driver.quit();
}

@Given("^User is on home page of the site$")
public void user_is_on_home_page_of_the_site() throws Throwable {
   
launchApplication("chrome", "https://www.fishkeeper.co.uk/");
   close_iframe();
   acpt_cookies();

}

@When("^User selects a subtab$")
public void user_selects_a_subtab() throws Throwable {
 obj.select_subtabs();
}

@When("^User selects a product from the page$")
public void user_selects_a_product_from_the_page() throws Throwable {
obj.slct_prdct();
}

@When("^add the product to basket$")
public void add_the_product_to_basket() throws Throwable {
pro_name=obj.get_name();
obj.add_to_bskt();
}

@Then("^checks the basket to check if the product is added$")
public void checks_the_basket_to_check_if_the_product_is_added() throws Throwable {
   obj.check_bskt();
   
int flag=0;

//Actions act=new Actions(driver);

TimeUnit.SECONDS.sleep(2);
//close_iframe();
List<WebElement> pro_link=driver.findElements(By.tagName("a"));
int num_links=pro_link.size();
for(WebElement name:pro_link)
{
String name_of_pro=name.getText();
if(name_of_pro.equalsIgnoreCase(pro_name))
{
flag=1;
break;
}

}
if(flag==1)
{
System.out.println("Item added to the cart");
}
else
{
System.out.println("Item not in the cart");
}
driver.quit();
}



}