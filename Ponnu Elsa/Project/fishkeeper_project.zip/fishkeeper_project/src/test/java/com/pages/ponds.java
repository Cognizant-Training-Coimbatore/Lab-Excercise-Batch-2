package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.baseClass.WrapperClass;


public class ponds extends WrapperClass{
//By product=By.xpath("//*[@id=\"products-container\"]/ol[1]/li[1]/div/div/a");

public ponds(WebDriver driver)
{
this.driver=driver;
}

public void click_tabs()
{
driver.findElement(By.xpath("//*[@id=\"store.menu\"]/nav/ul/li[2]/a")).click();
}

public void slct_prdct()
{
driver.findElement(By.xpath("//*[@id=\"products-container\"]/ol/li[1]/div/div/a")).click();;

}

public String get_name()
{
String name=driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div/div[1]/h1/span")).getText();
return name;
}

public void add_to_bskt()
{
try
{
driver.findElement(By.xpath("//*[@id=\"product-options-wrapper\"]/div/div/div/div[1]/span[2]")).click();
}
catch(Exception e)
{
System.out.println("single option  available");
}

driver.findElement(By.id("product-addtocart-button")).click();
}

public void check_bskt()
{
driver.findElement(By.xpath("/html/body/div[4]/header/div[1]/div/div[3]/div/span")).click();
driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[1]/div[2]/div/div/div/a")).click();

}
public void select_subtabs()
{
Actions act=new Actions(driver);
WebElement tab=driver.findElement(By.xpath("//*[@id=\"store.menu\"]/nav/ul/li[1]/a"));
act.moveToElement(tab).build().perform();
driver.findElement(By.linkText("Aqua Oak")).click();
}

}