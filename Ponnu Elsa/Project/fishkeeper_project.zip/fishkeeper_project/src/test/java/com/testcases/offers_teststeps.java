package com.testcases;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.baseClass.WrapperClass;
import com.pages.offers;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class offers_teststeps extends WrapperClass {
offers obj=new offers(driver);
public String pro_name="";


@Given("^User is on the home page$")
public void user_is_on_the_home_page() throws Throwable {
   launchApplication("chrome", "https://www.fishkeeper.co.uk/");
   close_iframe();
   acpt_cookies();
   
}

@When("^User clicks the special offers tab$")
public void user_clicks_the_special_offers_tab() throws Throwable {
obj.click_tabs();
}

@When("^User selects the product$")
public void user_selects_the_product() throws Throwable {

  obj.slct_prdct();
 
}

@When("^User add the item to cart$")
public void user_add_the_item_to_cart() throws Throwable {
pro_name=obj.get_name();
obj.add_to_bskt();


}

@Then("^User checks the cart whether the item is added$")
public void user_checks_the_cart_whether_the_item_is_added() throws Throwable {
   obj.check_bskt();
   
int flag=0;

//Actions act=new Actions(driver);

TimeUnit.SECONDS.sleep(2);
//close_iframe();
List<WebElement> pro_link=driver.findElements(By.tagName("a"));
int num_links=pro_link.size();
for(WebElement name:pro_link)
{
String name_of_pro=name.getText();
if(name_of_pro.equalsIgnoreCase(pro_name))
{
flag=1;
break;
}

}
if(flag==1)
{
System.out.println("Item added to the cart");
}
else
{
System.out.println("Item not in the cart");
}
driver.quit();
}




@Given("^User browse the homepage$")
public void user_browse_the_homepage() throws Throwable {
launchApplication("chrome", "https://www.fishkeeper.co.uk/");
    close_iframe();
    acpt_cookies();
   
}

@When("^User clicks  special offers tab$")
public void user_clicks_special_offers_tab() throws Throwable {
obj.click_tabs1();
   
}

@When("^User selects the filters option$")
public void user_selects_the_filters_option() throws Throwable {
obj.slct_filter();

   
}

@When("^User applies the required filters$")
public void user_applies_the_required_filters() throws Throwable {
driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[2]/ol/li[1]/a")).click();
obj.slct_filter();
driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/ol/li[1]/a")).click();
obj.slct_filter();
TimeUnit.SECONDS.sleep(5);
driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/div/ol/li[1]/a")).click();
obj.slct_filter();
driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[3]/div[2]/div/div[4]/div[2]/a")).click();

   
}

@When("^User selects the desired product$")
public void user_selects_the_desired_product() throws Throwable {
obj.slct_prdct1();
   
}

@When("^User add the item to correct$")
public void user_add_the_item_to_correct() throws Throwable {
pro_name=obj.get_name();
obj.add_to_bskt1();


}

@Then("^Checks  the cart whether item is added$")
public void checks_the_cart_whether_item_is_added() throws Throwable {
obj.check_bskt1();
   
int flag=0;

//Actions act=new Actions(driver);

TimeUnit.SECONDS.sleep(2);
//close_iframe();
List<WebElement> pro_link=driver.findElements(By.tagName("a"));
int num_links=pro_link.size();
for(WebElement name:pro_link)
{
String name_of_pro=name.getText();
if(name_of_pro.equalsIgnoreCase(pro_name))
{
flag=1;
break;
}

}
if(flag==1)
{
System.out.println("Item added to the cart");
}
else
{
System.out.println("Item not in the cart");
}
driver.quit();

}


}