package com.testcases;

import com.baseClass.WrapperClass;
import com.pages.mag;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class magtestcase extends WrapperClass{
	mag obj = new mag(driver);
	@Given("^the user is on homepage$")
	public void the_user_is_on_homepage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
	    
	}

	@When("^the user selects magazine$")
	public void the_user_selects_magazine() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_magazine();
	    
	}

	@Then("^validate the page navigation$")
	public void validate_the_page_navigation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean stat=obj.checkurl();
		String s=Boolean.toString(stat);
		System.out.println(s);
	   
	}

	@Given("^the user clicks on newss$")
	public void the_user_clicks_on_newss() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_news();
	   
	}

	@When("^uuser clicks on first link$")
	public void uuser_clicks_on_first_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink1();
	    
	}

	@Then("^closing browsers$")
	public void closing_browsers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

	@Given("^the user clicks on general fishkeepingg$")
	public void the_user_clicks_on_general_fishkeepingg() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
	    obj.click_general_fishkeeping();
	}

	@When("^user cclicks on first link$")
	public void user_cclicks_on_first_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink2();
	    
	}

	@Then("^cclosing browser$")
	public void cclosing_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	   
	}

	@Given("^the user clicks on our storess$")
	public void the_user_clicks_on_our_storess() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
		obj.click_our_stores();
	    
	}

	@When("^user clicks oon first link$")
	public void user_clicks_oon_first_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink3();
	    
	}

	@Then("^cllosing browser$")
	public void cllosing_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

	@Given("^the user clicks on aquariumm$")
	public void the_user_clicks_on_aquariumm() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
		obj.click_aquarium();
	    
	}

	@When("^user clicks on ffirst link$")
	public void user_clicks_on_ffirst_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink4();
	    
	}

	@Then("^cloosing browser$")
	public void cloosing_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

	@Given("^the user clicks on pondd$")
	public void the_user_clicks_on_pondd() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
		obj.click_pond();
	    
	}

	@When("^user clicks on first llink$")
	public void user_clicks_on_first_llink() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink5();
	    
	}

	@Then("^closiing browser$")
	public void closiing_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

	@Given("^the user clicks on finn$")
	public void the_user_clicks_on_finn() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
		obj.click_fin();
	    
	}

	@When("^user clicks on first linkk$")
	public void user_clicks_on_first_linkk() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink6();
	    
	}

	@Then("^closingg browser$")
	public void closingg_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

	@Given("^the user clicks on fishkeeper fry$")
	public void the_user_clicks_on_fishkeeper_fry() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		launchApplication("chrome","https://www.fishkeeper.co.uk/");
		try {
		    close_iframe();
			}
			catch (Exception e) {
				System.out.println("no iframe");
			}
			close_nxt();
		acpt_cookies();
		obj.click_magazine();
		obj.click_fishkeeperfry();
	    
	}

	@When("^user clicks on first linnk$")
	public void user_clicks_on_first_linnk() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.click_firstlink7();
	    
	}

	@Then("^closing browseer$")
	public void closing_browseer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj.close_browser();
	    
	}

}
