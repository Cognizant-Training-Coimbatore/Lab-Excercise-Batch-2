package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.baseClass.WrapperClass;

public class login_page extends WrapperClass{
	
	//locators
	//By login=By.xpath("/html/body/div[3]/header/div[1]/div/div[2]/div/a[1]");
	By logout=By.xpath("//*[@id=\"account-nav\"]/ul/li[9]/a");
	
	public login_page(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void click_login()
	{
		driver.findElement(By.xpath("//*[@title=\"Your Account\"]")).click();
		
	}
	
	public void pagedown() throws InterruptedException
	{
		//creating object for Actions method
				Actions action=new Actions(driver);
				//using the Arrow down key in keyboard using Actions method
				action.sendKeys(Keys.ARROW_DOWN).build().perform();
				//waiting for 1 second
				TimeUnit.SECONDS.sleep(1);
				action.sendKeys(Keys.ARROW_DOWN).build().perform();
				TimeUnit.SECONDS.sleep(1);
				action.sendKeys(Keys.ARROW_DOWN).build().perform();
				TimeUnit.SECONDS.sleep(1);
				action.sendKeys(Keys.ARROW_DOWN).build().perform();
				TimeUnit.SECONDS.sleep(1);
	}
	
	public void click_signin()
	{
		driver.findElement(By.id("send2")).click();
	}
	
	public boolean checkurl()
	{
		String url=driver.getCurrentUrl();
		return(url.equalsIgnoreCase("https://www.fishkeeper.co.uk/customer/account/index/"));
	}
	
	
	public void logout()
	{
		driver.findElement(logout).click();
	}
	
	public void click_forgotpswd()
	{
		driver.findElement(By.xpath("//*[@id=\"login-form\"]/fieldset/div[3]/div[2]/a")).click();
	}
	
	public void enter_mailid()
	{
		driver.findElement(By.id("email_address")).sendKeys("me.eliswa@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"form-validate\"]/div/div/button")).click();
	}
	public void click_createacc()
	{
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div/div[2]/div[2]/div[2]/div/div/a")).click();
	}
	
	

}
