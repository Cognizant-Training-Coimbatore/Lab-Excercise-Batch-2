package com.testcases;

import org.openqa.selenium.By;

import com.baseClass.WrapperClass;
import com.pages.filters;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class filters_teststeps extends WrapperClass {
	filters obj3=new filters(driver);
	
	@Given("^User is on search page$")
	public void user_is_on_search_page() throws Throwable {
		launchApplication("chrome", "https://www.fishkeeper.co.uk/");
	    close_iframe();
	    acpt_cookies();
	    driver.findElement(By.xpath("//*[@id=\"store.menu\"]/nav/ul/li[1]/a")).click();
	}

	@When("^User selects from product options$")
	public void user_selects_from_product_options() throws Throwable {
		obj3.slct_prdctfilter();
	    
	}

	@When("^selects category$")
	public void selects_category() throws Throwable {
	    obj3.slct_ctgryfilter();
	}

	@When("^selects the price range$")
	public void selects_the_price_range() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^selects the preferred brands$")
	public void selects_the_preferred_brands() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Checks the output$")
	public void checks_the_output() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
