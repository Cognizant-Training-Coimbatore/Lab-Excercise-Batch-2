package com.excelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelReadWrite {

	XSSFWorkbook workbook;
	XSSFSheet sheet;
	FileInputStream inputStream;
	FileOutputStream outputStream;
	String filePath;
	
	public excelReadWrite(String path) 
	{
		filePath = path;
	}
	
	//To read excel data
	public String readExcelData(int rowNumber, int colNumber,String sheetname) throws IOException 
	{
		inputStream = new FileInputStream(new File(filePath));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet(sheetname);	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.getCell(colNumber);
		
		String value = cell.getStringCellValue();
		inputStream.close();
		return value;
	}
	
	//To write excel data
	public void writeExcelData(int rowNumber, int columnNumber, String data,String sheetname) throws IOException
	{
		inputStream = new FileInputStream(new File(filePath));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet(sheetname);	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.createCell(columnNumber);
		cell.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File(filePath));
		workbook.write(outputStream);
        outputStream.close();
	}
	
	public int getTotalRows(String sheetname) throws IOException 
	{
		inputStream = new FileInputStream(new File(filePath));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet(sheetname);	
		int totalRows = sheet.getLastRowNum();
		inputStream.close();
		
		return(totalRows);		
	}
	
	public int getTotalcolumns(String sheetname) throws IOException 
	{
		inputStream = new FileInputStream(new File(filePath));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet(sheetname);	
		
		int totalcolumns = sheet.getRow(1).getLastCellNum();
		inputStream.close();
		
		return(totalcolumns);		
	}
}
