package com.baseClass;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xdgf.usermodel.section.geometry.MoveTo;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class WrapperClass {
	
	//creating webdriver object	
	protected static WebDriver driver;
	
		
	public void close_iframe() throws InterruptedException
	{
		driver.switchTo().frame("cloudiqOverlayIframe");
		driver.findElement(By.id("cloudiqClose")).click();
		TimeUnit.SECONDS.sleep(3);
		driver.switchTo().parentFrame();
	}
	public void close_nxt() throws InterruptedException
	{
		
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div[2]/div[1]/img")).click();
		TimeUnit.SECONDS.sleep(2);
	}
	
	public void acpt_cookies()
	{
		driver.findElement(By.id("btn-cookie-allow")).click();
	}
		
		public void launchApplication(String browser,String url) throws InterruptedException
		{
			try
			{
				//to launch firefox
				if(browser.equalsIgnoreCase("firefox"))
				{
					
					//geckodriver root path integration
					System.setProperty("webdriver.gecko.driver","src\\test\\resources\\com\\drivers\\geckodriver.exe");
					//creating an object for firefox browser
					driver=new FirefoxDriver();
				}
				//to launch chrome driver
				else if(browser.equalsIgnoreCase("chrome"))
				{
					ChromeOptions opt=new ChromeOptions();
					opt.addArguments("--disable-notifications");
					//chrome driver  root path integration
					System.setProperty("webdriver.chrome.driver","src\\test\\resources\\com\\drivers\\chromedriver.exe");
					//creating object for chrome browser
					driver=new ChromeDriver(opt);
					
					
				}
				
				//to maximize the window
				driver.manage().window().maximize();
				//to wait implicitly
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				//to enter the url
				driver.get(url);
				TimeUnit.SECONDS.sleep(2);
				
				}
			catch(WebDriverException e)
			{
				//to print when the browser cannot be launched
				System.out.println("browser could not be launched");
			}
		}
			//to take screenshot
			public void screenshot(String path) throws IOException
			{
				TakesScreenshot ts=((TakesScreenshot)driver);
				//getting the screenshot
				File Source=ts.getScreenshotAs(OutputType.FILE);
				//copying the screenshot to the required location
			    FileUtils.copyFile(Source,new File(path));
			    
			}
			//to close the browser
			public void quit()
			{
				driver.close();
			}

}
