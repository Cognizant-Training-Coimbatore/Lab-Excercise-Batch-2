package com.excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelRead 
{
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	FileInputStream inputStream;
	FileOutputStream outputStream;
	

	public String ReadData(String path,int rowNumber,int colNumber) throws IOException
	{

		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.getCell(colNumber);
		
		String value = cell.getStringCellValue();
		inputStream.close();
		return value;
	}
	public void WriteData(String path,int rowNumber, int columnNumber, String data) throws IOException
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.createCell(columnNumber);
		cell.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File(path));
		workbook.write(outputStream);
        outputStream.close();
	}
	public int getTotalRows(String path) throws IOException 
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		int totalRows = sheet.getLastRowNum();
		inputStream.close();
		
		return(totalRows);		
	}
	public int getTotalcolumns(String path) throws IOException 
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		int totalcolumns = sheet.getRow(1).getLastCellNum();
		inputStream.close();
		
		return(totalcolumns);		
	}
}
