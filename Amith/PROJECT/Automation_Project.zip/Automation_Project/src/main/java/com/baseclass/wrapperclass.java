package com.baseclass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class wrapperclass 
{
	protected static WebDriver driver;
	protected Actions enter;
	protected Actions contact;
	public void launch(String browser, String url)
	{
		try
		{
			if(browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\com\\drivers\\chromedriver.exe");
				driver=new ChromeDriver();
			}
			else if(browser.equalsIgnoreCase("firefox"))
			{
				System.setProperty("webdriver.gecko.driver", "src\\test\\resources\\com\\drivers\\geckodriver.exe");
				driver=new FirefoxDriver();
			}
		}
			catch(WebDriverException e)
			{
				System.out.println("browser launched");
			}
		driver.manage().window().maximize();
		driver.get(url);
		}
	
	public void mouse_Action_Solutions()
	{
		enter=new Actions(driver);
		enter.moveToElement(driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[1]/div[2]/div/div"))).build().perform();
		
	}
	public void mouse_Action_Contacts()
	{
		contact=new Actions(driver);
		contact.moveToElement(driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[2]/div/div"))).build().perform();
		
	}
	public void screenshot(String path) throws IOException
	{
		TakesScreenshot tc=((TakesScreenshot)driver);
		File source=tc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File(path));
		
	}
		
	
	public void quit()
	{
		driver.quit();
	}
}
