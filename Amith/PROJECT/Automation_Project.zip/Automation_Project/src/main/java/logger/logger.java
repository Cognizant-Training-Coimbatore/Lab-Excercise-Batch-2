package logger;

import java.util.logging.Logger;

public class logger 
{
	static Logger log=Logger.getLogger(logger.class.getName());
	public static void writelog(String s)
	{
		log.info(s);
	}
}
