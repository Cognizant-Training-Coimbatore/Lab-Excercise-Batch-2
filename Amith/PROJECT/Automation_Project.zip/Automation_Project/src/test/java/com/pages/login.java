package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;

public class login extends wrapperclass{

	public login(WebDriver driver) 
	{
		this.driver=driver;
	}
	public void login() throws IOException, InterruptedException
	{
		excelRead readdata=new excelRead();
		for(int i=1;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				String dat=readdata.ReadData("src\\test\\resources\\com\\testdata\\login.xlsx", i, j);
				if(j==0)
				{
					driver.findElement(By.id("username")).sendKeys(dat);
					
				}
				if(j==1)
				{
					driver.findElement(By.id("password")).sendKeys(dat);
				}
				
			}
			driver.findElement(By.id("submit")).click();
			TimeUnit.SECONDS.sleep(10);
			try
			{driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div[2]/div[3]/div/button")).click();
			driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div[2]/div[3]/div/ul/div/li[5]/a")).click();
			driver.navigate().to("https://app.saucelabs.com/login");
			TimeUnit.SECONDS.sleep(7);
			}
			catch(WebDriverException e)
			{
				System.out.println("cannot login");
			}
			if(i==1)
			{
				readdata.WriteData("src\\test\\resources\\com\\testdata\\login.xlsx", i, 3, "PASS");
			}
			else
			{
				readdata.WriteData("src\\test\\resources\\com\\testdata\\login.xlsx", i, 3, "FAIL");
			}				
			
		}
		
	}
	public void signup() throws IOException, InterruptedException
	{
		excelRead excel = new excelRead();
		
		int totalRows = excel.getTotalRows("src\\test\\resources\\com\\testdata\\tryitfree.xlsx");
		int totalColumns = excel.getTotalcolumns("src\\test\\resources\\com\\testdata\\tryitfree.xlsx");
			for(int row = 1;row<= totalRows; row++)
			{
				for(int column = 0; column<totalColumns; column++)
				{
					if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx", 0,column).equalsIgnoreCase("First name"))
					{
						String inputFirstname =excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						driver.findElement(By.id("first_name_step1")).sendKeys(inputFirstname);
						TimeUnit.SECONDS.sleep(3);
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",0, column).equalsIgnoreCase("Last name"))
					{
						String inputlastname = excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						driver.findElement(By.id("last_name_step1")).sendKeys(inputlastname);
						TimeUnit.SECONDS.sleep(2);
						
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx", 0, column).equalsIgnoreCase("Work Email"))
					{
						String inputEmail =excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						driver.findElement(By.id("email_step1")).sendKeys(inputEmail);
						TimeUnit.SECONDS.sleep(2);
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",0, column).equalsIgnoreCase("Company"))
					{
						String inputCompany = excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						driver.findElement(By.id("organization_name_step1")).sendKeys(inputCompany);
						TimeUnit.SECONDS.sleep(2);
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",0, column).equalsIgnoreCase("Username"))
					{
						WebElement element = driver.findElement(By.xpath("//*[@id=\"entry-undefined\"]/div/div[2]/div/form[1]/div[6]/button"));
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript("window.scrollBy(0,300)", "");
						TimeUnit.SECONDS.sleep(4);
						element.click();
						TimeUnit.SECONDS.sleep(3);
						JavascriptExecutor js1 = (JavascriptExecutor) driver;
						js1.executeScript("window.scrollBy(0,-100)", "");
						String inputusername = excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						driver.findElement(By.id("username")).sendKeys(inputusername);
						
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",0, column).equalsIgnoreCase("Password"))
					{
						String inputPass = excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						 driver.findElement(By.id("password")).sendKeys(inputPass);
					}
					else if(excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",0, column).equalsIgnoreCase("Country"))
					{
						String inputCountry =excel.ReadData("src\\test\\resources\\com\\testdata\\tryitfree.xlsx",row, column);
						Select dropcountry = new Select(driver.findElement(By.id("country")));
						dropcountry.selectByVisibleText(inputCountry);
					}
				
						
				}
				driver.navigate().to("https://saucelabs.com/sign-up");
				
			}
		
	}

}
