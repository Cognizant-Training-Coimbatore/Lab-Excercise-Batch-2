package com.testcases;

import org.openqa.selenium.By;

import com.baseclass.wrapperclass;
import com.pages.pricing;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class dpricing extends wrapperclass
{	pricing obj1 = new pricing(driver);
	By price = By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[3]/div/div/a");
	
	@Given("^The home page should be opened for selecting pricing tab$")
	public void the_home_page_should_be_opened_for_selecting_pricing_tab() throws Exception 
	{
		launch("chrome", "https://saucelabs.com/");
	}
	@When("^The user clicks the pricing tab$")
	public void the_user_clicks_the_pricing_tab() throws Exception 
	{
	    driver.findElement(price).click();
	}

	@Then("^The user wants to do some functions on the \"([^\"]*)\" pricing page$")
	public void the_user_wants_to_do_some_functions_on_the_pricing_page(String function) throws Exception 
	{
		if(function.equalsIgnoreCase("Live Testing"))
		{
			obj1.Live_Testing();
			
		}
		else if(function.equalsIgnoreCase("Virtual Cloud"))
		{
			obj1.virtual_cloud();
		}
		else if(function.equalsIgnoreCase("Real Device Cloud"))
		{
			obj1.real_device();
		}
		
	}

}
