package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class eresources extends wrapperclass{
	@Given("^The home page should be opened for selecting Resources  tab$")
	public void the_home_page_should_be_opened_for_selecting_Resources_tab() throws Exception 
	{
		launch("chrome", "https://saucelabs.com/");
	}
    @When("^The user clicks the resources tab$")
	public void the_user_clicks_the_resources_tab() throws Exception 
	{
	
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[1]/div/a")).click();
	   
	}
    @Then("^The user want to select \"([^\"]*)\" in the resources tab dropdowns$")
	public void the_user_want_to_select_in_the_resources_tab_dropdowns(String tabname) throws Exception 
	{   
    	com.pages.resources obj= new com.pages.resources(driver);
    	if(tabname.equalsIgnoreCase("Saucelabs"))
	    {
    		obj.Saucelabs();  
	    }
    	else if(tabname.equalsIgnoreCase("Resource"))
	    {
	    	obj.Resource();
	    }
	    else if(tabname.equalsIgnoreCase("TrainingSupport"))
	    {
	    	obj.TrainingSupport();
	    }
	    else if(tabname.equalsIgnoreCase("community"))
	    {
	    	obj.community();
	    }
	    else if(tabname.equalsIgnoreCase("Article"))
	    {
	    	obj.Article();
	    	
	    }
	    else if(tabname.equalsIgnoreCase("Video"))
	    {
	    	obj.Video();
	    	
	    }
	    else if(tabname.equalsIgnoreCase("Webiners"))
	    {
	    	obj.Webiners();
	    }
	    else if(tabname.equalsIgnoreCase("Casestudies"))
	    {
	    	obj.Casestudies();
	    }
	    else if(tabname.equalsIgnoreCase("whitepapper"))
	    {
	    	obj.whitepapper();
	    }
	    else if(tabname.equalsIgnoreCase("datasheet"))
	    {
	    	obj.datasheet();
	    }
	    else if(tabname.equalsIgnoreCase("Documentation"))
	    {
	    	obj.Documentation();
	    }
	    else if(tabname.equalsIgnoreCase("Training"))
	    {
	    	obj.Training();
	    }
	    else if(tabname.equalsIgnoreCase("Sauce"))
	    {
	    	obj.Sauce();
	    }
	    else if(tabname.equalsIgnoreCase("Events"))
	    {
	    	obj.events();
	    }
	    else if(tabname.equalsIgnoreCase("Selenium"))
	    {
	    	obj.selenium();
	    }
	    else if(tabname.equalsIgnoreCase("Appium"))
	    {
	    	obj.Appium();
	    }
	    
	}

	@Then("^The user wants to do some functions on the \"([^\"]*)\"resources sub tabs$")
	public void the_user_wants_to_do_some_functions_on_the_resources_sub_tabs(String function) throws Exception
	{
		com.pages.resources obj= new com.pages.resources(driver);
		if(function.equalsIgnoreCase("Saucelabs"))
	    {
	    	obj.sourcelabsfunction();
	    }
	    else if(function.equalsIgnoreCase("Resource")) 
	    {
	    
	    	obj.Resourcefunction();
	    }
	    else if(function.equalsIgnoreCase("TrainingSupport"))
	    {
	    	
	    	
	    	driver.get("https://support.saucelabs.com/hc/en-us/requests/new");
			excelRead excel=new excelRead();
			
  
			int i;
   		 for(i=1 ; i<=2 ; i++) {
   			 for(int j=0;j<3;j++) {
   				String value=excel.ReadData("src\\test\\resources\\com\\testdata\\excel1.xlsx",i, j);
   				System.out.println(value);
   				if(j==0) {
   					driver.findElement(By.xpath("//*[@id=\"request_anonymous_requester_email\"]")).sendKeys(value);
   				}
   				if(j==1) {
   					driver.findElement(By.xpath("//*[@id=\"request_subject\"]")).sendKeys(value);
   				}
   				if(j==2) {
   					driver.findElement(By.xpath("//*[@id=\"request_description\"]")).sendKeys(value);
   					JavascriptExecutor js=(JavascriptExecutor)driver;
   					 js.executeScript("window.scrollBy(0,400)");
   					driver.findElement(By.xpath("//*[@id=\"new_request\"]/footer/input")).submit();
   	   				Thread.sleep(5000);
   				}
   				
   				
   				}
   			Thread.sleep(5000);
   			driver.navigate().to("https://support.saucelabs.com/hc/en-us/requests/new"); 
   			 }
   			
   		
	    	
	    	
	    	
	    }
	    else if(function.equalsIgnoreCase("community"))
	    {
	    	obj.communityfun();
	    }
	    else if(function.equalsIgnoreCase("Article")) 
	    {
	    	obj.Articlefun();
	    }
	    else if(function.equalsIgnoreCase("Video"))
	    {
	    	obj.Videofun();
	    }
	    else if(function.equalsIgnoreCase("Webiners"))
	    {
	    	obj.Webinersfun();
	    }
	    else if(function.equalsIgnoreCase("Casestudies"))
	    {
	    	obj.Casestudiesfun();
	    }
	    else if(function.equalsIgnoreCase("whitepapper"))
	    {
	    	obj.whitepapperfun();
	    }
	    else if(function.equalsIgnoreCase("datasheet"))
	    {
	    	obj.datasheetfun();
	    }
	    else if(function.equalsIgnoreCase("Documentation"))
	    {
	    	obj.Documentationfun();
	    }
	    else if(function.equalsIgnoreCase("Training"))
	    {
	    	obj.Trainingfun();
	    }
	    else if(function.equalsIgnoreCase("Sauce"))
	    {
	    	obj.Saucefun();
	    }
	    
	    else if(function.equalsIgnoreCase("Selenium"))
	    {
	    	obj.seleniumfun();
	    }
	    else if(function.equalsIgnoreCase("Appium"))
	    {
	    	obj.Appiumfun();
	    }
	    
	   driver.quit();
	}

	
}
