package com.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;
import com.testcases.alogin;

public class solutions extends wrapperclass {
	
	public solutions(WebDriver driver)
	{
		this.driver=driver;
	}
	By enterprise=By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[1]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[1]/div/ul/li/a");
	
	
	public void startup() throws InterruptedException
	{
		
		
		driver.findElement(By.xpath("//*[@href=\"/pricing\" and @class=\"button is-rounded is-primary\"]")).click();
		
	}
	
	public void opensource()
	{
		driver.findElement(By.xpath("//*[@href=\"/open-sauce\" and @class=\"button is-rounded is-primary\"]")).click();
	}
	public void continuos() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1250)", "");
		TimeUnit.SECONDS.sleep(4);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(4);
		driver.findElement(By.xpath("//*[@href=\"/solutions/startup-medium-teams\" and @class=\"button is-rounded is-primary\"]")).click();
		driver.findElement(By.xpath("//*[@class=\"button is-rounded is-primary\" and @href=\"/pricing\"]")).click();
	}
	public void automated() throws InterruptedException
	{
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,550)", "");
		TimeUnit.SECONDS.sleep(4);
		driver.switchTo().frame("widget2");
		driver.findElement(By.xpath("//*[@class=\"ytp-large-play-button ytp-button\"]")).click();
		TimeUnit.SECONDS.sleep(10);
    	quit();
	}
	public void livetesting() throws InterruptedException
	{
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1200)", "");
		TimeUnit.SECONDS.sleep(4);
		driver.findElement(By.xpath("//*[@href=\"/solutions/startup-medium-teams\" and @class=\"button is-rounded is-primary\"]")).click();
		driver.findElement(By.xpath("//*[@class=\"button is-rounded is-primary\" and @href=\"/pricing\"]")).click();
	}
	

}
