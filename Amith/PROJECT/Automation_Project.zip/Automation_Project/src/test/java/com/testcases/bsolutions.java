package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;
import com.pages.login;
import com.pages.pricing;
import com.pages.solutions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class bsolutions extends wrapperclass 
{
	solutions sol=new solutions(driver);
	
	@Given("^The home page should be opened for selecting solution tab$")
	public void the_home_page_should_be_opened_for_selecting_solution_tab() throws Exception 
	{
		launch("chrome", "https://saucelabs.com/");
	}

	@When("^The user clicks the solution tab$")
	public void the_user_clicks_the_solution_tab() throws Exception 
	{
		Actions acti=new Actions(driver);
		
	   acti.moveToElement(driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[1]/div[1]/div/a"))).clickAndHold().build().perform();
	    
	}

	@Then("^The user want to select \"([^\"]*)\" in the solution  dropdown$")
	public void the_user_want_to_select_in_the_solution_dropdown(String tabname) throws Exception 
	{
		TimeUnit.SECONDS.sleep(3);
		System.out.println(tabname);
	    if(tabname.equalsIgnoreCase("Enterprise"))
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Enterprise"))).click().build().perform();
	    }
	    else if(tabname.equalsIgnoreCase("Startup")) 
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Start-ups & SMB Teams"))).click().build().perform();
	    }
	    else if(tabname.equalsIgnoreCase("Opensource"))
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Open Source Projects"))).click().build().perform();
	    }
	    else if(tabname.equalsIgnoreCase("Continuos"))
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Continuous Testing"))).click().build().perform();
	    }
	    else if(tabname.equalsIgnoreCase("Automated"))
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Automated Testing"))).click().build().perform();
	    }
	    else if(tabname.equalsIgnoreCase("Live"))
	    {
	    	mouse_Action_Solutions();
	    	enter.moveToElement(driver.findElement(By.linkText("Live Testing"))).click().build().perform();
	    }
	}

	@Then("^The user wants to do some functions on the \"([^\"]*)\"solutions sub tab$")
	public void the_user_wants_to_do_some_functions_on_the_solutions_sub_tab(String function) throws Exception 
	{
		if(function.equalsIgnoreCase("Enterprise"))
	    {
			driver.findElement(By.xpath("//*[@id=\"entry-4SpIFkXBB5GX0eTswW1kpM\"]/div/div/div/div[1]/div/div/a")).click();
			
			login obj=new login(driver);
			obj.signup();
	    	quit();
	    }
	    else if(function.equalsIgnoreCase("Startup")) 
	    {
	   
	    	quit();
	    }
	    else if(function.equalsIgnoreCase("Opensource"))
	    {
	    	sol.opensource();
	    	excelRead read=new excelRead();
	    	for(int i=1;i<7;i++)
	    	{
	    		for(int j=0;j<5;j++)
	    		{
	    			String value=read.ReadData("src\\test\\resources\\com\\testdata\\opensource.xlsx", i, j);
	    			System.out.println(value);
	    			if(j==0)
	    			{
	    				driver.findElement(By.id("name")).sendKeys(value);
	    			}
	    			else if(j==1)
	    			{
	    				driver.findElement(By.id("email")).sendKeys(value);
	    			}
	    			else if(j==2)
	    			{
	    				driver.findElement(By.id("organization_name")).sendKeys(value);
	    			}
	    			else if(j==3)
	    			{
	    				driver.findElement(By.id("repository_url")).sendKeys(value);
	    			}
	    			else if(j==4)
	    			{
	    				driver.findElement(By.xpath("//*[@id=\"project\"]")).sendKeys(value);
	    			}
	    			
	    		}
	    		driver.navigate().to("https://saucelabs.com/open-sauce");
	    	}
	    	quit();
	    }
	    else if(function.equalsIgnoreCase("Continuos"))
	    {
	    	sol.continuos();
	    	
	 	  
	    	quit();
	    }
	    else if(function.equalsIgnoreCase("Automated"))
	    {
	    	sol.automated();
	    }
	    else if(function.equalsIgnoreCase("Live"))
	    {
	    	sol.livetesting();
	    	quit();
	    }
		
	    
	}
}
