package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.baseclass.wrapperclass;

public class resources extends wrapperclass {
com.testcases.eresources obj=new com.testcases.eresources();
	
	
	public resources(WebDriver driver)
	{
		this.driver=driver;
	}
	public void Saucelabs() throws Exception {
		 driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[1]/div/ul/li/a")).click();
	     	
	}
	public void Resource() {
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/a")).click();
	
		}
	public void TrainingSupport() {
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[1]/div/ul/li/a")).click();
	
		}
	public void community () {
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[2]/div/ul/li/a")).click();
	    
		}
	public void Article()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[1]/a")).click();
		
	}
	public void Video()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[2]/a")).click();
		
	}
	public void Webiners()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[3]/a")).click();
		
	}
	public void Casestudies()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[4]/a")).click();
		
	}
	public void whitepapper()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[5]/a")).click();
	}
	public void datasheet()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[1]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[6]/a")).click();
	}
	public void Documentation()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[1]/div/ul/li/ul/li[2]/a")).click();
		
	}
	public void Training() 
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[1]/div/ul/li/ul/li[3]/a")).click();
	}
	public void Sauce()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[1]/a")).click();
	}
	public void events()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[2]/a")).click();
	}
	public void selenium()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[3]/a")).click();
	}
	public void Appium()
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[4]/div[2]/div/div/div/ul/li[2]/div/ul/li/div/ul/li[2]/div/ul/li/ul/li[4]/a")).click();
	}
	
	public void sourcelabsfunction()
	{
		
	
		driver.findElement(By.xpath("//*[@id=\"template__blog-home\"]/section[1]/div/div/div[2]/div[1]/div/div/a[1]/div[2]/div[1]/p")).click();
driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/div[2]/ul/li/a")).click();
		
		driver.navigate().to("https://saucelabs.com/blog"); 
		driver.findElement(By.xpath("//*[@id=\"template__blog-home\"]/section[1]/div/div/div[2]/div[1]/div/div/a[2]/div[2]/div[1]/p")).click();
		driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/div[3]/ul/li/a")).click();
		
	}
	
	
	public void Resourcefunction() throws InterruptedException 
	{
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,450)");
		 Thread.sleep(5000);
		 driver.get("https://saucelabs.com/resources/case-studies/quick-base-reduces-test-execution-time-from-5-hours-to-15-minutes-while-increasing-coverage-and-empowering-developers");
		
		
	}
	public void TrainingSupportfun() throws InterruptedException {
		driver.get("https://support.saucelabs.com/hc/en-us/requests/new");
		
		
		driver.findElement(By.xpath("//*[@id=\"request_anonymous_requester_email\"]")).sendKeys("ardra3@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"request_subject\"]")).sendKeys("BLA");
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("//*[@id=\"request_description\"]")).sendKeys("Regarding testing...");
	
		 
		driver.findElement(By.xpath("//*[@id=\"new_request\"]/footer/input")).submit();
		Thread.sleep(5000);
		
	}
	public void communityfun() throws InterruptedException {
		
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();

    	JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,350)");
		 TimeUnit.SECONDS.sleep(4);
		 driver.get("https://support.saucelabs.com/hc/en-us");
		 WebElement bla=driver.findElement(By.xpath("//*[@id=\"query\"]"));
		 bla.sendKeys("Selenium");
		 bla.submit();
		 driver.navigate().to("https://saucelabs.com/community"); 
		
		 driver.get("https://saucelabs.com/community/join-secret-sauce");
		
	}
	public void Articlefun() throws InterruptedException 
	{

		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-3iQbA3qb7YsDeHE1BnnwVs\"]/div/div/div[1]/a/div[2]")).click();
	}
	public void Videofun() throws InterruptedException 
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-3WYZc1bCoElSp49Rmo6A7u\"]/div/div/div[1]/a/div[1]/img")).click();

		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[1]/div[2]/div/p[2]/a")).click();
		 Thread.sleep(5000);
		
	}
	public void Webinersfun() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-E0YU6U6jotw2qHbFPkVe5\"]/div/div[2]/div/a/div[1]/img")).click();
		 driver.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Anusha");
		 driver.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("PV");
		 driver.findElement(By.xpath("//*[@id=\"Company\"]")).sendKeys("cts");
		 

			//JavascriptExecutor jx=(JavascriptExecutor)driver;
			 js.executeScript("window.scrollBy(0,400)");
			 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("anusha@gmail.com");
		 js.executeScript("window.scrollBy(0,400)");
		
		 driver.findElement(By.xpath("//*[@id=\"Title\"]")).sendKeys("Program Analyst");
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"mktoForm_1844\"]/div[7]/span/button")).submit();
		
		 js.executeScript("window.scrollBy(0,-500)","");
		 Thread.sleep(5000);
	}
	public void Casestudiesfun() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-5bWZbrFfFX9rAkgOW2uszX\"]/div/div/div[2]/a/div[2]/div/p")).click();;
		driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/div[4]/a")).click();
		Thread.sleep(5000);
	}
	public void whitepapperfun() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-2gm5SJxUrDHmcjXYG5cc4F\"]/div/div/div[2]/a/div[2]/div/p[1]")).click();
		 driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/a")).click();
		 Thread.sleep(2000);
		 
	}
	public void datasheetfun() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,400)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"entry-75kcijPNRarIQqws6AsyLV\"]/div/div/div[2]/a/div[2]/div/p[1]")).click();
		 driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/div[1]/a")).click();
		 Thread.sleep(2000);
	}
	
	public void Documentationfun() throws InterruptedException
	{
	
		
		
	    Thread.sleep(5000);
		driver.get("https://wiki.saucelabs.com/display/DOCS/Getting+Started");
		Thread.sleep(5000);
	}
	public void Trainingfun() throws InterruptedException 
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,550)");
		 Thread.sleep(2000);
		 driver.get("https://saucelabs.learnupon.com/users/sign_in");
		 driver.findElement(By.xpath("//*[@id=\"user_login\"]")).sendKeys("ardrapsurendran3@gmail.com");
		 driver.findElement(By.xpath("//*[@id=\"user_password\"]")).sendKeys("Ardra1234@");
		 driver.findElement(By.xpath("//*[@id=\"pageContentWrapper\"]/div/div/div/div/section/div/div[1]/form/input[3]")).click();
		 Thread.sleep(5000);	
	}
	public void Saucefun() throws InterruptedException
	{
		Thread.sleep(5000);
		}
	
	public void seleniumfun() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.get("https://www.selenium.dev/downloads/");
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/p[2]/a")).click();
		Thread.sleep(5000);
	}
	public void Appiumfun() throws InterruptedException
	{
		Thread.sleep(5000);
		
		driver.get("https://github.com/appium/appium-desktop/releases/tag/v1.15.1");
		Thread.sleep(5000);
	}
}
