package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;
import com.pages.login;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class alogin extends wrapperclass
{
	ExtentReports report=new ExtentReports("src\\test\\resources\\com\\report\\report.html");
	ExtentTest test=report.startTest("Login_Test");
	login log=new login(driver);
		
		@Given("^The home page should be opened in the browser$")
		public void the_home_page_should_be_opened_in_the_browser() throws Exception 
		{
		    launch("chrome", "https://saucelabs.com/");
		   
		}
		
		@When("^The user clicks the sign in button$")
		public void the_user_clicks_the_sign_in_button() throws Exception {
		   driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[3]/ul/li[2]/a")).click();
		    
		}
		
		@Then("^The user wants to enter username,password and click the login button$")
		public void the_user_wants_to_enter_username_password_and_click_the_login_button() throws Exception 
		{
			
			log.login();
			
			TimeUnit.SECONDS.sleep(5);
			quit();
		   
		}
		
		@Given("^User is in the Login Page$")
		public void user_is_in_the_Login_Page() throws Exception 
		{
			launch("chrome", "https://app.saucelabs.com/login");
		   
		}
		
		@When("^The user clicks the forgot password button$")
		public void the_user_clicks_the_forgot_password_button() throws Exception 
		{
			TimeUnit.SECONDS.sleep(5);
		    driver.findElement(By.linkText("Forgot?")).click();
		    
		}
		@Then("^The user enters the username and click the reset password button$")
		public void the_user_enters_the_username_and_click_the_reset_password_button() throws Exception 
		{
   
		
		    excelRead forg=new excelRead();
		    for(int i=1;i<3;i++)
		    {
		    	String forgot=forg.ReadData("src\\test\\resources\\com\\testdata\\login.xlsx", i, 0);
		    	driver.findElement(By.id("username")).sendKeys(forgot);
		    	driver.findElement(By.xpath("//button[@class=\"Buttons__btn__3yodQ Buttons__btn-action__wMfIo Buttons__block__1b70M\"]")).click();
		    	
		    		TimeUnit.SECONDS.sleep(5);
		    		driver.findElement(By.linkText("Forgot?")).click();
		    		test.log(LogStatus.PASS, "Entered username for getting password reset");
		    		}
		    	
		    		
		    			
		    		
		    
		    TimeUnit.SECONDS.sleep(5);
			quit();
		   
		}		
		
		
		@Given("^User is in the Login page for creating account$")
		public void user_is_in_the_Login_page_for_creating_account() throws Exception 
		{
			launch("chrome", "https://app.saucelabs.com/login"); 
		   
		}
		
		@When("^The user clicks the Create account link$")
		public void the_user_clicks_the_Create_account_link() throws Exception 
		{
			TimeUnit.SECONDS.sleep(5);
			driver.findElement(By.xpath("//a[@href=\"https://saucelabs.com/sign-up\"]")).click();   
		    
		}
		@Then("^The user enters required information for login and submit$")
public void the_user_enters_required_information_for_login_and_submit() throws Exception {
   

		
		 log.signup(); 
		 test.log(LogStatus.PASS, "Account creation done for valid and invalid data");
		 TimeUnit.SECONDS.sleep(5);
			quit();
		   
		}
		
		
		
		
		    
		
		
		@Given("^User is in the Login page for github login$")
		public void user_is_in_the_Login_page_for_github_login() throws Exception {
			launch("chrome", "https://app.saucelabs.com/login");
		   
		}
		
		@When("^The user clicks the login using github account$")
		public void the_user_clicks_the_login_using_github_account() throws Exception
		{
			TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//a[@href=\"https://saucelabs.com/oauth/login/github\"]")).click();
		   
		}
		@Then("^The user wants to enter reqiured information and click login$")
public void the_user_wants_to_enter_reqiured_information_and_click_login() throws Exception 
		{
    
			excelRead readdata=new excelRead();
			for(int i=1;i<2;i++)
			{
				for(int j=0;j<2;j++)
				{
					String dat=readdata.ReadData("src\\test\\resources\\com\\testdata\\github.xlsx", i, j);
					if(j==0)
					{
						driver.findElement(By.id("login_field")).sendKeys(dat);
					}
					if(j==1)
					{
						driver.findElement(By.id("password")).sendKeys(dat);
					}
					
				}
				driver.findElement(By.name("commit")).click();
				TimeUnit.SECONDS.sleep(10);
				
				try
				{driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div[2]/div[3]/div/button")).click();
				driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div[2]/div[3]/div/ul/div/li[5]/a")).click();
				driver.navigate().to("https://app.saucelabs.com/login");
				TimeUnit.SECONDS.sleep(7);
				driver.findElement(By.xpath("//a[@href=\"https://saucelabs.com/oauth/login/github\"]")).click();
				readdata.WriteData("src\\test\\resources\\com\\testdata\\github.xlsx", i, 3, "PASS");
				test.log(LogStatus.PASS, "logged in using github credentials");
				}
				catch(WebDriverException e)
				{
					readdata.WriteData("src\\test\\resources\\com\\testdata\\github.xlsx", i, 3, "FAIL");
					System.out.println("incorrect login");
					test.log(LogStatus.FAIL, "Cannot login using git hub credentials");
					
				}
			}
			
			TimeUnit.SECONDS.sleep(5);
			report.endTest(test);
			report.flush();
			quit(); 
		}
	


}
