package com.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;

public class contacts extends wrapperclass {

	public contacts(WebDriver driver) 
	{
		this.driver=driver;
	}
	
	public void contact_Sales() throws IOException, InterruptedException
	{
		
		excelRead read=new excelRead();
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
	for(int i=1;i<3;i++)
	{
		
		
		for(int j=0;j<5;j++)
		{
			String value=read.ReadData("src\\test\\resources\\com\\testdata\\contactsone.xlsx", i, j);
			System.out.println(value);
			if(j==0)
			{
				driver.findElement(By.id("FirstName")).sendKeys(value);
			}
			else if(j==1)
			{
				driver.findElement(By.id("LastName")).sendKeys(value);
			}
			else if(j==2)
			{
				driver.findElement(By.id("Company")).sendKeys(value);
			}
			else if(j==3)
			{
				driver.findElement(By.id("Email")).sendKeys(value);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,300)", "");
			}
			
			else if(j==4)
			{
				driver.findElement(By.id("Sales_Contact_Comments__c")).sendKeys(value);
			}
				
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		driver.findElement(By.id("Phone")).sendKeys("9876543210");
		Select companysize=new Select(driver.findElement(By.id("Company_Size__c")));
		companysize.selectByIndex(3);
		driver.findElement(By.xpath("//input[@value=\"Mobile Testing\"]")).click();
		TimeUnit.SECONDS.sleep(5);
		
		driver.findElement(By.xpath("//*[@id=\"mktoForm_381\"]/div[13]/span/button")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.navigate().to("https://saucelabs.com/sales");
		
		
		
	}
	}
	public void general() throws IOException, InterruptedException
	{
		excelRead readgen=new excelRead();
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		for(int i=1;i<3;i++)
		{
			for(int j=0;j<6;j++)
			{
				String input=readgen.ReadData("src\\test\\resources\\com\\testdata\\General.xlsx", i, j);
				System.out.println(input);
				if(j==0)
				{
					driver.findElement(By.id("name")).sendKeys(input);
				}
				else if(j==1)
				{
					driver.findElement(By.id("email")).sendKeys(input);
				}
				else if(j==2)
				{
					driver.findElement(By.id("organization_name")).sendKeys(input);
				}
				else if(j==3)
				{
					driver.findElement(By.id("country")).sendKeys(input);
				}
				else if(j==4)
				{
					driver.findElement(By.id("state")).sendKeys(input);
				}
				else if(j==5)
				{
					driver.findElement(By.id("message")).sendKeys(input);
				}
				
			}
			TimeUnit.SECONDS.sleep(7);
			
			driver.navigate().to("https://saucelabs.com/contact");
		}
			
	}
	public void contactsupport() throws Exception {
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[2]/div/div/div/ul/li/div/ul/li[2]/div/ul/li[1]/div/ul/li/a")).click();
			
	}
	public void contactsupportfun() throws InterruptedException 
	{
		driver.findElement(By.xpath("//*[@id=\"entry-7gUOYHBcOMcXJCkS9egev2\"]/div/div/div/div[1]/div/div[2]/a")).click();

		driver.findElement(By.xpath("//*[@id=\"request_anonymous_requester_email\"]")).sendKeys("ardra3@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"request_subject\"]")).sendKeys("BLA");
		//Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id=\"request_description\"]")).sendKeys("Regarding testing...");
		driver.findElement(By.xpath("//*[@id=\"new_request\"]/footer/input")).submit();
		Thread.sleep(5000);	
	}
	
    public void saucecommunity()
    {
    	driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[2]/div/div/div/ul/li/div/ul/li[2]/div/ul/li[2]/div/ul/li/a")).click();
    }
    public void saucecommunityfun() throws InterruptedException
    {
    	JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,350)");
		 TimeUnit.SECONDS.sleep(4);
		 driver.get("https://support.saucelabs.com/hc/en-us");
		 WebElement bla=driver.findElement(By.xpath("//*[@id=\"query\"]"));
		 bla.sendKeys("Selenium");
		 bla.submit();
		 driver.navigate().to("https://saucelabs.com/community"); 
		 //driver.findElement(By.xpath("//*[@id=\"entry-3hdyL9JOZYNS4Q4mwq0gPa\"]/div/div/div[2]/div/div/div[2]/div/a")).click();
		 driver.get("https://saucelabs.com/community/join-secret-sauce");
		 
    }
}
