package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class cplatform extends wrapperclass
{
	public Actions enter;

	@Given("^The home page should be opened for selecting platform tab$")
	public void the_home_page_should_be_opened_for_selecting_platform_tab() throws Exception {
		 launch("chrome", "https://saucelabs.com/");
	    
	}

	
	@When("^The user clicks the platform tab$")
	public void the_user_clicks_the_platform_tab() throws Exception {
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[2]/div[1]/div/a")).click(); 
		
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[2]/div[2]/div/div")).click();
		
	}

	
	@Then("^The user want to select \"([^\"]*)\" in the platform tab dropdowns$")
	public void the_user_want_to_select_in_the_platform_tab_dropdowns(String arg1) throws Exception {
	    
		
		com.pages.platform obj=new com.pages.platform(driver);
		
		if(arg1.equalsIgnoreCase("RealDeviceCloud"))
	    {
			
			obj.RealDeviceCloud();
			
	    }
	    else if(arg1.equalsIgnoreCase("CrossBrowserTesting")) 
	    {
	    	obj.CrossBrowserTesting();
			
	    }
	    else if(arg1.equalsIgnoreCase("EmulatorsSimulators"))
	    {
	    	
	    	obj.EmulatorsSimulators();
	    }
	    else if(arg1.equalsIgnoreCase("SauceHeadless"))
	    {
	    	obj.SauceHeadless();
	    }
	    else if(arg1.equalsIgnoreCase("VisualTesting"))
	    {
	    	obj.VisualTesting();
	    }
	    else if(arg1.equalsIgnoreCase("SupportedIntegrations"))
	    {
	    	obj.SupportedIntegrations();
	    }
	    else if(arg1.equalsIgnoreCase("SupportedBrowsers"))
	    {
	    	obj.SupportedBrowsers();
	    }
	    else if(arg1.equalsIgnoreCase("SaucePerformance"))
	    {
	    	obj.SaucePerformance();
			
	    }
	    else if(arg1.equalsIgnoreCase("TestAnalytics"))
	    {
	    	obj.TestAnalytics();
	    }
	    else if(arg1.equalsIgnoreCase("ExtendedDebugging"))
	    {
	    	obj.ExtendedDebugging();
	    }
	    else if(arg1.equalsIgnoreCase("Selenium"))
	    {
	    	obj.Selenium();
	    }
	    else if(arg1.equalsIgnoreCase("Appium"))
	    {
	    	obj.Appium();
	    }
	    else if(arg1.equalsIgnoreCase("Espresso"))
	    {
	    	obj.Espresso();
	    }
	    else if(arg1.equalsIgnoreCase("XCUITest"))
	    {
	    	obj.XCUITest();
	    }
	    else 
	    {
	    	obj.Viewall();
	    }
	   
	
	    
	}

}
