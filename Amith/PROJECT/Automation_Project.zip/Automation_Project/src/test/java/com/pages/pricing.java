package com.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.baseclass.wrapperclass;

public class pricing extends wrapperclass 
{
	
	@SuppressWarnings("static-access")
	public pricing(WebDriver driver)
	{
		this.driver=driver;
	}
	public void Live_Testing() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		for(int i=0;i<3;i++)
		{
			List <WebElement>radio = driver.findElements(By.xpath("//*[@class=\"plan-radio\"]"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)", "");
			System.out.println(radio.get(i).getText());
			TimeUnit.SECONDS.sleep(5);
			radio.get(i).click();
			driver.findElement(By.xpath("//*[@id=\"entry-68uWQLYvnF9acV0WYQ5Wh4\"]/div/div/div[1]/form/div[2]/div[2]/a")).click();
			driver.navigate().to("https://saucelabs.com/pricing");
			TimeUnit.SECONDS.sleep(4);
		}
		quit();
			
		
	}
	
	public void virtual_cloud() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		for(int i=0;i<5;i++)
		{
			
			Select list = new Select(driver.findElement(By.xpath("//select[@class=\"browser-default\"and @name=\"virtual-platform-cloud-options\"]")));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)", "");
			TimeUnit.SECONDS.sleep(6);
			list.selectByIndex(i);
			driver.findElement(By.xpath("//*[@id=\"entry-68uWQLYvnF9acV0WYQ5Wh4\"]/div/div/div[2]/form/div[2]/div[2]/a")).click();
			driver.navigate().to("https://saucelabs.com/pricing");
			TimeUnit.SECONDS.sleep(4);
		}
		
	}
	public void real_device() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		for(int i=0;i<5;i++)
		{
			
			Select list = new Select(driver.findElement(By.xpath("//select[@class=\"browser-default\" and @name=\"real-device-cloud-options\"]")));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)", "");
			TimeUnit.SECONDS.sleep(6);
			list.selectByIndex(i);
			driver.findElement(By.xpath("//*[@id=\"entry-68uWQLYvnF9acV0WYQ5Wh4\"]/div/div/div[3]/form/div[2]/div[2]/a")).click();
			driver.navigate().to("https://saucelabs.com/pricing");
			TimeUnit.SECONDS.sleep(4);
		}
	}

}
