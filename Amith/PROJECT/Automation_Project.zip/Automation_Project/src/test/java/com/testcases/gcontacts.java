package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;
import com.pages.contacts;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class gcontacts extends wrapperclass

{

	contacts cont=new contacts(driver);
	@Given("^The home page should be opened for selecting Contacts tab$")
	public void the_home_page_should_be_opened_for_selecting_Contacts_tab() throws Exception 
	{	
		launch("chrome", "https://saucelabs.com/");
	   
	}

	@When("^The user clicks the Contacts tab$")
	public void the_user_clicks_the_Contacts_tab() throws Exception 
	{
		Actions con=new Actions(driver);
		con.moveToElement(driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[1]/div/a"))).build().perform();;
	   
	}

	@Then("^The user want to select \"([^\"]*)\" in the Contacts tab dropdowns$")
	public void the_user_want_to_select_in_the_Contacts_tab_dropdowns(String tabname) throws Exception 
	{com.pages.contacts obj= new com.pages.contacts(driver);
		TimeUnit.SECONDS.sleep(3);
		System.out.println(tabname);
	    if(tabname.equalsIgnoreCase("Contact"))
	    {
	    	
	    	
	    	driver.findElement(By.linkText("Contact Sales")).click();
	    }
	    else if(tabname.equalsIgnoreCase("General")) 
	    {
	    	
	    	driver.findElement(By.linkText("General Inquiries")).click();
	    }
	   
	    
	    if(tabname.equalsIgnoreCase("contactsupport"))
	    {
    		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[2]/div/div/div/ul/li/div/ul/li[2]/div/ul/li[1]/div/ul/li/a")).click(); 
	    }
    	else if(tabname.equalsIgnoreCase("saucecommunity"))
	    {
    		obj.saucecommunity();
	    	
	    }
	   
	    
	   
	}

	@Then("^The user wants to do some functions on the \"([^\"]*)\" Contacts sub tabs$")
	public void the_user_wants_to_do_some_functions_on_the_Contacts_sub_tabs(String selected ) throws Exception 
	{
		 if(selected.equalsIgnoreCase("Contact"))
		    {
		    	
		    	cont.contact_Sales();
		    	quit();
		    	screenshot("C:\\Users\\Admin\\Downloads\\Automation_Project\\Automation_Project\\src\\test\\resources\\com\\screenshot\\contact.jpg");
		    	
		    }
		    else if(selected.equalsIgnoreCase("General")) 
		    {
		    	
		    	cont.general();
		    }
		com.pages.contacts obj= new com.pages.contacts(driver);
			if(selected.equalsIgnoreCase("contactsupport"))
		    {
				driver.get("https://support.saucelabs.com/hc/en-us/requests/new");
				excelRead excel=new excelRead();
				
	   		// System.out.println(value);
				int i;
	   		 for(i=1 ; i<=2 ; i++) {
	   			 for(int j=0;j<3;j++) {
	   				String value=excel.ReadData("src\\test\\resources\\com\\testdata\\excel1.xlsx", i, j);
	   				System.out.println(value);
	   				if(j==0) {
	   					driver.findElement(By.xpath("//*[@id=\"request_anonymous_requester_email\"]")).sendKeys(value);
	   				}
	   				if(j==1) {
	   					driver.findElement(By.xpath("//*[@id=\"request_subject\"]")).sendKeys(value);
	   				}
	   				if(j==2) {
	   					driver.findElement(By.xpath("//*[@id=\"request_description\"]")).sendKeys(value);
	   					JavascriptExecutor js=(JavascriptExecutor)driver;
	   					 js.executeScript("window.scrollBy(0,400)");
	   					driver.findElement(By.xpath("//*[@id=\"new_request\"]/footer/input")).submit();
	   	   				Thread.sleep(5000);
	   				}
	   				
	   				
	   				}
	   			Thread.sleep(5000);
	   			driver.navigate().to("https://support.saucelabs.com/hc/en-us/requests/new"); 
	   			 }
	   			
	   		
	   		 }
		    
	    	else if(selected.equalsIgnoreCase("saucecommunity"))
		    {
		    	obj.saucecommunityfun();
		    }
			
		    
		driver.quit();
	    
	}
}
