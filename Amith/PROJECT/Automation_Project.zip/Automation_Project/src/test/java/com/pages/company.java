package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;

public class company extends wrapperclass{

	public company(WebDriver driver) 
	{
		this.driver=driver;
		
	}
	public void aboutus() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[5]/div[2]/div/div/div/ul/li/div/ul/li/div/ul/li[1]/div/ul/li/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"entry-3zE2XinivioBmMs7zu8eMO\"]/div/div/div[2]/div/div[2]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.xpath("//*[@id=\"template__columns\"]/div[2]/div/div[2]/div[1]/a")).click();
	TimeUnit.SECONDS.sleep(3);
	}
	public void careers() throws InterruptedException
	{
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,750)", "");
		TimeUnit.SECONDS.sleep(3);
		
		
		
	}
	

}
