package com.pages;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;

public class platform extends wrapperclass {
	
	public platform(WebDriver driver)
	{
		this.driver=driver;
	}
	public void RealDeviceCloud() throws InterruptedException
	{
		
		driver.findElement(By.linkText("Real Device Cloud")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		TimeUnit.SECONDS.sleep(5);
		js.executeScript("window.scrollBy(0,500)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		
		WebElement clickbutton = driver.findElement(By.linkText("View case study"));
		Actions action = new Actions(driver);
		action.moveToElement(clickbutton).click().perform();
		WebElement click = driver.findElement(By.linkText("Download PDF"));
		Actions act = new Actions(driver);
		act.moveToElement(click).click().perform();
		TimeUnit.SECONDS.sleep(5); 
		
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));
			driver.close();
			driver.switchTo().window(tabs.get(0));
			driver.navigate().to("https://saucelabs.com/platform/real-device-cloud");
		
		js.executeScript("window.scrollBy(0,1000)", "");
		TimeUnit.SECONDS.sleep(5); 
		js.executeScript("window.scrollBy(0,500)", "");
		TimeUnit.SECONDS.sleep(5); 
			
			WebElement click1 = driver.findElement(By.linkText("View supported devices"));
			Actions act1 = new Actions(driver);
			act1.moveToElement(click1).click().perform();
			js.executeScript("window.scrollBy(0,200)", "");
			TimeUnit.SECONDS.sleep(5); 
		js.executeScript("window.scrollBy(0,300)", "");
		WebElement c1 = driver.findElement(By.linkText("Platform configurator"));
		act1.moveToElement(c1).click().perform();
		driver.navigate().to("https://saucelabs.com/platform/real-device-cloud");
		TimeUnit.SECONDS.sleep(5); 
		js.executeScript("window.scrollBy(0,1000)", "");
		TimeUnit.SECONDS.sleep(5); 
		js.executeScript("window.scrollBy(0,1000)", "");
		driver.quit();
		
	}
	public void CrossBrowserTesting() throws InterruptedException
	{
		driver.findElement(By.linkText("Cross-browser Testing")).click();
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		js1.executeScript("window.scrollBy(0,500)", "");
		TimeUnit.SECONDS.sleep(5); 
		js1.executeScript("window.scrollBy(0,200)", "");
		WebElement clickbutton1 = driver.findElement(By.linkText("View case study"));
		Actions action1 = new Actions(driver);
		action1.moveToElement(clickbutton1).click().perform();
		driver.quit();
	}
	public void EmulatorsSimulators() throws InterruptedException
	{
		driver.findElement(By.linkText("Emulators & Simulators")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		js.executeScript("window.scrollBy(0,1000)", "");
		TimeUnit.SECONDS.sleep(5);
		//js.executeScript("window.scrollBy(0,500)", "");
		WebElement clickbutton4 = driver.findElement(By.linkText("View case study"));
		Actions action4 = new Actions(driver);
		action4.moveToElement(clickbutton4).click().perform();
		//clickbutton4.click();
		driver.navigate().to("https://saucelabs.com/platform/mobile-emulators-and-simulators");
		js.executeScript("window.scrollBy(0,1000)", "");
		TimeUnit.SECONDS.sleep(5);
		js.executeScript("window.scrollBy(0,1000)", "");
		WebElement clickbutto =driver.findElement(By.linkText("View real device cloud"));
		action4.moveToElement(clickbutto).click().perform();
		TimeUnit.SECONDS.sleep(5);
		//driver.navigate().to("https://saucelabs.com/platform/mobile-emulators-and-simulators");
		//TimeUnit.SECONDS.sleep(5);
		driver.quit();
		
	}
	public void SauceHeadless()
	{
		driver.findElement(By.linkText("Sauce Headless")).click();
		JavascriptExecutor js6 = (JavascriptExecutor) driver;
		js6.executeScript("window.scrollBy(0,1500)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();	
		driver.quit();
	
	}
	public void VisualTesting() throws InterruptedException
	{
		driver.findElement(By.linkText("Visual Testing")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
		
	}
	public void SupportedIntegrations() throws InterruptedException
	{
		driver.findElement(By.linkText("Supported Integrations")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		WebElement clickbu= driver.findElement(By.linkText("Learn more"));
		Actions action1 = new Actions(driver);
		action1.moveToElement(clickbu).click().perform();
		clickbu.click();
		TimeUnit.SECONDS.sleep(5);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.close();
		driver.switchTo().window(tabs.get(0));
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
		
		
		
	}
	public void SupportedBrowsers() throws InterruptedException
	{
		driver.findElement(By.linkText("Supported Browsers & Devices"));
		JavascriptExecutor js7 = (JavascriptExecutor) driver;
		js7.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		driver.findElement(By.linkText("Platform configurator")).click();
		js7.executeScript("window.scrollBy(0,1000)", "");
		driver.navigate().to("https://saucelabs.com/platform/supported-browsers-devices");
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//*[@id=\"selectDevicePanel\"]/div/div[1]/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//*[@id=\"selectDevicePanel\"]/div/div[2]/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//*[@id=\"selectDevicePanel\"]/div/div[3]/a")).click();
		TimeUnit.SECONDS.sleep(5); 
		driver.quit();
		
		
	}
	public void SaucePerformance() throws InterruptedException
	{
		driver.findElement(By.linkText("Sauce Performance")).click();
		JavascriptExecutor js3 = (JavascriptExecutor) driver;
		js3.executeScript("window.scrollBy(0,500)", "");
		//js.executeScript("window.scrollBy(0,500)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.navigate().to("https://saucelabs.com/");
		TimeUnit.SECONDS.sleep(5);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.quit();
	}
	public void TestAnalytics() throws InterruptedException
	{
		driver.findElement(By.linkText("Test Analytics")).click();
		JavascriptExecutor jss = (JavascriptExecutor) driver;
		jss.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		
		driver.navigate().to("https://saucelabs.com/");
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
	}
	public void ExtendedDebugging() throws InterruptedException
	{
		driver.findElement(By.linkText("Extended Debugging")).click();
		JavascriptExecutor jst = (JavascriptExecutor) driver;
		jst.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		WebElement clickbutton2 = driver.findElement(By.xpath("//*[@id=\"entry-62JZasMhESUpup24y47VmN\"]/div/div[2]/div[1]/div/div/div[2]/div/a"));
		Actions action2 = new Actions(driver);
		action2.moveToElement(clickbutton2).click().perform();
		//clickbutton2.click();
		TimeUnit.SECONDS.sleep(5);
		driver.navigate().to("https://saucelabs.com/");
		driver.quit();
	}
	public void Selenium() throws InterruptedException
	{
		driver.findElement(By.linkText("Selenium")).click();
		TimeUnit.SECONDS.sleep(5);
		JavascriptExecutor js9 = (JavascriptExecutor) driver;
		js9.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		js9.executeScript("window.scrollBy(0,500)", "");
		WebElement clickbutton2 = driver.findElement(By.linkText("Update Selenium tests"));
		Actions action2 = new Actions(driver);
		action2.moveToElement(clickbutton2).click().perform();
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
		
	}
	public void Appium() throws InterruptedException
	{
		driver.findElement(By.linkText("Appium")).click();
		JavascriptExecutor jsr = (JavascriptExecutor) driver;
		jsr.executeScript("window.scrollBy(0,1000)", "");
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		WebElement clickbutton2 = driver.findElement(By.linkText("Platform configurator"));
		Actions action2 = new Actions(driver);
		action2.moveToElement(clickbutton2).click().perform();
		//clickbutton2.click();
		TimeUnit.SECONDS.sleep(6);
		driver.quit();
	}
	public void Espresso() throws InterruptedException
	{
		driver.findElement(By.linkText("Espresso")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
	}
	public void XCUITest() throws InterruptedException
	{
		driver.findElement(By.linkText("XCUITest")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
		
	}
	public void Viewall() throws InterruptedException
	{
		driver.findElement(By.linkText("View all")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
	}
	
}
