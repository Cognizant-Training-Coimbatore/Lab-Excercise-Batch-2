package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.baseclass.wrapperclass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class isearch extends wrapperclass
{
	By Select_a_link = By.xpath("//*[@class=\"search-results\"]/a[2]");
	
	@Given("^The home page should be opened for searching$")
	public void the_home_page_should_be_opened_for_searching() throws Exception 
	{
		launch("chrome", "https://saucelabs.com/");
	}

	@When("^The user clicks the search button$")
	public void the_user_clicks_the_search_button() throws Exception 
	{	TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		TimeUnit.SECONDS.sleep(4);
		WebElement search =driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[3]/ul/li[3]/form"));
		search.click();
		
	    
	}

	@Then("^The user want to \"([^\"]*)\"$")
	public void the_user_want_to(String search) throws Exception 
	{
		WebElement search1 =driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[3]/ul/li[3]/form/div/input"));
		search1.sendKeys(search,Keys.ENTER);
		
	}
	@Then("^The user wants to do select the result$")
	public void the_user_wants_to_do_select_the_result() throws Exception 
	{
	    driver.findElement(Select_a_link).click();
	    TimeUnit.SECONDS.sleep(5);
	    driver.quit();
	}
}
