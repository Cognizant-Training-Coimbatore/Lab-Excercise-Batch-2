package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.wrapperclass;
import com.pages.company;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import logger.logger;

public class fcompany extends wrapperclass
{
	company com=new company(driver);
	logger log = new logger();
	
	@Given("^The home page should be opened for selecting Company tab$")
	public void the_home_page_should_be_opened_for_selecting_Company_tab() throws Exception 
	{
		launch("chrome", "https://saucelabs.com/");
		 log.writelog("app opened"); 
	    
	}

	@When("^The user clicks the Company tab$")
	public void the_user_clicks_the_Company_tab() throws Exception 
	{
		Actions acti=new Actions(driver);
		acti.moveToElement(driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[5]/div[1]/div/a"))).build().perform();
		log.writelog("company tab clicked");   
	    
	}

	@Then("^The user want to select \"([^\"]*)\" in the Company tab dropdowns$")
	public void the_user_want_to_select_in_the_Company_tab_dropdowns(String tab) throws Exception 
	{
		TimeUnit.SECONDS.sleep(3);
		if(tab.equalsIgnoreCase("aboutus"))
		{
			
			com.aboutus();
			log.writelog("about us tab clicked");
			
			
		}
		else if(tab.equalsIgnoreCase("careers"))
		{
			
			driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[5]/div[2]/div/div/div/ul/li/div/ul/li/div/ul/li[2]/div/ul/li/a")).click();
			com.careers();
			log.writelog("careers tab clicked");
			
			
			
		}
		else if(tab.equalsIgnoreCase("news"))
		{
			Actions acti=new Actions(driver);
			driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[5]/div[2]/div/div/div/ul/li/div/ul/li/div/ul/li[3]/div/ul/li/a")).click();
			TimeUnit.SECONDS.sleep(3);
			acti.sendKeys(Keys.PAGE_DOWN).build().perform();
			TimeUnit.SECONDS.sleep(2);
			driver.findElement(By.xpath("/html/body/div[2]/section[2]/div/div[1]/div[2]/a")).click();
			acti.sendKeys(Keys.PAGE_DOWN).build().perform();
			TimeUnit.SECONDS.sleep(2);
			driver.findElement(By.xpath("/html/body/div[2]/section[2]/div/div/div[1]/a/div[2]")).click();
			driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
			TimeUnit.SECONDS.sleep(3);
			log.writelog("news tab clicked");
			
			
			
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[5]/div[2]/div/div/div/ul/li/div/ul/li/div/ul/li[4]/div/ul/li/a")).click();
			TimeUnit.SECONDS.sleep(2);
			driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
			Actions acti=new Actions(driver);
			acti.sendKeys(Keys.PAGE_DOWN).build().perform();
			log.writelog(" partner tab clicked");
			TimeUnit.SECONDS.sleep(3);
			quit();
			
		}
		
	

	
	}
}
