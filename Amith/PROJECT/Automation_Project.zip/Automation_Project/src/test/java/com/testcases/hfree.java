package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.baseclass.wrapperclass;
import com.excelutility.excelRead;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class hfree extends wrapperclass
{
	String excelPath = "src\\test\\resources\\com\\testdata\\tryitfree1.xlsx";
	excelRead excel = new excelRead();
	int column;
	int row;
	
@Given("^The home page should be opened for selecting try it free$")
public void the_home_page_should_be_opened_for_selecting_try_it_free() throws Exception 
{
	launch("chrome", "https://saucelabs.com/");
}

@When("^The user clicks the try it free button$")
public void the_user_clicks_the_try_it_free_button() throws Exception 
{
   driver.findElement(By.linkText("Try it free")).click();
	TimeUnit.SECONDS.sleep(5);
	driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
}

@Then("^The user  wants to enter first four fields and wants to click next button,and enter remaining four field$")
public void the_user_wants_to_enter_first_four_fields_and_wants_to_click_next_button_and_enter_remaining_four_field() throws Exception 
{
    

	excel= new excelRead();
	int totalRows = excel.getTotalRows(excelPath);
	int totalColumns = excel.getTotalcolumns(excelPath);
		for(int row = 1;row<= totalRows; row++)
		{
			for(int column = 0; column<totalColumns; column++)
			{
				if(excel.ReadData(excelPath, 0,column).equalsIgnoreCase("First name"))
				{
					String inputFirstname =excel.ReadData(excelPath,row, column);
					driver.findElement(By.id("first_name_step1")).sendKeys(inputFirstname);
					TimeUnit.SECONDS.sleep(3);
				}
				else if(excel.ReadData(excelPath,0, column).equalsIgnoreCase("Last name"))
				{
					String inputlastname = excel.ReadData(excelPath,row, column);
					driver.findElement(By.id("last_name_step1")).sendKeys(inputlastname);
					TimeUnit.SECONDS.sleep(2);
					
				}
				else if(excel.ReadData(excelPath, 0, column).equalsIgnoreCase("Work Email"))
				{
					String inputEmail =excel.ReadData(excelPath,row, column);
					driver.findElement(By.id("email_step1")).sendKeys(inputEmail);
					TimeUnit.SECONDS.sleep(2);
				}
				else if(excel.ReadData(excelPath,0, column).equalsIgnoreCase("Company"))
				{
					String inputCompany = excel.ReadData(excelPath,row, column);
					driver.findElement(By.id("organization_name_step1")).sendKeys(inputCompany);
					TimeUnit.SECONDS.sleep(2);
					WebElement element = driver.findElement(By.xpath("//*[@id=\"entry-undefined\"]/div/div[2]/div/form[1]/div[6]/button"));
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,300)", "");
					TimeUnit.SECONDS.sleep(4);
					element.click();
					TimeUnit.SECONDS.sleep(3);
				}
			
		
				
			try
				{
					
					String url ="https://saucelabs.com/sign-up/step2";
					
					
					if((excel.ReadData(excelPath,0, column).equalsIgnoreCase("Username"))&&(driver.getCurrentUrl().equalsIgnoreCase(url)))
					{
					
					JavascriptExecutor js1 = (JavascriptExecutor) driver;
					js1.executeScript("window.scrollBy(0,-100)", "");
					String inputusername = excel.ReadData(excelPath,row, column);
					driver.findElement(By.id("username")).sendKeys(inputusername);
					
					}
					else if((excel.ReadData(excelPath,0, column).equalsIgnoreCase("Password"))&&(driver.getCurrentUrl().equalsIgnoreCase(url)))
					{
					String inputPass = excel.ReadData(excelPath,row, column);
					 driver.findElement(By.id("password")).sendKeys(inputPass);
					}
					else if((excel.ReadData(excelPath,0, column).equalsIgnoreCase("Country"))&&(driver.getCurrentUrl().equalsIgnoreCase(url)))
					{
					String inputCountry =excel.ReadData(excelPath,row, column);
					Select dropcountry = new Select(driver.findElement(By.id("country")));
					dropcountry.selectByVisibleText(inputCountry);
					excel.WriteData(excelPath, row, 8, "Pass");
					
					}
			
		}
			catch(WebDriverException String  )
			{
				
				excel.WriteData(excelPath, row, 8, "Fail");
			}
			
		}
			
			driver.navigate().to("https://saucelabs.com/sign-up");
			
		}
		driver.quit();
   }
}

